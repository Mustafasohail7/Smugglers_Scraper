

<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
            <div class="page-header">
              <h3 class="page-title">
                <span class="page-title-icon bg-gradient-primary text-white me-2">
                  <i class="mdi mdi-clipboard-text"></i>
                </span> All Benefits
              </h3>
            </div>
            <?php echo $__env->make('admin.inc.notify', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="row">
              <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title">All Benefits</h4>
                    <table class="table table-striped">
                      <thead>
                        <tr>
                          <th> # </th>
                          <th> Procedure </th>
                          <th> Benefit Code </th>
                          <th> Benefit Name </th>
                          <th> Benefit statistics </th>
                          <th> User </th>
                          <th> Status </th>
                          <th> Created_at </th>
                        </tr>
                      </thead>
                      <tbody>

                        <?php
                        $count = 0;
                        ?>
                        <?php $__currentLoopData = $new_benefit_pending; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new_benefit_pending_get): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php
                        $count++;
                        ?>
                        <?php
                        $mnb = explode(',',$new_benefit_pending_get->procedure_code);
                        ?>
                        <tr>
                          <td> <?php echo e($count); ?> </td>
                          <td>
                          <?php $__currentLoopData = $mnb; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $singcode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a href="<?php echo e(url('procedure', $singcode)); ?>">
        <?php echo e($singcode); ?>

    </a>

    <?php if( !$loop->last): ?>
        ,
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</td>
                          <td> <?php echo e($new_benefit_pending_get->code); ?> </td>
                          <td> <?php echo e($new_benefit_pending_get->benefit_name); ?> </td>
                          <td> <?php echo e($new_benefit_pending_get->statistics); ?> </td>
                          <td> <?php echo e($new_benefit_pending_get->fname); ?> <?php echo e($new_benefit_pending_get->lname); ?> </td>
                          <?php if($new_benefit_pending_get->status == 0): ?>
                          <td> <label class="badge badge-gradient-danger">Pending</label> </td>
                          <?php else: ?>
                          <td> <label class="badge badge-gradient-success">Done</label> </td>
                          <?php endif; ?>
                          <td> <?php echo e($new_benefit_pending_get->created_at); ?> </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
            
            
          </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\surgery\resources\views/admin/allbenefits.blade.php ENDPATH**/ ?>