

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e($show_webpage->name); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <div class="col-md-12">
                        <h5>Content:</h5>
                        <?php echo $show_webpage->content; ?>

                    </div>
                    
                    <!-- <?php echo e(Crypt::decryptString(Auth::user()->cardnumber)); ?> -->
                </div>
            </div>

            <div class="card mt-3">
                <div class="card-header"><?php echo e(__('Download QR Code')); ?></div>
                <!-- $from = [255, 0, 0]; -->
                <!-- $to = [0, 0, 255]; -->
                <?php
                $from = [81, 65, 79];
                $to = [103, 49, 71];
                ?>
                <div class="card-body">
                    <div class="col-md-12">
                        <div class="row">
                        <div class="col-md-4 mb-3">
                            <div id="img1_qr" style="width: 66px;
    height: 66px;
    padding: 5px;">
                            <img src="data:image/png;base64, <?php echo base64_encode(QrCode::size(56)->color(159, 43, 104)->style('square')->gradient($from[0], $from[1], $from[2], $to[0], $to[1], $to[2], 'diagonal')->eye('square')->format('png')->generate(url('/page/'.$show_webpage->pageid))); ?> ">
                            </div>
                            <a href="javascript:void(0);" class="btn btn-warning roundbtn saveimg1_qr mt-3" style=""><i class="fa fa-download"></i> Download</a>
                    </div>
                     <div class="col-md-4 mb-3">
                        <div id="img2_qr" style="width: 105px;
    height: 105px;
    padding: 5px;"> 
                        <img src="data:image/png;base64, <?php echo base64_encode(QrCode::size(95)->color(159, 43, 104)->style('square')->gradient($from[0], $from[1], $from[2], $to[0], $to[1], $to[2], 'diagonal')->eye('square')->format('png')->generate(url('/page/'.$show_webpage->pageid))); ?> ">
                        </div>
                        <a href="javascript:void(0);" class="btn btn-warning roundbtn saveimg2_qr mt-3" style=""><i class="fa fa-download"></i> Download</a>
                    </div>
                     <div class="col-md-4 mb-3">
                        <div id="img3_qr" style="width: 160px;
    height: 160px;
    padding: 5px;"> 
                        <img src="data:image/png;base64, <?php echo base64_encode(QrCode::size(150)->color(159, 43, 104)->style('square')->gradient($from[0], $from[1], $from[2], $to[0], $to[1], $to[2], 'diagonal')->eye('square')->format('png')->generate(url('/page/'.$show_webpage->pageid))); ?> ">
                        </div>
                        <a href="javascript:void(0);" class="btn btn-warning roundbtn saveimg3_qr mt-3" style=""><i class="fa fa-download"></i> Download</a>
                    </div>
                        </div>
                    </div>
                    
                    <!-- <?php echo e(Crypt::decryptString(Auth::user()->cardnumber)); ?> -->
                </div>
            </div>

            <div class="card mt-3">
                <div class="card-header"><?php echo e(__('Download QR Code in PDF')); ?></div>
                <div class="card-body" >
                    <div class="col-md-12" id="pdfmaindiv">
                        <div class="row" style="    justify-content: center;">
                        <?php
                         for ($i=0; $i < 4; $i++) {  
                         ?>  
                        <div class="col-md-3" style="border: 1px solid black;
    padding: 10px;
    justify-content: center;
    display: flex;width: 180px;
    align-items: center;
    height: 180px;">
                        <img src="data:image/png;base64, <?php echo base64_encode(QrCode::size(56)->color(159, 43, 104)->style('square')->gradient($from[0], $from[1], $from[2], $to[0], $to[1], $to[2], 'diagonal')->eye('square')->format('png')->generate(url('/page/'.$show_webpage->pageid))); ?> "> 
                    </div>
                    <?php
                }
                ?>
                </div>
                <div class="row" style="    justify-content: center;">
                    <?php
                         for ($i=0; $i < 4; $i++) {  
                         ?> 
                     <div class="col-md-3" style="border: 1px solid black;
    padding: 10px;
    justify-content: center;
    display: flex;width: 180px;
    align-items: center;
    height: 180px;">
                        <img src="data:image/png;base64, <?php echo base64_encode(QrCode::size(95)->color(159, 43, 104)->style('square')->gradient($from[0], $from[1], $from[2], $to[0], $to[1], $to[2], 'diagonal')->eye('square')->format('png')->generate(url('/page/'.$show_webpage->pageid))); ?> "> 
                    </div>
                    <?php
                }
                ?>
                </div>
                <div class="row mb-3" style="    justify-content: center;">
                    <?php
                         for ($i=0; $i < 4; $i++) {  
                         ?> 
                     <div class="col-md-3" style="border: 1px solid black;
    padding: 10px;
    justify-content: center;
    display: flex;width: 180px;
    align-items: center;
    height: 180px;">
                        <img src="data:image/png;base64, <?php echo base64_encode(QrCode::size(150)->color(159, 43, 104)->style('square')->gradient($from[0], $from[1], $from[2], $to[0], $to[1], $to[2], 'diagonal')->eye('square')->format('png')->generate(url('/page/'.$show_webpage->pageid))); ?> ">
                    </div>
                    <?php
                }
                ?>
                        </div>
                    </div>
                    
                    <!-- <?php echo e(Crypt::decryptString(Auth::user()->cardnumber)); ?> -->
                </div>
            </div>
<a href="javascript:void(0);" class="btn btn-warning roundbtn savepdf_qr mt-3" style="float: right;">Download PDF</a>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\qrcode\resources\views/webpage/show.blade.php ENDPATH**/ ?>