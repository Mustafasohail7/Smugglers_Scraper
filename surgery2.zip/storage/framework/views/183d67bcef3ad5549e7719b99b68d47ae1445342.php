

<?php $__env->startSection('content'); ?>
<style type="text/css">
	.list-ticked li{
		background: #e5e3e3;
    border-radius: 5px;
    padding: 0px 0px 0px 5px;
    position: relative;
	}
  .mdi-subdirectory-arrow-left{
        position: absolute;
    top: 40px;
    left: -22px;
    font-size: 20px;
    color: blue;
    cursor: pointer;
  }
  .mdi-subdirectory-arrow-right{
        position: absolute;
    top: 10px;
    right: -22px;
    font-size: 20px;
    color: blue;
    cursor: pointer;
  }
</style>
<div class="content-wrapper">
            <div class="page-header">
              <h3 class="page-title">
                <span class="page-title-icon bg-gradient-primary text-white me-2">
                  <i class="mdi mdi-clipboard-text"></i>
                </span> <?php echo e($single_proc->procedure_name); ?> (<?php echo e($single_proc->procedure_code); ?>)  created by (<?php echo e($single_proc->fname); ?> <?php echo e($single_proc->lname); ?>) <?php if($single_proc->status == 0): ?>
                      	<b style="color:red">Pending</b>
                      	<?php else: ?>
                      	<b style="color:green">Done</b>
                      	<?php endif; ?>
                         
              </h3>
            </div>

            <form method="POST" class="mb-3" action="<?php echo e(url('/admin_procedure_status/' .  $single_proc->id)); ?>">
                        <?php echo csrf_field(); ?>
                    <input type="hidden" name="webpageid" value="<?php echo e($single_proc->id); ?>">
                    <input type="text" name="proc_name" value="<?php echo e($single_proc->procedure_name); ?>">
                    <select name="statusget" id="statusget">
                        <option <?php if($single_proc->status == 1) { echo "selected"; } ?> value="1">Done</option>
                        <option <?php if($single_proc->status == 0) { echo "selected"; } ?> value="0">Pending</option>
                    </select>
                    <button type="submit" class="btn btn-gradient-success btn-sm">Update</button>
                    </form>
            <?php echo $__env->make('admin.inc.notify', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
           	

           	<div class="row">
              <div class="col-3 mb-2">
                      <button type="button" class="btn btn-gradient-secondary" id="addnewbenefit_modalopen" data-name="ben">Add Benefit</button>
                    </div>
              <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                   
                   <div class="row">
                   	<div class="col-6">
                   		<h5>Procedure Benefit</h5>
                   		<ul class="list-ticked">
                   		<?php $__currentLoopData = $single_proc_benfit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single_proc_benfit_get): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li><b><?php echo e($single_proc_benfit_get->code); ?></b> - <?php echo e($single_proc_benfit_get->benefit_name); ?> - <?php echo e($single_proc_benfit_get->statistics); ?> <p><?php echo e($single_proc_benfit_get->detail); ?></p>
                      	<?php if($single_proc_benfit_get->status == 0): ?>
                      	<p>
                      	<b style="color:red">Pending</b> -- Create & view by only <b><?php echo e($single_proc_benfit_get->fname); ?> <?php echo e($single_proc_benfit_get->lname); ?></b>
                        <form method="POST" class="mb-3" action="<?php echo e(url('/admin_benfit_status/' .  $single_proc_benfit_get->code)); ?>">
                        <?php echo csrf_field(); ?>
                    <input type="hidden" name="benfitcode" value="<?php echo e($single_proc_benfit_get->code); ?>">
                    <select name="statusget_ben" class="statusget_ben">
                        <option <?php if($single_proc_benfit_get->status == 1) { echo "selected"; } ?> value="1">Done</option>
                        <option <?php if($single_proc_benfit_get->status == 0) { echo "selected"; } ?> value="0">Pending</option>
                    </select>
                    </form>
                      	</p>
                      	<?php else: ?>
                      	<p>
                      	<b style="color:green">Done</b> -- Created by <b><?php echo e($single_proc_benfit_get->fname); ?> <?php echo e($single_proc_benfit_get->lname); ?></b>
                      	</p>
                      	<?php endif; ?>
                        <?php if($single_proc_benfit_get->status == 1): ?>
                        <i class="mdi mdi-subdirectory-arrow-right moverightside" data-id="<?php echo e($single_proc_benfit_get->id); ?>" data-name="ben" data-code="<?php echo e($single_proc_benfit_get->code); ?>" data-procid="<?php echo e($single_proc->id); ?>"></i>
                        <?php endif; ?>
                      </li>
                   		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </ul>
                   	</div>

                   	<div class="col-6">
                   		<h5>All Benefit</h5>
                   		<ul class="list-ticked">
                   		<?php $__currentLoopData = $single_proc_all_benfit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single_proc_all_benfit_get): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li><b><?php echo e($single_proc_all_benfit_get->code); ?></b> - <?php echo e($single_proc_all_benfit_get->benefit_name); ?> - <?php echo e($single_proc_all_benfit_get->statistics); ?> <p><?php echo e($single_proc_all_benfit_get->detail); ?></p>
                      	<?php if($single_proc_all_benfit_get->status == 0): ?>
                      	<p>
                      	<b style="color:red">Pending</b> -- Create & view by only <b><?php echo e($single_proc_all_benfit_get->fname); ?> <?php echo e($single_proc_all_benfit_get->lname); ?></b>
                      	</p>
                      	<?php else: ?>
                      	<p>
                      	<b style="color:green">Done</b> -- Created by <b><?php echo e($single_proc_all_benfit_get->fname); ?> <?php echo e($single_proc_all_benfit_get->lname); ?></b>
                      	</p>
                      	<?php endif; ?>
                        <i class="mdi mdi-subdirectory-arrow-left moveleftside" data-name="ben" data-code="<?php echo e($single_proc_all_benfit_get->code); ?>" data-procid="<?php echo e($single_proc->id); ?>"></i>
                      </li>
                   		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </ul>
                   	</div>
                   </div>

                  </div>
                </div>
              </div>
            </div>

            <div class="row">
              <div class="col-3 mb-2">
                      <button type="button" class="btn btn-gradient-secondary" id="addnewbenefit_modalopen" data-name="risk">Add Risk</button>
                    </div>
              <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                   
                   <div class="row">
                    <div class="col-6">
                      <h5>Procedure Risk</h5>
                      <ul class="list-ticked">
                      <?php $__currentLoopData = $single_proc_risk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single_proc_risk_get): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li><b><?php echo e($single_proc_risk_get->code); ?></b> - <?php echo e($single_proc_risk_get->risk_name); ?> - <?php echo e($single_proc_risk_get->statistics); ?> <p><?php echo e($single_proc_risk_get->detail); ?></p>
                        <?php if($single_proc_risk_get->status == 0): ?>
                        <p>
                        <b style="color:red">Pending</b> -- Create & view by only <b><?php echo e($single_proc_risk_get->fname); ?> <?php echo e($single_proc_risk_get->lname); ?></b>
                        <form method="POST" class="mb-3" action="<?php echo e(url('/admin_risk_status/' .  $single_proc_risk_get->code)); ?>">
                        <?php echo csrf_field(); ?>
                    <input type="hidden" name="riskcode" value="<?php echo e($single_proc_risk_get->code); ?>">
                    <select name="statusget_risk" class="statusget_risk">
                        <option <?php if($single_proc_risk_get->status == 1) { echo "selected"; } ?> value="1">Done</option>
                        <option <?php if($single_proc_risk_get->status == 0) { echo "selected"; } ?> value="0">Pending</option>
                    </select>
                    </form>
                        </p>
                        <?php else: ?>
                        <p>
                        <b style="color:green">Done</b> -- Created by <b><?php echo e($single_proc_risk_get->fname); ?> <?php echo e($single_proc_risk_get->lname); ?></b>
                        </p>
                        <?php endif; ?>
                        <?php if($single_proc_risk_get->status == 1): ?>
                        <i class="mdi mdi-subdirectory-arrow-right moverightside" data-id="<?php echo e($single_proc_risk_get->id); ?>" data-name="risk" data-code="<?php echo e($single_proc_risk_get->code); ?>" data-procid="<?php echo e($single_proc->id); ?>"></i>
                        <?php endif; ?>
                      </li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </ul>
                    </div>

                    <div class="col-6">
                      <h5>All Risk</h5>
                      <ul class="list-ticked">
                      <?php $__currentLoopData = $single_proc_all_risk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single_proc_all_risk_get): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li><b><?php echo e($single_proc_all_risk_get->code); ?></b> - <?php echo e($single_proc_all_risk_get->risk_name); ?> - <?php echo e($single_proc_all_risk_get->statistics); ?> <p><?php echo e($single_proc_all_risk_get->detail); ?></p>
                        <?php if($single_proc_all_risk_get->status == 0): ?>
                        <p>
                        <b style="color:red">Pending</b> -- Create & view by only <b><?php echo e($single_proc_all_risk_get->fname); ?> <?php echo e($single_proc_all_risk_get->lname); ?></b>
                        </p>
                        <?php else: ?>
                        <p>
                        <b style="color:green">Done</b> -- Created by <b><?php echo e($single_proc_all_risk_get->fname); ?> <?php echo e($single_proc_all_risk_get->lname); ?></b>
                        </p>
                        <?php endif; ?>
                        <i class="mdi mdi-subdirectory-arrow-left moveleftside" data-name="risk" data-code="<?php echo e($single_proc_all_risk_get->code); ?>" data-procid="<?php echo e($single_proc->id); ?>"></i>
                      </li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                      </ul>
                    </div>
                   </div>

                  </div>
                </div>
              </div>
            </div>
            
            
          </div>

<!-- new benefit modal -->
<div class="modal fade zoomIn" id="newBenefit_Modal" tabindex="-1" data-bs-keyboard="false" data-bs-backdrop="static" aria-hidden="true" role="dialog">
          <div class="modal-dialog modal-dialog-centered modal-md">
            <div class="modal-content">
                <div class="modal-header">
        <h4 class="modal-title">Add New Procedure</h4>
      </div>
      <form method="POST" action="<?php echo e(url('submit_new_benefitrisk_admin')); ?>" id="new_benefitrisk_form">
        <?php echo csrf_field(); ?>
                <div class="modal-body" style="">
                <div class="row">
                            <div class="col-md-6">
                                <label class="form-label">Name</label>
                                <input name="new_benefit_status_input" type="hidden" class="new_benefit_status_input form-control input">
                                <input name="proc_id" type="hidden" class="proc_id form-control input" value="<?php echo e($single_proc->id); ?>">
                                <input name="new_benefit_name_input" required type="text" class="new_benefit_name_input form-control input">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Statistics</label>
                                <input name="new_benefit_statistics_input" required type="text" class="new_benefit_statistics_input form-control input">
                            </div>
                            <div class="col-md-12 mt-2">
                                <label class="form-label">Detail</label>
                                <input name="new_benefit_detail_input" required type="text" class="new_benefit_detail_input form-control input">
                            </div>
                            </div>

                </div>
                 <div class="modal-footer">
        <button type="button" class="btn btn-gradient-danger btn-fw btn_close_modal" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-gradient-success btn-fw add_newben_submit_btn">SUBMIT</button>
        <button type="button" class="btn btn-gradient-success btn-fw add_newben_submit_btn_loader" style="display:none;">Waiting...</button>
      </div>
  </form>
                </div>
            </div>
          </div>
<!-- new benefit modal -->
<script type="text/javascript">

$(document).on('change','.statusget_ben',function(event){
this.form.submit();
})
$(document).on('change','.statusget_risk',function(event){
this.form.submit();
})
$(document).on('click','.moverightside',function(event){
var id = $(this).attr('data-id');
var name = $(this).attr('data-name');
var code = $(this).attr('data-code');
var procid = $(this).attr('data-procid');
let formData = new FormData();
formData.append('id',id);
formData.append('name',name);
formData.append('code',code);
formData.append('procid',procid);
        $.ajaxSetup({
          headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
      });
         $.ajax({
        // headers: {
        //     'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')
        // },
        url: "<?php echo e(url('admin_benrisk_moverightside')); ?>",
        type: "POST",
        data: formData,
         processData: false,
    contentType: false,
    cache: false,
        dataType: "json",
         success: function(data) {
          console.log(data)
          location.reload();
          }
        });
});

$(document).on('click','.moveleftside',function(event){
var name = $(this).attr('data-name');
var code = $(this).attr('data-code');
var procid = $(this).attr('data-procid');
let formData = new FormData();
formData.append('name',name);
formData.append('code',code);
formData.append('procid',procid);
        $.ajaxSetup({
          headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
      });
         $.ajax({
        // headers: {
        //     'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')
        // },
        url: "<?php echo e(url('admin_benrisk_moveleftside')); ?>",
        type: "POST",
        data: formData,
         processData: false,
    contentType: false,
    cache: false,
        dataType: "json",
         success: function(data) {
          console.log(data)
          location.reload();
          }
        });
});
$(document).on('click','#addnewbenefit_modalopen',function(event){
  var name = $(this).attr('data-name');
  if(name == 'ben'){
  $('.modal-title').text('Add New Benefit')
  }
  else{
  $('.modal-title').text('Add New Risk')
  }
  $('.new_benefit_status_input').val(name)
  $('#newBenefit_Modal').modal('show')
})

 $(document).on('click','.btn_close_modal',function(){
        $('#newBenefit_Modal').modal('hide');
    });

 $('#new_benefitrisk_form').submit(function(e) {
        e.preventDefault();
        $('.add_newben_submit_btn').hide();
        $('.add_newben_submit_btn_loader').show();
        let formData = new FormData(this);
        $.ajaxSetup({
          headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
      });
         $.ajax({
        // headers: {
        //     'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')
        // },
        url: $(this).attr('action'),
        type: $(this).attr('method'),
        data: formData,
         processData: false,
    contentType: false,
    cache: false,
        dataType: "json",
         success: function(data) {
            console.log(data);
            
        $('.add_newben_submit_btn').show();
        $('.add_newben_submit_btn_loader').hide();
        $('#newBenefit_Modal').modal('hide')
        // fetchproc($('#search_proc').val(),$('#search_status').val());
        location.reload()
        },
        error: function(err) {
            console.log(err)
        }
    });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\surgery\resources\views/admin/procedure.blade.php ENDPATH**/ ?>