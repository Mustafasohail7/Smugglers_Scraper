

<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
            <div class="page-header">
              <h3 class="page-title">
                <span class="page-title-icon bg-gradient-primary text-white me-2">
                  <i class="mdi mdi-account-search"></i>
                </span> All Users
              </h3>
            </div>
            <?php echo $__env->make('admin.inc.notify', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="row justify-content-center">
              
            <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <table class="table table-striped">
                      <thead>
                        <tr>
                          <th> #</th>
                          <th> First name </th>
                          <th> Last name</th>
                          <th> Email </th>
                          <th> Phone </th>
                          <th> Qualification </th>
                          <th> Practice name </th>
                          <th> Created_at </th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php
                        $count = 0;
                        ?>
                        <?php $__currentLoopData = $all_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php
                        $count++;
                        ?>
                        <tr>
                          <td> <?php echo e($count); ?> </td>
                          <td> <?php echo e($user->fname); ?> </td>
                          <td> <?php echo e($user->lname); ?> </td>
                          <td> <?php echo e($user->email); ?> </td>
                          <td> <?php echo e($user->phone); ?> </td>
                          <td> <?php echo e($user->qualifications); ?> </td>
                          <td> <?php echo e($user->practice_name); ?> </td>
                          <td> <?php echo e($user->created_at); ?> </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>

            </div>
            
            
          </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\surgery\resources\views/admin/allusers.blade.php ENDPATH**/ ?>