<style>
    .spiinerdiv {
  background-color: #000000a6;
    width: 100%;
    height: 100vh;
    margin: 0;
    display: grid;
    place-items: center;
    z-index: 9999;
    position: absolute;
}

.spinner {
  display: grid;
  place-items: center;
  width: 150px;
  height: 150px;
  border-radius: 50%;
  background: conic-gradient(
    from 180deg at 50% 50%,
    rgba(82, 0, 255, 0) 0deg,
    #5200ff 360deg
  );
  animation: spin 2s infinite linear;
}
.spinner::before {
  content: "";
  border-radius: 50%;
  width: 80%;
  height: 80%;
  background-color: #000;
}

@keyframes spin {
  to {
    transform: rotate(1turn);
  }
}
   </style>
<?php if(auth()->guard()->guest()): ?>
<div class="spiinerdiv">
<div class="spinner"></div>
</div>
<?php else: ?>
<?php endif; ?>


<?php $__env->startSection('content'); ?>
<style>
    .pageheading{
        text-align: center;
        font-weight: bold;
        font-size: 25px;
    }
    .smallheading{
        font-size: 15px;
    }
.form-label {
    margin-bottom: 0rem;
    text-align: center !important;
    width: 100%;
    color: black;
    font-weight: 500;
}
.input{
    background: none;
  outline: none;
  border: 2px solid black !important;
  border-radius: inherit;
  text-align: center;
    font-size: 20px;
    font-weight: 700;
    text-transform: uppercase;
  padding: 0px !important;
}
.input:focus{
    background: none !important;
  outline: none !important;
  border: 2px solid black !important;
  border-radius: inherit;
  padding: 0px !important;
   box-shadow: none !important;
}
.input:active{
    background: none !important;
  outline: none !important;
  border: 2px solid black !important;
  border-radius: inherit;
  padding: 0px !important;
   box-shadow: none !important;
}
.btnanotherproc {
    width: 100%;
    border: 1px solid #a79696 !important;
    border-radius: 0;
    color: #a79696;
    text-transform: uppercase;
    text-align: center;
}
.btnanotherproc:focus{
    background: none !important;
  outline: none !important;
  border: 1px solid #a79696 !important;
  border-radius: inherit;
/*  padding: 0px !important;*/
   box-shadow: none !important;
}
.btnanotherproc:active{
    background: none !important;
  outline: none !important;
  border: 1px solid #a79696 !important;
  border-radius: inherit;
/*  padding: 0px !important;*/
   box-shadow: none !important;
}
.btnanotherproc_plus, .btnanotherproc_classaddremove{
    font-size: 30px;
    /* border: 1px solid; */
    color: #aad9aa;
    font-weight: bold;
    position: absolute;
    font-family: sans-serif;
    top: 20px;
    cursor: pointer;
}
.btnanotherproc_plus:hover{
color: #12b712;
}

.btnsubmit{
        background: #b5ddb5;
    border: 1px solid #12b712;
    color: black;
    font-weight: bold;
    padding: 10px 30px 10px 30px;
    border-radius: 0;
    width: 200px;
}
.btnsubmit:hover{
        background: #b5ddb5;
    border: 1px solid #12b712;
    color: black;
    font-weight: bold;
    padding: 10px 30px 10px 30px;
    border-radius: 0;
    width: 200px;
}
.py-4 {
    padding-top: 1.5rem!important;
    padding-bottom: 0rem!important;
}

@import url(https://fonts.googleapis.com/css?family=Roboto);

/****** LOGIN MODAL ******/
.loginmodal-container {
  padding: 30px;
  max-width: 350px;
  width: 100% !important;
  background-color: #F7F7F7;
  margin: 0 auto;
  border-radius: 2px;
  box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
  overflow: hidden;
  font-family: roboto;
}

.loginmodal-container h1 {
  text-align: center;
  font-size: 1.8em;
  font-family: roboto;
}

.loginmodal-container input[type=submit] {
  width: 100%;
  display: block;
  margin-bottom: 10px;
  position: relative;
}

.loginmodal-container input[type=text], input[type=password], input[type=email] {
  height: 44px;
  font-size: 16px;
  width: 100%;
  margin-bottom: 10px;
  -webkit-appearance: none;
  background: #fff;
  border: 1px solid #d9d9d9;
  border-top: 1px solid #c0c0c0;
  /* border-radius: 2px; */
  padding: 0 8px;
  box-sizing: border-box;
  -moz-box-sizing: border-box;
}

.loginmodal-container input[type=text]:hover, input[type=password]:hover, input[type=email]:hover {
  border: 1px solid #b9b9b9;
  border-top: 1px solid #a0a0a0;
  -moz-box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
  -webkit-box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
  box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
}

.loginmodal {
  text-align: center;
  font-size: 14px;
  font-family: 'Arial', sans-serif;
  font-weight: 700;
  height: 36px;
  padding: 0 8px;
/* border-radius: 3px; */
/* -webkit-user-select: none;
  user-select: none; */
}

.loginmodal-submit {
  /* border: 1px solid #3079ed; */
  border: 0px;
  color: #fff;
  text-shadow: 0 1px rgba(0,0,0,0.1); 
  background-color: #4d90fe;
  padding: 17px 0px;
  font-family: roboto;
  font-size: 14px;
  /* background-image: -webkit-gradient(linear, 0 0, 0 100%,   from(#4d90fe), to(#4787ed)); */
}

.loginmodal-submit:hover {
  /* border: 1px solid #2f5bb7; */
  border: 0px;
  text-shadow: 0 1px rgba(0,0,0,0.3);
  background-color: #357ae8;
  /* background-image: -webkit-gradient(linear, 0 0, 0 100%,   from(#4d90fe), to(#357ae8)); */
}

.loginmodal-container a {
  text-decoration: none;
  color: #666;
  font-weight: 400;
  text-align: center;
  display: inline-block;
  opacity: 0.6;
  transition: opacity ease 0.5s;
} 

.login-help{
  font-size: 12px;
}

.login-btn {
  text-align:center;
  margin-top: 50px;
}

.button {
  line-height: 55px;
  padding: 0 30px;
  background: #004a80;
  color: #fff;
  display: inline-block;
  font-family: roboto;
  text-decoration: none;
  font-size: 18px;
}

.button:hover,
.button:visited {
  background: #006cba;
  color: #fff;
}

.btnprocedure_minus{
    font-size: 30px;
    /* border: 1px solid; */
    color: #12b712;
    font-weight: bold;
    position: absolute;
    font-family: sans-serif;
    top: 25px;
    cursor: pointer;
}
.parag{
    margin: 0;
    color: black;
    font-weight: 600;
    position: relative;
}
.btnminusbenefist_minus{
    font-size: 50px;
    color: #12b712;
    font-weight: bold;
    font-family: sans-serif;
    cursor: pointer;
    width: 35px;
    position: absolute;
    top: -27px;

}
.btnanotherbenefit_plus{
    font-size: 30px;
    /* border: 1px solid; */
    color: #aad9aa;
    font-weight: bold;
    position: absolute;
    font-family: sans-serif;
    top: 5px;
    cursor: pointer;
}
.btnanotherbenefit_plus:hover{
color: #12b712;
}
.btnanotherbenefit{
    width: 100%;
        border: 1px solid #a79696;
    border-radius: 0;
    color: #a79696;
}
.btnanotherbenefit:hover{
    width: 100%;
        border: 1px solid black;
    border-radius: 0;
    color: black;
}
.proc_identity{
    color: grey;
    font-size: 13px;
}
.data_unq_code{
    position: absolute;
    top: 23px;
    font-size: 20px;
    font-weight: 700;
    left: -50px;
}
.btn_close_modal{
        padding: 12px;
    border-radius: 100px;
    width: 50px;
    height: 50px;
}
.btn_close_modal_remove_ben_risk{
    padding: 12px;
    border-radius: 100px;
    width: 50px;
    height: 50px; 
}

.btn_close_modal_another_ben_risk{
    padding: 12px;
    border-radius: 100px;
    width: 50px;
    height: 50px; 
}
.btn_close_modal_another_risk_risk{
    padding: 12px;
    border-radius: 100px;
    width: 50px;
    height: 50px; 
}
.btn_new_proc_benrisk_plus{
    font-size: 30px;
    /* border: 1px solid; */
    color: #aad9aa;
    font-weight: bold;
    position: absolute;
    font-family: sans-serif;
    top: 35px;
    cursor: pointer;
}
.btn_new_proc_benrisk_plus:hover{
color: #12b712;
}

.temp_save_new_bene{
    background: #33a8de1f;
    padding: 10px;
    border-radius: 10px;
    position: relative;
    box-shadow: 0 3px 6px rgba(0,0,0,0.16), 0 3px 6px rgba(0,0,0,0.23);
}
.temp_save_new_bene p{
    margin: 0;
}
.temp_save_new_bene i{
    position: absolute;
    color: red;
    top: 0;
    right: 10px;
    cursor: pointer;
}

.sep_temp_save_new_bene{
    background: #33a8de1f;
    padding: 10px;
    border-radius: 10px;
    position: relative;
    box-shadow: 0 3px 6px rgba(0,0,0,0.16), 0 3px 6px rgba(0,0,0,0.23);
}
.sep_temp_save_new_bene p{
    margin: 0;
}
.sep_temp_save_new_bene i{
    position: absolute;
    color: red;
    top: 0;
    right: 10px;
    cursor: pointer;
}

.sep_temp_save_new_risk{
    background: #33a8de1f;
    padding: 10px;
    border-radius: 10px;
    position: relative;
    box-shadow: 0 3px 6px rgba(0,0,0,0.16), 0 3px 6px rgba(0,0,0,0.23);
}
.sep_temp_save_new_risk p{
    margin: 0;
}
.sep_temp_save_new_risk i{
    position: absolute;
    color: red;
    top: 0;
    right: 10px;
    cursor: pointer;
}
.p_existing_ben_ask{
    text-align: center;
    color: #2b2f2b;
    cursor: pointer;
    text-decoration: underline;
    font-family: monospace;
    margin-top: 10px;
}
.p_existing_ben_ask:hover{
color: green;
}

.temp_save_new_risk{
    background: #33a8de1f;
    padding: 10px;
    border-radius: 10px;
    position: relative;
    box-shadow: 0 3px 6px rgba(0,0,0,0.16), 0 3px 6px rgba(0,0,0,0.23);
}
.temp_save_new_risk p{
    margin: 0;
}
.temp_save_new_risk i{
    position: absolute;
    color: red;
    top: 0;
    right: 10px;
    cursor: pointer;
}
.p_existing_risk_ask{
    text-align: center;
    color: #2b2f2b;
    cursor: pointer;
    text-decoration: underline;
    font-family: monospace;
    margin-top: 10px;
}
.p_existing_risk_ask:hover{
color: green;
}
</style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.css" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<div class="container" style="min-height:530px;">
    <div class="row justify-content-center">
        <div class="col-md-7">
            <h3 class="pageheading mb-4">Consent for surgical procedure</h3>
            <div class="parentprocedure">
            </div>
                        <div class="row">
                            <div class="col-md-11 mb-3 mt-3">
                                <input type="text" class="form-control btnanotherproc" id="btnanotherproc" placeholder="type here procedure">
                                
                            </div>
                            <div class="col-md-1 mb-3 p-0" style="position:relative;">
                                <span class="btnanotherproc_classaddremove btnanotherproc_plus"><i class="icon_plus_btnanotherproc fa fa-plus"></i></span>
                            </div>
                        </div>
        </div>
    </div>

    <div class="row super_parentbenefit" style="display:none;">
        <h3 class="smallheading p-0">Benefits:</h3>
        <div class="col-md-12 parentbenefit">
        </div>
                            <div class="col-md-6 mb-3">
                                <a href="javascript:void(0);" class="btn btnanotherbenefit_plus_click btnanotherbenefit">Add another benefit</a>
                                
                            </div>
                            <div class="col-md-2 mb-3 p-0" style="position:relative;">
                                <span class="btnanotherbenefit_plus_click btnanotherbenefit_plus"><i class="fa fa-plus"></i></span>
                            </div>
                        </div>

                        <div class="row super_parentrisk" style="display:none;">
        <h3 class="smallheading p-0">Risks:</h3>
        <div class="col-md-12 parentrisk">
        
        </div>
                            <div class="col-md-6 mb-3">
                                <a href="javascript:void(0);" class="btn btnanotherrisk_plus_click btnanotherbenefit">Add another risks</a>
                                
                            </div>
                            <div class="col-md-2 mb-3 p-0" style="position:relative;">
                                <span class="btnanotherrisk_plus_click btnanotherbenefit_plus"><i class="fa fa-plus"></i></span>
                            </div>
                        </div>

    

</div>



<!-- procedure another -->
<!-- Modal -->
    <div class="modal fade zoomIn" id="loginModal" tabindex="-1" data-bs-keyboard="false" data-bs-backdrop="static" aria-hidden="true" role="dialog">
          <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content" style="    background: transparent;
    border: none;">
                <div class="modal-body">
                <div class="loginmodal-container">
                    <h3 class="pageheading mb-4">Login to Your Account</h3><br>
                  <form method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo csrf_field(); ?>
                    <input id="email" type="email" class=" <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>

                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <input id="password" type="password" class=" <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password">

                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <input type="submit" name="login" class="login loginmodal-submit" value="Login">
                  </form>
                    
                  <div class="login-help">
                    <?php if(Route::has('password.request')): ?>
                                    <a href="<?php echo e(route('password.request')); ?>">
                                        <?php echo e(__('Forgot Your Password?')); ?>

                                    </a>
                                <?php endif; ?>
                    <!-- <a href="#">Forgot Password</a> -->
                  </div>
                </div>
                </div>
                </div>
            </div>
          </div>

 <div class="container mb-2">
 <div class="row justify-content-center">
        <div class="col-md-2">
            <button class="btn btnsubmit btnsubmit_procedure_all">SUBMIT</button>
        </div>
    </div>
    </div>
<footer class="footer text-center text-white" style="background-color: #f1f1f1;">

  <!-- Copyright -->
  <div class="text-center text-dark p-3" style="background-color: rgba(0, 0, 0, 0.2);">
    © 2023 Copyright:
    <a class="text-dark" style="text-transform:uppercase;" href="https://surgeryconsent.com.au/">Surgery Consent Companion</a>
  </div>
  <!-- Copyright -->
</footer>

<!-- new procedure modal -->
<div class="modal fade zoomIn" id="newProc_Modal" tabindex="-1" data-bs-keyboard="false" data-bs-backdrop="static" aria-hidden="true" role="dialog">
          <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-header">
        <h4 class="modal-title">Add New Procedure</h4>
      </div>
      <form method="POST" action="<?php echo e(url('submit_new_procedure')); ?>" id="new_procedure_form">
        <?php echo csrf_field(); ?>
                <div class="modal-body" style="height: 600px;
    overflow-y: scroll;">
                <div class="row">
                            <div class="col-md-12">
                                <label for="new_procedure_input" class="form-label">Type New Procedure</label>
                                <input name="new_procedure_input" id="new_procedure_input" type="text" required class="form-control input">
                            </div>
                            </div>

                            <!-- benefit -->
                            <div class="add_new_proc_bene_parent mt-3" style="border: 1px solid #ccc;
    border-radius: 10px;
    padding: 10px;
    margin: 0;">
    <div class="col-md-12">
                            <h3 class="smallheading p-0" style="text-align: center;
    font-weight: bold;
    font-size: 20px;
    text-decoration: underline;">Benefits:</h3>
                            </div>
        <div class="row temp_save_new_bene_parent mb-3">
          
        </div>

                            <div class="row add_new_proc_bene_single">
                            <div class="col-md-6">
                                <label class="form-label">Benefit Name</label>
                                <input name="new_benefit_code_input[]" type="hidden" class="new_benefit_code_input form-control input">
                                <input name="new_benefit_name_input[]" type="text" class="new_benefit_name_input form-control input">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Benefit Statistics</label>
                                <input name="new_benefit_statistics_input[]" type="text" class="new_benefit_statistics_input form-control input">
                            </div>
                            <div class="col-md-11 mt-2">
                                <label class="form-label">Benefit Detail</label>
                                <input name="new_benefit_detail_input[]" type="text" class="new_benefit_detail_input form-control input">
                            </div>
                            <div class="col-md-1 mb-3 p-0" style="position:relative;">
                                <span class="btn_new_proc_ben_plus_click btn_new_proc_benrisk_plus"><i class="fa fa-plus"></i></span>
                            </div>
                            </div>
                            </div>
                            <!-- <p class="p_existing_ben_ask">if you want to use existing benefit's for this procedure.?</p> -->
                            <!-- benefit -->

                            <!-- risk -->
                            <div class="add_new_proc_risk_parent mt-3" style="border: 1px solid #ccc;
    border-radius: 10px;
    padding: 10px;
    margin: 0;">
    <div class="col-md-12">
                            <h3 class="smallheading p-0" style="text-align: center;
    font-weight: bold;
    font-size: 20px;
    text-decoration: underline;">Risks:</h3>
                            </div>
        <div class="row temp_save_new_risk_parent mb-3">
          
        </div>

                            <div class="row add_new_proc_risk_single">
                            <div class="col-md-6">
                                <label class="form-label">Risk Name</label>
                                <input name="new_risk_code_input[]" type="hidden" class="new_risk_code_input form-control input">
                                <input name="new_risk_name_input[]" type="text" class="new_risk_name_input form-control input">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Risk Statistics</label>
                                <input name="new_risk_statistics_input[]" type="text" class="new_risk_statistics_input form-control input">
                            </div>
                            <div class="col-md-11 mt-2">
                                <label class="form-label">Risk Detail</label>
                                <input name="new_risk_detail_input[]" type="text" class="new_risk_detail_input form-control input">
                            </div>
                            <div class="col-md-1 mb-3 p-0" style="position:relative;">
                                <span class="btn_new_proc_risk_plus_click btn_new_proc_benrisk_plus"><i class="fa fa-plus"></i></span>
                            </div>
                            </div>
                            </div>
                            <!-- <p class="p_existing_risk_ask">if you want to use existing risk's for this procedure.?</p> -->
                            <!-- risk -->

                           

                </div>
                 <div class="modal-footer">
        <button type="button" class="btn btn-danger btn_close_modal" data-dismiss="modal"><i class="fa fa-times"></i></button>
        <button type="submit" class="btn btnsubmit add_newproc_submit_btn">SUBMIT</button>
        <button type="button" class="btn btnsubmit add_newproc_submit_btn_loader" style="display:none;"><i class="fa fa-circle-o-notch fa-spin"></i></button>
      </div>
  </form>
                </div>
            </div>
          </div>
<!-- new procedure modal -->

<!-- remove benefi and risk modal -->
<div class="modal fade zoomIn" id="rembenrisk_Modal" tabindex="-1" data-bs-keyboard="false" data-bs-backdrop="static" aria-hidden="true" role="dialog">
          <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-header">
        <h4 class="modal-title">Remove <span class="modaltitle_rem_benrisk" style="text-transform:capitalize;"></span> (<span class="modaltitle_rem_benrisk_name"></span>)</h4>
      </div>
                <div class="modal-body rembenrisk_modalbody">
                </div>
                 <div class="modal-footer">
        <button type="button" class="btn btn-danger btn_close_modal_remove_ben_risk" data-dismiss="modal"><i class="fa fa-times"></i></button>
        <button type="button" class="btn btnsubmit rem_benrisk_btn">SUBMIT</button>
        <button type="button" class="btn btnsubmit rem_benrisk_btn_loader" style="display:none;"><i class="fa fa-circle-o-notch fa-spin"></i></button>
      </div>
                </div>
            </div>
          </div>
<!-- remove benefi and risk modal -->

<!-- add another benefit -->
<div class="modal fade zoomIn" id="anotherbenefit_Modal" tabindex="-1" data-bs-keyboard="false" data-bs-backdrop="static" aria-hidden="true" role="dialog">
          <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-header">
        <h4 class="modal-title">Add New Benefit</h4>
      </div>
      <form method="POST" action="<?php echo e(url('submit_new_benefit')); ?>" id="new_benefit_form">
        <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="fetch_procedure_another_benefit">
                        <p style="color: #2b2f2b;text-decoration: underline;font-family: monospace;margin-top: 10px;">please select atleast one procedure</p>
                        
                    </div>
                    <!-- benefit -->
                            <div class="sep_add_new_proc_bene_parent mt-3" style="border: 1px solid #ccc;
    border-radius: 10px;
    padding: 10px;
    margin: 0;">
    <div class="col-md-12">
                            <h3 class="smallheading p-0" style="text-align: center;
    font-weight: bold;
    font-size: 20px;
    text-decoration: underline;">Benefits:</h3>
                            </div>
        <div class="row sep_temp_save_new_bene_parent mb-3">
          
        </div>

                            <div class="row sep_add_new_proc_bene_single">
                            <div class="col-md-6">
                                <label class="form-label">Benefit Name</label>
                                <input name="sep_new_benefit_code_input[]" type="hidden" class="sep_new_benefit_code_input form-control input">
                                <input name="sep_new_benefit_name_input[]" type="text" class="sep_new_benefit_name_input form-control input">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Benefit Statistics</label>
                                <input name="sep_new_benefit_statistics_input[]" type="text" class="sep_new_benefit_statistics_input form-control input">
                            </div>
                            <div class="col-md-11 mt-2">
                                <label class="form-label">Benefit Detail</label>
                                <input name="sep_new_benefit_detail_input[]" type="text" class="sep_new_benefit_detail_input form-control input">
                            </div>
                            <div class="col-md-1 mb-3 p-0" style="position:relative;">
                                <span class="sep_btn_new_proc_ben_plus_click btn_new_proc_benrisk_plus"><i class="fa fa-plus"></i></span>
                            </div>
                            </div>
                            </div>
                            <!-- <p class="p_existing_ben_ask">if you want to use existing benefit's for this procedure.?</p> -->
                            <!-- benefit -->
                </div>
                 <div class="modal-footer">
        <button type="button" class="btn btn-danger btn_close_modal_another_ben_risk" data-dismiss="modal"><i class="fa fa-times"></i></button>
        <button type="submit" class="btn btnsubmit anotherbenefit_btn">SUBMIT</button>
        <button type="button" class="btn btnsubmit anotherbenefit_btn_loader" style="display:none;"><i class="fa fa-circle-o-notch fa-spin"></i></button>
      </div>
  </form>
                </div>
            </div>
          </div>
<!-- add another benefit -->

<!-- add another risk -->
<div class="modal fade zoomIn" id="anotherrisk_Modal" tabindex="-1" data-bs-keyboard="false" data-bs-backdrop="static" aria-hidden="true" role="dialog">
          <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-header">
        <h4 class="modal-title">Add New Risk</h4>
      </div>
      <form method="POST" action="<?php echo e(url('submit_new_risk')); ?>" id="new_risk_form">
        <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="fetch_procedure_another_risk">
                        <p style="color: #2b2f2b;text-decoration: underline;font-family: monospace;margin-top: 10px;">please select atleast one procedure</p>
                        
                    </div>
                    <!-- risk -->
                            <div class="sep_add_new_proc_risk_parent mt-3" style="border: 1px solid #ccc;
    border-radius: 10px;
    padding: 10px;
    margin: 0;">
    <div class="col-md-12">
                            <h3 class="smallheading p-0" style="text-align: center;
    font-weight: bold;
    font-size: 20px;
    text-decoration: underline;">Risks:</h3>
                            </div>
        <div class="row sep_temp_save_new_risk_parent mb-3">
          
        </div>

                            <div class="row sep_add_new_proc_risk_single">
                            <div class="col-md-6">
                                <label class="form-label">Risk Name</label>
                                <input name="sep_new_risk_code_input[]" type="hidden" class="sep_new_risk_code_input form-control input">
                                <input name="sep_new_risk_name_input[]" type="text" class="sep_new_risk_name_input form-control input">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Risk Statistics</label>
                                <input name="sep_new_risk_statistics_input[]" type="text" class="sep_new_risk_statistics_input form-control input">
                            </div>
                            <div class="col-md-11 mt-2">
                                <label class="form-label">Risk Detail</label>
                                <input name="sep_new_risk_detail_input[]" type="text" class="sep_new_risk_detail_input form-control input">
                            </div>
                            <div class="col-md-1 mb-3 p-0" style="position:relative;">
                                <span class="sep_btn_new_proc_risk_plus_click btn_new_proc_benrisk_plus"><i class="fa fa-plus"></i></span>
                            </div>
                            </div>
                            </div>
                            <!-- <p class="p_existing_ben_ask">if you want to use existing risk's for this procedure.?</p> -->
                            <!-- risk -->
                </div>
                 <div class="modal-footer">
        <button type="button" class="btn btn-danger btn_close_modal_another_risk_risk" data-dismiss="modal"><i class="fa fa-times"></i></button>
        <button type="submit" class="btn btnsubmit anotherrisk_btn">SUBMIT</button>
        <button type="button" class="btn btnsubmit anotherrisk_btn_loader" style="display:none;"><i class="fa fa-circle-o-notch fa-spin"></i></button>
      </div>
  </form>
                </div>
            </div>
          </div>
<!-- add another risk -->
<?php echo $__env->make('print', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
<?php if(auth()->guard()->guest()): ?>
<script type="text/javascript">
    $(document).ready(function () {
    setTimeout(function(){
    $('#loginModal').modal('show');
    $('.spiinerdiv').hide();
    },2000)
});
</script>
<?php else: ?>
<?php endif; ?>
<script type="text/javascript">
var array_surgery_ben = [];
var array_surgery_risk = [];
var procedure_code_array = [];
var array_surgery_parent = [];
var procedure_codes=[];

function groupBy(array, key) {
  return array.reduce((result, obj) => {
    const keyValue = obj[key];
    if (!result[keyValue]) {
      result[keyValue] = [];
    }
    result[keyValue].push(obj);
    return result;
  }, {});
}

    $(document).on('click','.btnanotherbenefit_plus_click',function(){
        $('#anotherbenefit_Modal').modal('show');
    });
    $(document).on('click','.btn_close_modal_another_ben_risk',function(){
        $('#anotherbenefit_Modal').modal('hide');
    });

    $(document).on('click','.btnanotherrisk_plus_click',function(){
        $('#anotherrisk_Modal').modal('show');
    });
    $(document).on('click','.btn_close_modal_another_risk_risk',function(){
        $('#anotherrisk_Modal').modal('hide');
    });
    $(document).on('click','.btn_close_modal',function(){
        $('#newProc_Modal').modal('hide');
    });
    $(document).on('click','.btn_close_modal_remove_ben_risk',function(){
        $('#rembenrisk_Modal').modal('hide');
    });
    $(document).on('keyup','#btnanotherproc',function(event){
        // alert('f')
        var proc_val = $( "#btnanotherproc" ).val();
        if(event.keyCode == 13) {
            if(proc_val == 'No Procedure Found'){

            }
            else{
            $('.btnanotherproc_plus').click();
            }
        }
        else{
        $( this ).attr('data-id','');
        }
    });
$(document).on('click','.btnanotherproc_plus',function(){
    var proc_val = $( "#btnanotherproc" ).val();
    var proc_id = $( "#btnanotherproc" ).attr('data-id');
    if(proc_val == ''){ 
        $( "#btnanotherproc" ).focus();
    }
    else{
        $('.btnanotherproc_classaddremove').removeClass('btnanotherproc_plus')
        $('.icon_plus_btnanotherproc').removeClass('fa-plus')
    $('.icon_plus_btnanotherproc').addClass('fa-circle-o-notch fa-spin')
        if (proc_id == '') {
            $('#new_procedure_input').val(proc_val)
    $('.btnanotherproc_classaddremove').addClass('btnanotherproc_plus')
                $('.icon_plus_btnanotherproc').removeClass('fa-circle-o-notch fa-spin')
    $('.icon_plus_btnanotherproc').addClass('fa-plus')
                $( "#btnanotherproc" ).val('');
                $( "#btnanotherproc" ).attr('data-id','');
    $('#newProc_Modal').modal('show')
}
else{
var path_get_procedure = "<?php echo e(url('fetch_procedure')); ?>";
    $.ajax({
            url: path_get_procedure,
            type: 'GET',
            dataType: "json",
            data: {
               proc_id: proc_id
            },
            success: function( data ) { 
                // console.log(data)
                if(procedure_code_array.find((element) => element == data.procedure.procedure_code)){
                    alert('procedure already exist')
                     $('.btnanotherproc_classaddremove').addClass('btnanotherproc_plus')
                $('.icon_plus_btnanotherproc').removeClass('fa-circle-o-notch fa-spin')
    $('.icon_plus_btnanotherproc').addClass('fa-plus')
                $( "#btnanotherproc" ).val('');
                $( "#btnanotherproc" ).attr('data-id','');
                    }
                    else{
                var in_html_sep_ben = '<div class="row sepben_option_row" data-id="'+data.procedure.procedure_code+'">'+
                            '<div class="col-md-12">';
      in_html_sep_ben += '<div class="form-check">'+
      '<input type="radio" class="form-check-input sepben_option" id="check'+data.procedure.procedure_code+'" name="sepben_option[]" value="'+data.procedure.id+'">'+
      '<label class="form-check-label" for="check'+data.procedure.procedure_code+'">'+data.procedure.procedure_code+'</label>'+
    '</div>';
                            in_html_sep_ben += '</div></div>';
                        $('.fetch_procedure_another_benefit').append(in_html_sep_ben);
                        var in_html_sep_risk = '<div class="row seprisk_option_row" data-id="'+data.procedure.procedure_code+'">'+
                            '<div class="col-md-12">';
      in_html_sep_risk += '<div class="form-check">'+
      '<input type="radio" class="form-check-input seprisk_option" id="check'+data.procedure.procedure_code+'" name="seprisk_option[]" value="'+data.procedure.id+'">'+
      '<label class="form-check-label" for="check'+data.procedure.procedure_code+'">'+data.procedure.procedure_code+'</label>'+
    '</div>';
                            in_html_sep_risk += '</div></div>';
                        $('.fetch_procedure_another_risk').append(in_html_sep_risk);
                procedure_code_array.push(data.procedure.procedure_code)
                // console.log(procedure_code_array)
                array_surgery_parent.push(data);
                // window.ar = array_surgery_parent;
                // console.log(array_surgery_parent)
                for (var i = 0; i < data.benefit.length; i++) {
                var array_surgery_child_ben = new Object();
                array_surgery_child_ben.procedure_code = data.procedure.procedure_code;
                array_surgery_child_ben.procedure_name = data.procedure.procedure_name;
                array_surgery_child_ben.benefit_code = data.benefit[i].code;
                array_surgery_child_ben.benefit_name = data.benefit[i].benefit_name;
                array_surgery_child_ben.benefit_statistics = data.benefit[i].statistics;
                array_surgery_child_ben.benefit_detail = data.benefit[i].detail;
                array_surgery_ben.push(array_surgery_child_ben);
            }
            for (var i = 0; i < data.risk.length; i++) {
                var array_surgery_child_risk = new Object();
                array_surgery_child_risk.procedure_code = data.procedure.procedure_code;
                array_surgery_child_risk.procedure_name = data.procedure.procedure_name;
                array_surgery_child_risk.risk_code = data.risk[i].code;
                array_surgery_child_risk.risk_name = data.risk[i].risk_name;
                array_surgery_child_risk.risk_statistics = data.risk[i].statistics;
                array_surgery_child_risk.risk_detail = data.risk[i].detail;
                array_surgery_risk.push(array_surgery_child_risk);
            }
                
                const result_ben = groupBy(array_surgery_ben, 'benefit_code');
                // var result_ben = Object.groupBy(array_surgery_ben, ({ benefit_code }) => benefit_code);
                array_surgery_ben['benefit'] = result_ben;
                // alert(data.procedure.procedure_code);
                // console.log('resl benfit', result_ben)
                // var result_risk = Object.groupBy(array_surgery_risk, ({ risk_code }) => risk_code);
                const result_risk = groupBy(array_surgery_risk, 'risk_code');
                array_surgery_risk['risk'] = result_risk;
                // console.log('resl risk', result_risk)
                riskben_fetch(array_surgery_ben,array_surgery_risk);
              var in_html_proc = '<div class="row singleproc">'+
                            '<div class="col-md-2" style="position:relative;">'+
                            '<span class="data_unq_code">'+data.procedure.procedure_code+'</span>'+
                                '<label for="side" class="form-label">Side</label>'+
                                '<input name="side" type="text" required class="side form-control input <?php $__errorArgs = ['side'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">'+
                            '</div>'+
                            '<div class="col-md-2">'+
                                '<label for="site" class="form-label">Site</label>'+
                                '<input name="site" type="text" required class="site form-control input <?php $__errorArgs = ['site'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">'+
                            '</div>'+
                            '<div class="col-md-7">'+
                                '<label for="procedureseach" class="form-label">Procedure</label>'+
                                '<input name="procedure" type="text" required id="procedureseach" class="procedureseach form-control input <?php $__errorArgs = ['procedure'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="'+data.procedure.procedure_name+'" readonly>'+
                            '</div>'+
                            '<div class="col-md-1 mb-3 p-0" style="position:relative;">'+
                                '<span class="btnprocedure_minus" data-id="'+data.procedure.procedure_code+'"><i class="fa fa-minus"></i></span>'+
                            '</div>'+
                        '</div>';
        $('.parentprocedure').append(in_html_proc);
         $('.btnanotherproc_classaddremove').addClass('btnanotherproc_plus')
                $('.icon_plus_btnanotherproc').removeClass('fa-circle-o-notch fa-spin')
    $('.icon_plus_btnanotherproc').addClass('fa-plus')
                $( "#btnanotherproc" ).val('');
                $( "#btnanotherproc" ).attr('data-id','');
                $('.super_parentbenefit').show();
                $('.super_parentrisk').show();
            }
            },
             error: function(err) {
                 alert('err')
            console.log(err)
        }
          });
}
    }
})

 $(document).on('click','.rem_benrisk_btn',function(){
    var cat = $(this).attr('data-cat');
    var id = $(this).attr('data-id');
    if($('.rembenrisk_option:checked').length == 0){
        alert('please atleast one procedure')
    }
    else{
        $('.rem_benrisk_btn').hide();
        $('.rem_benrisk_btn_loader').show();
    if(cat == 'benefit'){
        $('.rembenrisk_option:checked').each(function(){
            var procedureCodeToRemove = $(this).val();
    array_surgery_ben = $.grep(array_surgery_ben, function(item) {
    return item.benefit_code !== id || item.procedure_code !== procedureCodeToRemove;
    });
    // var result_ben = Object.groupBy(array_surgery_ben, ({ benefit_code }) => benefit_code);
    const result_ben = groupBy(array_surgery_ben, 'benefit_code');
    array_surgery_ben['benefit'] = result_ben;
    riskben_fetch(array_surgery_ben,array_surgery_risk)
    $('.rem_benrisk_btn').show();
        $('.rem_benrisk_btn_loader').hide();
        $('#rembenrisk_Modal').modal('hide');
})
    }
    else{
$('.rembenrisk_option:checked').each(function(){
            var procedureCodeToRemove = $(this).val();
    array_surgery_risk = $.grep(array_surgery_risk, function(item) {
    return item.risk_code !== id || item.procedure_code !== procedureCodeToRemove;
    });
    // var result_risk = Object.groupBy(array_surgery_risk, ({ risk_code }) => risk_code);
    const result_risk = groupBy(array_surgery_risk, 'risk_code');
    array_surgery_risk['risk'] = result_risk;
    riskben_fetch(array_surgery_ben,array_surgery_risk)
    $('.rem_benrisk_btn').show();
        $('.rem_benrisk_btn_loader').hide();
        $('#rembenrisk_Modal').modal('hide');
})
    }
}
 });
 $(document).on('click','.btnminusbenrisk_click',function(){
    var cat = $(this).attr('data-cat');
    var id = $(this).attr('data-id');
    var procid = $(this).attr('data-procid');
    var name = $(this).attr('data-name');
    $('.rem_benrisk_btn').attr('data-id',id)
    $('.rem_benrisk_btn').attr('data-cat',cat)
    $('.modaltitle_rem_benrisk').text(cat)
    $('.modaltitle_rem_benrisk_name').text(name)
    var in_html_rembenrisk = '<div class="row">'+
                            '<div class="col-md-12">'+
                            '<p style="color: #2b2f2b;text-decoration: underline;font-family: monospace;margin-top: 10px;">please select atleast one procedure</p>';
    var array = procid.split(",");
for (var i in array){
      in_html_rembenrisk += '<div class="form-check">'+
      '<input type="checkbox" class="form-check-input rembenrisk_option" id="check'+array[i]+'" name="option'+array[i]+'" value="'+array[i]+'">'+
      '<label class="form-check-label" for="check'+array[i]+'">'+array[i]+'</label>'+
    '</div>';
}
                            in_html_rembenrisk += '</div></div>';
    $('.rembenrisk_modalbody').html(in_html_rembenrisk)
    $('#rembenrisk_Modal').modal('show');
    // console.log(array_surgery_parent)
    // console.log(array_surgery_ben)
   // var benefitCodeToRemove = "RP-002"; // The benefit_code to remove
    // var procedureCodeToRemove = "P-966"; // The procedure_code to remove

   // array_surgery_ben = $.grep(array_surgery_ben, function(item) {
   //  return item.benefit_code !== benefitCodeToRemove || item.procedure_code !== procedureCodeToRemove;
   //  });
   // var result_ben = Object.groupBy(array_surgery_ben, ({ benefit_code }) => benefit_code);
   //  array_surgery_ben['benefit'] = result_ben;
// array_surgery_ben['benefit'] = result_ben;
// console.log(array_surgery_ben)
// riskben_fetch(array_surgery_ben,array_surgery_risk)
 });
 $(document).on('click','.btnprocedure_minus',function(){
    var proc_code = $(this).attr('data-id');
    $('.sepben_option_row[data-id='+proc_code+']').remove();
    $('.seprisk_option_row[data-id='+proc_code+']').remove();
    var index = procedure_code_array.findIndex((element) => element == proc_code);
    procedure_code_array.splice(index);

    var procedureCodeToRemove = proc_code; // The procedure_code you want to remove

// Find and remove the object with the specified "procedure_code"
array_surgery_parent = array_surgery_parent.filter(function (obj) {
    return obj.procedure.procedure_code !== procedureCodeToRemove;
});
var data = array_surgery_parent;
array_surgery_ben = [];
array_surgery_risk = [];
for (var id = 0; id < data.length; id++) {
for (var i = 0; i < data[id].benefit.length; i++) {
                var array_surgery_child_ben = new Object();
                array_surgery_child_ben.procedure_code = data[id].procedure.procedure_code;
                array_surgery_child_ben.procedure_name = data[id].procedure.procedure_name;
                array_surgery_child_ben.benefit_code = data[id].benefit[i].code;
                array_surgery_child_ben.benefit_name = data[id].benefit[i].benefit_name;
                array_surgery_child_ben.benefit_statistics = data[id].benefit[i].statistics;
                array_surgery_child_ben.benefit_detail = data[id].benefit[i].detail;
                array_surgery_ben.push(array_surgery_child_ben);
            }
            for (var i = 0; i < data[id].risk.length; i++) {
                var array_surgery_child_risk = new Object();
                array_surgery_child_risk.procedure_code = data[id].procedure.procedure_code;
                array_surgery_child_risk.procedure_name = data[id].procedure.procedure_name;
                array_surgery_child_risk.risk_code = data[id].risk[i].code;
                array_surgery_child_risk.risk_name = data[id].risk[i].risk_name;
                array_surgery_child_risk.risk_statistics = data[id].risk[i].statistics;
                array_surgery_child_risk.risk_detail = data[id].risk[i].detail;
                array_surgery_risk.push(array_surgery_child_risk);
            }
        }
                // var result_ben = Object.groupBy(array_surgery_ben, ({ benefit_code }) => benefit_code);
                const result_ben = groupBy(array_surgery_ben, 'benefit_code');
                array_surgery_ben['benefit'] = result_ben;
                // console.log('resl benfit', result_ben)
                // var result_risk = Object.groupBy(array_surgery_risk, ({ risk_code }) => risk_code);
                const result_risk = groupBy(array_surgery_risk, 'risk_code');
                array_surgery_risk['risk'] = result_risk;
                // console.log('resl risk', result_risk)
                riskben_fetch(array_surgery_ben,array_surgery_risk)
    // console.log(array_surgery_parent)
    if(data.length == 0){
        $('.super_parentbenefit').hide();
                $('.super_parentrisk').hide();
    }
        $(this).closest('.singleproc').remove();
    });


var path = "<?php echo e(url('procedure_autocomplete')); ?>";
    function autocomp(){
    $( "#btnanotherproc" ).each(function(){
    $(this).autocomplete({
         autoFocus: true,
        source: function( request, response ) {
          $.ajax({
            url: path,
            type: 'GET',
            dataType: "json",
            data: {
               search: request.term
            },
            success: function( data ) {
                // console.log(data)
                if (data.length === 0) {
 var result = [
            {
                label: 'No Procedure Found', 
                value: response.term
            }
        ];
        response(result);
}
else{
               response( data );
}

            }
          });
        },
        select: function (event, ui) {
            // alert('ffffffff')
            if(ui.item.label == 'No Procedure Found'){

            }
            else{
           $(this).val(ui.item.label);
           $(this).attr('data-id',ui.item.id);
           $('.btnanotherproc_plus').click();
       }
           // console.log(ui.item); 
           return false;
        }
      });
  });
}
autocomp();

function riskben_fetch(ben_res,risk_res){
    $('.parentbenefit').html('');
    $('.parentrisk').html('');
    $('.A4_benefit_fetch').html('');
    $('.A4_risk_fetch').html('');
    var count = 0;
    $.each( ben_res.benefit, function( key, value ) {
    count = count + 1;

    var proce_ben = '';
  for (var ib = 0; ib < value.length; ib++) {
    proce_ben += value[ib].procedure_code+',';
  }
  proce_ben = proce_ben.slice(0, -1);
        var in_html_ben = ' <p class="parag">'+count+'. '+value[0].benefit_name+' – '+value[0].benefit_detail+' <span class="proc_identity">('+proce_ben+')</span> <span class="btnminusbenrisk_click btnminusbenefist_minus" data-cat="benefit" data-id="'+value[0].benefit_code+'" data-procid="'+proce_ben+'" data-name="'+value[0].benefit_name+'">-</span></p>';
                    $('.parentbenefit').append(in_html_ben);
    var A4_benefit_fetch = '<tr><td>'+count+'</td> <td>'+value[0].benefit_name+'</td> <td>'+value[0].benefit_detail+'</td> <td>'+value[0].benefit_statistics+'</td> <td>'+proce_ben+'</td></tr>';
                    $('.A4_benefit_fetch').append(A4_benefit_fetch);
    
  // console.log('value',value.length)
});

    var count = 0;
    $.each( risk_res.risk, function( key, value ) {
    count = count + 1;

    var proce_risk = '';
  for (var ir = 0; ir < value.length; ir++) {
    proce_risk += value[ir].procedure_code+',';
  }
  proce_risk = proce_risk.slice(0, -1);
        var in_html_ben = ' <p class="parag">'+count+'. '+value[0].risk_name+' – '+value[0].risk_detail+' <span class="proc_identity">('+proce_risk+')</span> <span class="btnminusbenrisk_click btnminusbenefist_minus" data-cat="risk" data-id="'+value[0].risk_code+'" data-procid="'+proce_risk+'" data-name="'+value[0].risk_name+'">-</span></p>';
                    $('.parentrisk').append(in_html_ben);
                    var A4_risk_fetch = '<tr><td>'+count+'</td> <td>'+value[0].risk_name+'</td> <td>'+value[0].risk_detail+'</td> <td>'+value[0].risk_statistics+'</td> <td>'+proce_risk+'</td></tr>';
                    $('.A4_risk_fetch').append(A4_risk_fetch);
    
  // console.log('value',value.length)
});
    // console.log(ben_res)
    // console.log(risk_res.risk)
}
 
    $('#btnanotherproc').on('autocompleteselect', function (e, ui) {
        if(ui.item.label == 'No Procedure Found'){

            }
            else{
           $('#btnanotherproc').val(ui.item.label);
           $('#btnanotherproc').attr('data-id',ui.item.id);
       }
    });


// add new procedure
    $(document).on('click','.btn_new_proc_ben_plus_click',function(){
var new_benefit_name_input = $(this).parents('.add_new_proc_bene_single').find('.new_benefit_name_input').val();
var new_benefit_statistics_input = $(this).parents('.add_new_proc_bene_single').find('.new_benefit_statistics_input').val();
var new_benefit_detail_input = $(this).parents('.add_new_proc_bene_single').find('.new_benefit_detail_input').val();
if(new_benefit_name_input == ''){
$(this).parents('.add_new_proc_bene_single').find('.new_benefit_name_input').focus();
}
else if(new_benefit_statistics_input == ''){
$(this).parents('.add_new_proc_bene_single').find('.new_benefit_statistics_input').focus();
}
else if(new_benefit_detail_input == ''){
   $(this).parents('.add_new_proc_bene_single').find('.new_benefit_detail_input').focus(); 
}
else{
$(this).parents('.add_new_proc_bene_single').attr('data-name',new_benefit_name_input);
$(this).parents('.add_new_proc_bene_single').hide();
var new_benefit_detail_input_limit = new_benefit_detail_input.slice(0, 20)+'...';
var in_html_ben_new = '<div class="col-md-4 temp_save_new_bene_single mt-2">'+
              '<div class="temp_save_new_bene">'+
                  '<p style="font-weight:bold;">'+new_benefit_name_input+'</p>'+
                  '<p>'+new_benefit_detail_input_limit+'</p>'+
                  '<i class="fa fa-times close_temp_save_new_bene_single" data-id="'+new_benefit_name_input+'"></i>'+
              '</div>'+
          '</div>';
 $('.temp_save_new_bene_parent').append(in_html_ben_new);
var in_html_proc_new = '<div class="row add_new_proc_bene_single" data-id="'+new_benefit_name_input+'">'+
                            '<div class="col-md-6">'+
                                '<label class="form-label">Benefit Name</label>'+
                                '<input name="new_benefit_code_input[]" type="hidden" class="new_benefit_code_input form-control input">'+
                                '<input name="new_benefit_name_input[]" type="text" class="new_benefit_name_input form-control input">'+
                            '</div>'+
                            '<div class="col-md-6">'+
                                '<label class="form-label">Benefit Statistics</label>'+
                                '<input name="new_benefit_statistics_input[]" type="text" class="new_benefit_statistics_input form-control input">'+
                            '</div>'+
                            '<div class="col-md-11 mt-2">'+
                                '<label class="form-label">Benefit Detail</label>'+
                                '<input name="new_benefit_detail_input[]" type="text" class="new_benefit_detail_input form-control input">'+
                            '</div>'+
                            '<div class="col-md-1 mb-3 p-0" style="position:relative;">'+
                                '<span class="btn_new_proc_ben_plus_click btn_new_proc_benrisk_plus"><i class="fa fa-plus"></i></span>'+
                            '</div>'+
                            '</div>';
        $('.add_new_proc_bene_parent').append(in_html_proc_new);
    }
    });

    $(document).on('click','.btn_new_proc_risk_plus_click',function(){
var new_risk_name_input = $(this).parents('.add_new_proc_risk_single').find('.new_risk_name_input').val();
var new_risk_statistics_input = $(this).parents('.add_new_proc_risk_single').find('.new_risk_statistics_input').val();
var new_risk_detail_input = $(this).parents('.add_new_proc_risk_single').find('.new_risk_detail_input').val();
if(new_risk_name_input == ''){
$(this).parents('.add_new_proc_risk_single').find('.new_risk_name_input').focus();
}
else if(new_risk_statistics_input == ''){
$(this).parents('.add_new_proc_risk_single').find('.new_risk_statistics_input').focus();
}
else if(new_risk_detail_input == ''){
   $(this).parents('.add_new_proc_risk_single').find('.new_risk_detail_input').focus(); 
}
else{
$(this).parents('.add_new_proc_risk_single').attr('data-name',new_risk_name_input);
$(this).parents('.add_new_proc_risk_single').hide();
var new_risk_detail_input_limit = new_risk_detail_input.slice(0, 20)+'...';
var in_html_risk_new = '<div class="col-md-4 temp_save_new_risk_single mt-2">'+
              '<div class="temp_save_new_risk">'+
                  '<p style="font-weight:bold;">'+new_risk_name_input+'</p>'+
                  '<p>'+new_risk_detail_input_limit+'</p>'+
                  '<i class="fa fa-times close_temp_save_new_risk_single" data-id="'+new_risk_name_input+'"></i>'+
              '</div>'+
          '</div>';
 $('.temp_save_new_risk_parent').append(in_html_risk_new);
var in_html_proc_new = '<div class="row add_new_proc_risk_single" data-id="'+new_risk_name_input+'">'+
                            '<div class="col-md-6">'+
                                '<label class="form-label">Risk Name</label>'+
                                '<input name="new_risk_code_input[]" type="hidden" class="new_risk_code_input form-control input">'+
                                '<input name="new_risk_name_input[]" type="text" class="new_risk_name_input form-control input">'+
                            '</div>'+
                            '<div class="col-md-6">'+
                                '<label class="form-label">Risk Statistics</label>'+
                                '<input name="new_risk_statistics_input[]" type="text" class="new_risk_statistics_input form-control input">'+
                            '</div>'+
                            '<div class="col-md-11 mt-2">'+
                                '<label class="form-label">Risk Detail</label>'+
                                '<input name="new_risk_detail_input[]" type="text" class="new_risk_detail_input form-control input">'+
                            '</div>'+
                            '<div class="col-md-1 mb-3 p-0" style="position:relative;">'+
                                '<span class="btn_new_proc_risk_plus_click btn_new_proc_benrisk_plus"><i class="fa fa-plus"></i></span>'+
                            '</div>'+
                            '</div>';
        $('.add_new_proc_risk_parent').append(in_html_proc_new);
    }
    });

    $('#new_procedure_form').submit(function(e) {
        e.preventDefault();
        $('.add_newproc_submit_btn').hide();
        $('.add_newproc_submit_btn_loader').show();
        let formData = new FormData(this);
        $.ajaxSetup({
          headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
      });
         $.ajax({
        // headers: {
        //     'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')
        // },
        url: $(this).attr('action'),
        type: $(this).attr('method'),
        data: formData,
         processData: false,
    contentType: false,
    cache: false,
        dataType: "json",
         success: function(data) {
            console.log(data);
            var in_html_sep_ben = '<div class="row sepben_option_row" data-id="'+data.procedure.procedure_code+'">'+
                            '<div class="col-md-12">';
      in_html_sep_ben += '<div class="form-check">'+
      '<input type="radio" class="form-check-input sepben_option" id="check'+data.procedure.procedure_code+'" name="sepben_option[]" value="'+data.procedure.id+'">'+
      '<label class="form-check-label" for="check'+data.procedure.procedure_code+'">'+data.procedure.procedure_code+'</label>'+
    '</div>';
                            in_html_sep_ben += '</div></div>';
                        $('.fetch_procedure_another_benefit').append(in_html_sep_ben);
                        var in_html_sep_risk = '<div class="row seprisk_option_row" data-id="'+data.procedure.procedure_code+'">'+
                            '<div class="col-md-12">';
      in_html_sep_risk += '<div class="form-check">'+
      '<input type="radio" class="form-check-input seprisk_option" id="check'+data.procedure.procedure_code+'" name="seprisk_option[]" value="'+data.procedure.id+'">'+
      '<label class="form-check-label" for="check'+data.procedure.procedure_code+'">'+data.procedure.procedure_code+'</label>'+
    '</div>';
                            in_html_sep_risk += '</div></div>';
                        $('.fetch_procedure_another_risk').append(in_html_sep_risk);
             procedure_code_array.push(data.procedure.procedure_code)
                // console.log(procedure_code_array)
                array_surgery_parent.push(data);
                // window.ar = array_surgery_parent;
                // console.log(array_surgery_parent)

                for (var i = 0; i < data.benefit.length; i++) {
                var array_surgery_child_ben = new Object();
                array_surgery_child_ben.procedure_code = data.procedure.procedure_code;
                array_surgery_child_ben.procedure_name = data.procedure.procedure_name;
                array_surgery_child_ben.benefit_code = data.benefit[i].code;
                array_surgery_child_ben.benefit_name = data.benefit[i].benefit_name;
                array_surgery_child_ben.benefit_statistics = data.benefit[i].statistics;
                array_surgery_child_ben.benefit_detail = data.benefit[i].detail;
                array_surgery_ben.push(array_surgery_child_ben);
            }
            for (var i = 0; i < data.risk.length; i++) {
                var array_surgery_child_risk = new Object();
                array_surgery_child_risk.procedure_code = data.procedure.procedure_code;
                array_surgery_child_risk.procedure_name = data.procedure.procedure_name;
                array_surgery_child_risk.risk_code = data.risk[i].code;
                array_surgery_child_risk.risk_name = data.risk[i].risk_name;
                array_surgery_child_risk.risk_statistics = data.risk[i].statistics;
                array_surgery_child_risk.risk_detail = data.risk[i].detail;
                array_surgery_risk.push(array_surgery_child_risk);
            }
                // var result_ben_new = Object.groupBy(array_surgery_ben, ({ benefit_code }) => benefit_code);
                const result_ben_new = groupBy(array_surgery_ben, 'benefit_code');
                array_surgery_ben['benefit'] = result_ben_new;
                console.log('resl benfit', result_ben_new)
                // var result_risk_new = Object.groupBy(array_surgery_risk, ({ risk_code }) => risk_code);
                const result_risk_new = groupBy(array_surgery_risk, 'risk_code');
                array_surgery_risk['risk'] = result_risk_new;
                console.log('resl risk', result_risk_new)
                riskben_fetch(array_surgery_ben,array_surgery_risk)
              var in_html_proc = '<div class="row singleproc">'+
                            '<div class="col-md-2" style="position:relative;">'+
                            '<span class="data_unq_code">'+data.procedure.procedure_code+'</span>'+
                                '<label for="side" class="form-label">Side</label>'+
                                '<input name="side" type="text" required class="side form-control input <?php $__errorArgs = ['side'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">'+
                            '</div>'+
                            '<div class="col-md-2">'+
                                '<label for="site" class="form-label">Site</label>'+
                                '<input name="site" type="text" required class="site form-control input <?php $__errorArgs = ['site'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">'+
                            '</div>'+
                            '<div class="col-md-7">'+
                                '<label for="procedureseach" class="form-label">Procedure</label>'+
                                '<input name="procedure" type="text" required id="procedureseach" class="procedureseach form-control input <?php $__errorArgs = ['procedure'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="'+data.procedure.procedure_name+'" readonly>'+
                            '</div>'+
                            '<div class="col-md-1 mb-3 p-0" style="position:relative;">'+
                                '<span class="btnprocedure_minus" data-id="'+data.procedure.procedure_code+'"><i class="fa fa-minus"></i></span>'+
                            '</div>'+
                        '</div>';
        $('.parentprocedure').append(in_html_proc);
        $('#newProc_Modal').modal('hide')
        $('.temp_save_new_bene_parent').html('')
        $('.temp_save_new_risk_parent').html('')
        $('.add_new_proc_risk_single').remove('')
        $('.add_new_proc_bene_single').remove('')
        var in_html_proc_new_risk = '<div class="row add_new_proc_risk_single">'+
                            '<div class="col-md-6">'+
                                '<label class="form-label">Risk Name</label>'+
                                '<input name="new_risk_code_input[]" type="hidden" class="new_risk_code_input form-control input">'+
                                '<input name="new_risk_name_input[]" type="text" class="new_risk_name_input form-control input">'+
                            '</div>'+
                            '<div class="col-md-6">'+
                                '<label class="form-label">Risk Statistics</label>'+
                                '<input name="new_risk_statistics_input[]" type="text" class="new_risk_statistics_input form-control input">'+
                            '</div>'+
                            '<div class="col-md-11 mt-2">'+
                                '<label class="form-label">Risk Detail</label>'+
                                '<input name="new_risk_detail_input[]" type="text" class="new_risk_detail_input form-control input">'+
                            '</div>'+
                            '<div class="col-md-1 mb-3 p-0" style="position:relative;">'+
                                '<span class="btn_new_proc_risk_plus_click btn_new_proc_benrisk_plus"><i class="fa fa-plus"></i></span>'+
                            '</div>'+
                            '</div>';
        $('.add_new_proc_risk_parent').append(in_html_proc_new_risk);

        var in_html_proc_new_bene = '<div class="row add_new_proc_bene_single">'+
                            '<div class="col-md-6">'+
                                '<label class="form-label">Benefit Name</label>'+
                                '<input name="new_benefit_code_input[]" type="hidden" class="new_benefit_code_input form-control input">'+
                                '<input name="new_benefit_name_input[]" type="text" class="new_benefit_name_input form-control input">'+
                            '</div>'+
                            '<div class="col-md-6">'+
                                '<label class="form-label">Benefit Statistics</label>'+
                                '<input name="new_benefit_statistics_input[]" type="text" class="new_benefit_statistics_input form-control input">'+
                            '</div>'+
                            '<div class="col-md-11 mt-2">'+
                                '<label class="form-label">Benefit Detail</label>'+
                                '<input name="new_benefit_detail_input[]" type="text" class="new_benefit_detail_input form-control input">'+
                            '</div>'+
                            '<div class="col-md-1 mb-3 p-0" style="position:relative;">'+
                                '<span class="btn_new_proc_ben_plus_click btn_new_proc_benrisk_plus"><i class="fa fa-plus"></i></span>'+
                            '</div>'+
                            '</div>';
        $('.add_new_proc_bene_parent').append(in_html_proc_new_bene);
        $('.add_newproc_submit_btn').show();
        $('.add_newproc_submit_btn_loader').hide();
        $('.super_parentbenefit').show();
                $('.super_parentrisk').show();
        },
        error: function(err) {
            console.log(err)
        }
    });
    });

// add new benefit
    $(document).on('click','.sep_btn_new_proc_ben_plus_click',function(){
var sep_new_benefit_name_input = $(this).parents('.sep_add_new_proc_bene_single').find('.sep_new_benefit_name_input').val();
var sep_new_benefit_statistics_input = $(this).parents('.sep_add_new_proc_bene_single').find('.sep_new_benefit_statistics_input').val();
var sep_new_benefit_detail_input = $(this).parents('.sep_add_new_proc_bene_single').find('.sep_new_benefit_detail_input').val();
if(sep_new_benefit_name_input == ''){
$(this).parents('.sep_add_new_proc_bene_single').find('.sep_new_benefit_name_input').focus();
}
else if(sep_new_benefit_statistics_input == ''){
$(this).parents('.sep_add_new_proc_bene_single').find('.sep_new_benefit_statistics_input').focus();
}
else if(sep_new_benefit_detail_input == ''){
   $(this).parents('.sep_add_new_proc_bene_single').find('.sep_new_benefit_detail_input').focus(); 
}
else{
$(this).parents('.sep_add_new_proc_bene_single').attr('data-name',sep_new_benefit_name_input);
$(this).parents('.sep_add_new_proc_bene_single').hide();
var sep_new_benefit_detail_input_limit = sep_new_benefit_detail_input.slice(0, 20)+'...';
var sep_in_html_ben_new = '<div class="col-md-4 sep_temp_save_new_bene_single mt-2">'+
              '<div class="sep_temp_save_new_bene">'+
                  '<p style="font-weight:bold;">'+sep_new_benefit_name_input+'</p>'+
                  '<p>'+sep_new_benefit_detail_input_limit+'</p>'+
                  '<i class="fa fa-times close_sep_temp_save_new_bene_single" data-id="'+sep_new_benefit_name_input+'"></i>'+
              '</div>'+
          '</div>';
 $('.sep_temp_save_new_bene_parent').append(sep_in_html_ben_new);
var in_html_ben_new = '<div class="row sep_add_new_proc_bene_single" data-id="'+sep_new_benefit_name_input+'">'+
                            '<div class="col-md-6">'+
                                '<label class="form-label">Benefit Name</label>'+
                                '<input name="sep_new_benefit_code_input[]" type="hidden" class="sep_new_benefit_code_input form-control input">'+
                                '<input name="sep_new_benefit_name_input[]" type="text" class="sep_new_benefit_name_input form-control input">'+
                            '</div>'+
                            '<div class="col-md-6">'+
                                '<label class="form-label">Benefit Statistics</label>'+
                                '<input name="sep_new_benefit_statistics_input[]" type="text" class="sep_new_benefit_statistics_input form-control input">'+
                            '</div>'+
                            '<div class="col-md-11 mt-2">'+
                                '<label class="form-label">Benefit Detail</label>'+
                                '<input name="sep_new_benefit_detail_input[]" type="text" class="sep_new_benefit_detail_input form-control input">'+
                            '</div>'+
                            '<div class="col-md-1 mb-3 p-0" style="position:relative;">'+
                                '<span class="sep_btn_new_proc_ben_plus_click btn_new_proc_benrisk_plus"><i class="fa fa-plus"></i></span>'+
                            '</div>'+
                            '</div>';
        $('.sep_add_new_proc_bene_parent').append(in_html_ben_new);
    }
    });

    $('#new_benefit_form').submit(function(e) {
        e.preventDefault();
        if($('.sepben_option:checked').length == 0){
        alert('please atleast one procedure')
    }
    else{
        $('.anotherbenefit_btn').hide();
        $('.anotherbenefit_btn_loader').show();
        let formData = new FormData(this);
        $.ajaxSetup({
          headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
      });
         $.ajax({
        // headers: {
        //     'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')
        // },
        url: $(this).attr('action'),
        type: $(this).attr('method'),
        data: formData,
         processData: false,
    contentType: false,
    cache: false,
        dataType: "json",
         success: function(data) {

            // console.log(array_surgery_ben);
            console.log(data);
            for (var i = 0; i < data.benefit.length; i++) {
                var array_surgery_child_ben = new Object();
                array_surgery_child_ben.procedure_code = data.procedure.procedure_code;
                array_surgery_child_ben.procedure_name = data.procedure.procedure_name;
                array_surgery_child_ben.benefit_code = data.benefit[i].code;
                array_surgery_child_ben.benefit_name = data.benefit[i].benefit_name;
                array_surgery_child_ben.benefit_statistics = data.benefit[i].statistics;
                array_surgery_child_ben.benefit_detail = data.benefit[i].detail;
                array_surgery_ben.push(array_surgery_child_ben);
            }
                // var result_ben_new = Object.groupBy(array_surgery_ben, ({ benefit_code }) => benefit_code);
                const result_ben_new = groupBy(array_surgery_ben, 'benefit_code');
                array_surgery_ben['benefit'] = result_ben_new;
                riskben_fetch(array_surgery_ben,array_surgery_risk)
        
        $('.anotherbenefit_btn').show();
        $('.anotherbenefit_btn_loader').hide();
        $('#anotherbenefit_Modal').modal('hide')
        },
        error: function(err) {
            console.log(err)
        }
    });
     }
    });

// add new risk
    $(document).on('click','.sep_btn_new_proc_risk_plus_click',function(){
var sep_new_risk_name_input = $(this).parents('.sep_add_new_proc_risk_single').find('.sep_new_risk_name_input').val();
var sep_new_risk_statistics_input = $(this).parents('.sep_add_new_proc_risk_single').find('.sep_new_risk_statistics_input').val();
var sep_new_risk_detail_input = $(this).parents('.sep_add_new_proc_risk_single').find('.sep_new_risk_detail_input').val();
if(sep_new_risk_name_input == ''){
$(this).parents('.sep_add_new_proc_risk_single').find('.sep_new_risk_name_input').focus();
}
else if(sep_new_risk_statistics_input == ''){
$(this).parents('.sep_add_new_proc_risk_single').find('.sep_new_risk_statistics_input').focus();
}
else if(sep_new_risk_detail_input == ''){
   $(this).parents('.sep_add_new_proc_risk_single').find('.sep_new_risk_detail_input').focus(); 
}
else{
$(this).parents('.sep_add_new_proc_risk_single').attr('data-name',sep_new_risk_name_input);
$(this).parents('.sep_add_new_proc_risk_single').hide();
var sep_new_risk_detail_input_limit = sep_new_risk_detail_input.slice(0, 20)+'...';
var sep_in_html_risk_new = '<div class="col-md-4 sep_temp_save_new_risk_single mt-2">'+
              '<div class="sep_temp_save_new_risk">'+
                  '<p style="font-weight:bold;">'+sep_new_risk_name_input+'</p>'+
                  '<p>'+sep_new_risk_detail_input_limit+'</p>'+
                  '<i class="fa fa-times close_sep_temp_save_new_risk_single" data-id="'+sep_new_risk_name_input+'"></i>'+
              '</div>'+
          '</div>';
 $('.sep_temp_save_new_risk_parent').append(sep_in_html_risk_new);
var in_html_risk_new = '<div class="row sep_add_new_proc_risk_single">'+
                            '<div class="col-md-6">'+
                                '<label class="form-label">Risk Name</label>'+
                                '<input name="sep_new_risk_code_input[]" type="hidden" class="sep_new_risk_code_input form-control input">'+
                                '<input name="sep_new_risk_name_input[]" type="text" class="sep_new_risk_name_input form-control input">'+
                            '</div>'+
                            '<div class="col-md-6">'+
                                '<label class="form-label">Risk Statistics</label>'+
                                '<input name="sep_new_risk_statistics_input[]" type="text" class="sep_new_risk_statistics_input form-control input">'+
                            '</div>'+
                            '<div class="col-md-11 mt-2">'+
                                '<label class="form-label">Risk Detail</label>'+
                                '<input name="sep_new_risk_detail_input[]" type="text" class="sep_new_risk_detail_input form-control input">'+
                            '</div>'+
                            '<div class="col-md-1 mb-3 p-0" style="position:relative;">'+
                                '<span class="sep_btn_new_proc_risk_plus_click btn_new_proc_riskrisk_plus"><i class="fa fa-plus"></i></span>'+
                            '</div>'+
                            '</div>';
        $('.sep_add_new_proc_risk_parent').append(in_html_risk_new);
    }
    });

    $('#new_risk_form').submit(function(e) {
        e.preventDefault();
        if($('.seprisk_option:checked').length == 0){
        alert('please atleast one procedure')
    }
    else{
        $('.anotherrisk_btn').hide();
        $('.anotherrisk_btn_loader').show();
        let formData = new FormData(this);
        $.ajaxSetup({
          headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
      });
         $.ajax({
        // headers: {
        //     'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')
        // },
        url: $(this).attr('action'),
        type: $(this).attr('method'),
        data: formData,
         processData: false,
    contentType: false,
    cache: false,
        dataType: "json",
         success: function(data) {

            // console.log(array_surgery_risk);
            console.log(data);
            for (var i = 0; i < data.risk.length; i++) {
                var array_surgery_child_risk = new Object();
                array_surgery_child_risk.procedure_code = data.procedure.procedure_code;
                array_surgery_child_risk.procedure_name = data.procedure.procedure_name;
                array_surgery_child_risk.risk_code = data.risk[i].code;
                array_surgery_child_risk.risk_name = data.risk[i].risk_name;
                array_surgery_child_risk.risk_statistics = data.risk[i].statistics;
                array_surgery_child_risk.risk_detail = data.risk[i].detail;
                array_surgery_risk.push(array_surgery_child_risk);
            }
                // var result_risk_new = Object.groupBy(array_surgery_risk, ({ risk_code }) => risk_code);
                const result_risk_new = groupBy(array_surgery_risk, 'risk_code');
                array_surgery_risk['risk'] = result_risk_new;
                riskben_fetch(array_surgery_ben,array_surgery_risk)
        
        $('.anotherrisk_btn').show();
        $('.anotherrisk_btn_loader').hide();
        $('#anotherrisk_Modal').modal('hide')
        },
        error: function(err) {
            console.log(err)
        }
    });
     }
    });

    $(document).on('click','.close_sep_temp_save_new_risk_single',function(){
        var name = $(this).attr('data-id');
        $(this).parents('.sep_temp_save_new_risk_single').remove();
        $('.sep_add_new_proc_risk_single[data-name='+name+']').remove();
    })

     $(document).on('click','.close_temp_save_new_risk_single',function(){
        var name = $(this).attr('data-id');
        $(this).parents('.temp_save_new_risk_single').remove();
        $('.add_new_proc_risk_single[data-name='+name+']').remove();
    })

    $(document).on('click','.close_sep_temp_save_new_bene_single',function(){
        var name = $(this).attr('data-id');
        $(this).parents('.sep_temp_save_new_bene_single').remove();
        $('.sep_add_new_proc_bene_single[data-name='+name+']').remove();
    })

    $(document).on('click','.close_temp_save_new_bene_single',function(){
        var name = $(this).attr('data-id');
        $(this).parents('.temp_save_new_bene_single').remove();
        $('.add_new_proc_bene_single[data-name='+name+']').remove();
    })

$(document).on('click','.btnsubmit_procedure_all',function(){
var A4_procedure_fetch = '';
    $('.singleproc').each(function(){
    A4_procedure_fetch += '<p>'+
        '<span class="A4_procedure_code">'+$(this).find('.data_unq_code').text()+'</span> <span class="A4_procedure_star"><i class="fa-solid fa-arrow-right"></i></span> <span class="A4_procedure_side">'+$(this).find('.side').val()+'</span> <span class="A4_procedure_site">'+$(this).find('.site').val()+'</span> <span class="A4_procedure_site">'+$(this).find('.procedureseach').val()+'</span>'+
    '</p>';
});
    $('.A4_procedure_fetch').html(A4_procedure_fetch)
      printDiv();
    })
    function printDiv() 
{

  var divToPrint=document.getElementById('DivIdToPrint');

  var newWin=window.open('','Print-Window');

  newWin.document.open();
  var htm = '<html><head><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">'+
    '<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">'+
    '<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/print.css')); ?>"></head>'+
    '<body onload="window.print()">'+divToPrint.innerHTML+'</body></html>';
  newWin.document.write(htm);

  newWin.document.close();

  // setTimeout(function(){newWin.close();},10);

}
</script>
     

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\surgery\resources\views/home.blade.php ENDPATH**/ ?>