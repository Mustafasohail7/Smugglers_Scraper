<?php $__env->startSection('content'); ?>
<style type="text/css">
     .input-date {
  border: 0px solid #ccc;
  display: flex;
  widtH: 110px;
  position: relative;
  transition: 0.15s ease-in-out;
      padding: 0px 0px 0px 0px;
      border-top: 1px solid #ccc !important;
      border-bottom: 1px solid #ccc !important;
      height: 35px;

}
 
 .input-date:after {
  content: "/";
  position: absolute;
  color: #ccc;
  width: 3px;
  height: 22px;
  top: 50%;
  lefT: 35%;
  transform: translate(-50%, -50%);
}
 .input-date input {
  padding: 0px;
  width: 55px;
  text-transform: uppercase;
  display: block;
  border: none;
  outline: 0;
  background: none;
}
.input-date input:focus{
    background: none !important;
  outline: none !important;
  border: none !important;
  padding: 0px !important;
   box-shadow: none !important;
}
.input-date input:active{
    background: none !important;
  outline: none !important;
  border: none !important;
  padding: 0px !important;
   box-shadow: none !important;
}
.cvv input {
  width: 100%;
  padding: 5px;
  text-align: right;
  background: none;
  outline: 0;
  border: 0px solid #ccc;
/*  border:none;*/
border-radius: 0px 7px 7px 0px;
border-top: 1px solid #ccc !important;
      border-bottom: 1px solid #ccc !important;
      border-right: 1px solid #ccc !important;
}
.cvv input:focus{
    background: none !important;
  outline: none !important;
  border: 0px solid #ccc !important;
  padding: 5px !important;
   box-shadow: none !important;
   border-radius: 0px 7px 7px 0px;
border-top: 1px solid #ccc !important;
      border-bottom: 1px solid #ccc !important;
      border-right: 1px solid #ccc !important;
      border-left: px solid !important;
}
.cvv input:active{
    background: none !important;
  outline: none !important;
  border: 0px solid #ccc !important;
  padding: 5px !important;
   box-shadow: none !important;
   border-radius: 0px 7px 7px 0px;
border-top: 1px solid #ccc !important;
      border-bottom: 1px solid #ccc !important;
      border-right: 1px solid #ccc !important;
      border-left: px solid !important;
}
.cardnum input{
width: 100%;
  padding: 5px;
  background: none;
  outline: 0;
  border: 1px solid #ccc;
  border-radius: 7px 0px 0px 7px;
      border-right: 0px solid !important;
}
.cardnum input:focus{
    background: none !important;
  outline: none !important;
  border: 1px solid #ccc !important;
  padding: 5px !important;
   box-shadow: none !important;
   border-right: 0px solid !important;
}
.cardnum input:active{
    background: none !important;
  outline: none !important;
  border: 1px solid #ccc !important;
  padding: 5px !important;
   box-shadow: none !important;
   border-right: 0px solid !important;
}

.cardnum{
        padding: 0px 0px 0px 12px;
}
.cvv{
        padding: 0px 0px 0px 0px;
}
.input{
    background: none;
  outline: none;
  border: 1px solid #ccc !important;
  padding: 5px !important;
}
.input:focus{
    background: none !important;
  outline: none !important;
  border: 1px solid #ccc !important;
  padding: 5px !important;
   box-shadow: none !important;
}
.input:active{
    background: none !important;
  outline: none !important;
  border: 1px solid #ccc !important;
  padding: 5px !important;
   box-shadow: none !important;
}
.headingcard{
    text-align: center;
    margin: 0px 0px 0px 35px;
    font-size: 20px;
    font-weight: bold;
    font-family: inherit;
}
.cardwarning{
        margin: 0px 15px 0px 0px;
    font-size: 14px;
    text-align: right;
}
.invalid-feedback {
     display: block;
    }
</style>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Register')); ?></div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('register')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="row mb-3">
                            <label for="fname" class="col-md-4 col-form-label text-md-end"><?php echo e(__('First Name')); ?></label>

                            <div class="col-md-8">
                                <input id="fname" type="text" class="input form-control <?php $__errorArgs = ['fname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="fname" value="<?php echo e(old('fname')); ?>" required autocomplete="fname" autofocus>

                                <?php $__errorArgs = ['fname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="lname" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Last Name')); ?></label>

                            <div class="col-md-8">
                                <input id="lname" type="text" class="input form-control <?php $__errorArgs = ['lname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="lname" value="<?php echo e(old('lname')); ?>" required autocomplete="lname" autofocus>

                                <?php $__errorArgs = ['lname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="email" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Email Address')); ?></label>

                            <div class="col-md-8">
                                <input id="email" type="email" class="input form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email">

                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="phone" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Mobile Number')); ?></label>

                            <div class="col-md-6">
                                <input id="phone" type="tel" class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="phone" value="<?php echo e(old('phone')); ?>" required>

                                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        

                        <div class="row mb-3">
                            <label for="password" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Password')); ?></label>

                            <div class="col-md-8">
                                <input id="password" type="password" class="input form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" minlength="6" required autocomplete="new-password">

                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="password-confirm" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Confirm Password')); ?></label>

                            <div class="col-md-8">
                                <input id="password-confirm" type="password" class="input form-control" name="password_confirmation" required autocomplete="new-password">
                            </div>
                        </div>

                        <div class="row mb-1">

                            <div class="col-md-12">
                                <p class="headingcard">Enter Credit or Debit card details.</p>
                            </div>
                        </div>

                        <div class="row mb-1">
                            <label for="password-confirm" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Credit or Debit Card')); ?></label>

                            <div class="col-md-5 cardnum">
                                <input id="cardnumber" type="text" class=" form-control" name="cardnumber" required placeholder="Card Number" maxlength='19' minlength='19'>
                                <?php $__errorArgs = ['cardnumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                                <div class='col-md-2 field input-date'>
                                <input type='text' class=" form-control" required placeholder="MM" maxlength='2' minlength='2' name="cdmonth" id='cdmonth'/>
                                <input type='text' class=" form-control" required placeholder="YY" maxlength='2' minlength='2' name="cdyear" id='cdyear'/>
                                <?php $__errorArgs = ['cdyear'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                 <?php $__errorArgs = ['cdmonth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class='col-md-1 field cvv'>
                                    <input type='text' class="form-control" required minlength='3' maxlength='4' name='cdcvv' id='cd-cvv' placeholder="CVC" />
                                    <?php $__errorArgs = ['cd-cvv'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div> 
                        </div>
                        <div class="row mb-1">

                            <div class="col-md-12">
                                <p class="cardwarning">A valid Credit or Debit card is required when establishing a new account.</p>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-8">
                                <input id="roles" type="hidden" class="form-control" name="roles" value="2">
                            </div>
                        </div>


         <!-- Google Recaptcha -->
         <div class="row mb-3 mt-3">
            <div class="col-md-8 offset-md-4">
         <?php echo NoCaptcha::renderJs(); ?>

         <?php echo NoCaptcha::display(); ?>

          <?php $__errorArgs = ['g-recaptcha-response'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    </div>

<div class="row mb-3">
            <div class="col-md-8 offset-md-4">
    <div class="form-check">
  <input class="form-check-input" type="checkbox" id="privacy_policy" name="privacy_policy">
  <label class="form-check-label" for="privacy_policy">Check the box if you have read this <a href="">privacy</a></label>
</div>

<div class="form-check">
  <input class="form-check-input" type="checkbox" id="terms_and_conditions" name="terms_and_conditions">
  <label class="form-check-label" for="terms_and_conditions">Check the box if you have read this <a href="">tou</a></label>
</div>
<?php $__errorArgs = ['privacy_policy'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

 <?php $__errorArgs = ['terms_and_conditions'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
</div>

                        <div class="row mb-0">
                            <div class="col-md-8 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Register')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\surgery\resources\views/auth/register.blade.php ENDPATH**/ ?>