<page size="A4" id="DivIdToPrint" style="display: none;">

<div class="row A4_parent_header">
	<div class="col-md-6 header_img">
		<img src="{{ url('/images/logo.jpeg') }}" alt="logo" style="width: 300px;">
	</div>
	<div class="col-md-6 header_content">
		<h3>Dr. Important Surgeon</h3>
		<h3>Big City Orthopaedic Group</h3>
		<p>“Professional letterhead goes here</p>
	</div>
	</div>

<div class="row A4_parent_nav">
	<ul>
		<li><b>Phone:</b> 0402345677</li>
		<li><b>Gmail:</b> reception@bigcityortho.com</li>
		<li><b>Address:</b> Bic City, Australia</li>
	</ul>
</div>

<div class="row A4_parent_form">
	<h3>Consent for surgical procedure</h3>
	<div class="col-md-7 form_content">
		<p>Hospital Number: _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ </p>
		<p>Surname: _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _</p>
		<p>Given Name: _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _</p>
		<p>Address: _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _</p>
		<p>Date Of Birth: _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _</p>
		<p>Phone Number: _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _</p>
		<p>Gender: <span class="form_check_gender"></span> Male <span class="form_check_gender"></span> Female <span class="form_check_gender"></span> Other</p>
	</div>
</div>

<div class="row A4_parent_procedure">
	<h3>Procedure:</h3>
	<div class="A4_procedure_fetch"></div>
</div>

<div class="row A4_parent_content">
	<p>Medicolegal blurb about Dr. Important Surgeon has discussed the benefits, risks, outcomes
and side-effects of the procedure above. I, the patient, give my consent for the above
procedure.</p>

<div class="col-md-7 form_content2">
		<p>Name Of Patient : _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ </p>
		<p>Signature Of Patient : _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _</p>
		<p>Date : _ _ _ _ /_ _ _ _/ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _</p>
	</div>

<p>Medicolegal blurb about “I, Dr. Important Surgeon have discussed the benefits, risks and
outcomes of the above procedure with the above-named patient and accept their consent
for surgery.</p>

<div class="col-md-7 form_content2">
		<p>Name Of Doctor : _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ </p>
		<p>Signature Of Doctor : _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _</p>
		<p>Date : _ _ _ _ /_ _ _ _/ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _</p>
	</div>

</div>

<div class="row A4_parent_benrisk">
	<h3>Benefits:</h3>
	<table class="table">
    <thead>
      <tr>
        <th>#</th>
        <th>Benefit</th>
        <th>Explaination</th>
        <th>Statistics</th>
        <th>Procedure</th>
      </tr>
    </thead>
    <tbody class="A4_benefit_fetch">
      
  </tbody>
</table>

	<h3>Risks:</h3>
	<table class="table">
    <thead>
      <tr>
        <th>#</th>
        <th>Risk</th>
        <th>Explaination</th>
        <th>Statistics</th>
        <th>Procedure</th>
      </tr>
    </thead>
    <tbody class="A4_risk_fetch">

  </tbody>
</table>
</div>
</page>