@extends('layouts.app2')

@section('content')
<div class="content-wrapper">
            <div class="page-header">
              <h3 class="page-title">
                <span class="page-title-icon bg-gradient-primary text-white me-2">
                  <i class="mdi mdi-account-plus"></i>
                </span> Add User
              </h3>
            </div>
            @include('admin.inc.notify')
            <div class="row justify-content-center">
              
              <div class="col-8 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <form class="forms-sample" action="{{ url('add_user') }}" method="POST">
                    	@csrf
                      <div class="form-group">
                        <label for="fname" class="form-label">First Name</label>
                                <input name="fname" type="text" required class="form-control @error('fname') is-invalid @enderror" id="fname" placeholder="First Name">
                                <input id="roles" type="hidden" class="form-control" name="roles" value="2">
                                @error('fname')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror
                      </div>

                      <div class="form-group">
                        <label for="lname" class="form-label">Last Name</label>
                                <input name="lname" type="text" required class="form-control @error('lname') is-invalid @enderror" id="lname" placeholder="Last Name">
                                @error('lname')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror
                      </div>

                      <div class="form-group">
                        <label for="email" class="form-label">Email</label>
                                <input name="email" type="email" required class="form-control @error('email') is-invalid @enderror" id="email" placeholder="Email">
                                @error('email')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror
                      </div>

                      <div class="form-group">
                        <label for="password" class="form-label">Password</label>
                                <input name="password" type="text" required class="form-control @error('password') is-invalid @enderror" id="password" placeholder="Password">
                                @error('password')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror
                      </div>

                      <div class="form-group">
                        <label for="phone" class="form-label">Phone</label>
                                <input id="phone" type="tel" class="form-control @error('phone') is-invalid @enderror" name="phone" required >
                                @error('phone')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror
                      </div>

                      <div class="form-group">
                        <label for="qualification" class="form-label">Qualification</label>
                                <input id="qualification" type="name" class="form-control @error('qualification') is-invalid @enderror" name="qualification" required >
                                @error('qualification')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror
                      </div>

                      <div class="form-group">
                        <label for="practicename" class="form-label">Practice Name</label>
                                <input id="practicename" type="name" class="form-control @error('practicename') is-invalid @enderror" name="practicename" required >
                                @error('practicename')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror
                      </div>

                      
                      <button type="submit" class="btn btn-gradient-primary me-2">Add User</button>
                    </form>
                  </div>
                </div>
              </div>

            </div>
            
            
          </div>
@endsection