@extends('layouts.app2')

@section('content')
<style type="text/css">
	.list-ticked li{
		background: #e5e3e3;
    border-radius: 5px;
    padding: 0px 0px 0px 5px;
    position: relative;
	}
  .mdi-subdirectory-arrow-left{
        position: absolute;
    top: 40px;
    left: -22px;
    font-size: 20px;
    color: blue;
    cursor: pointer;
  }
  .mdi-subdirectory-arrow-right{
        position: absolute;
    top: 10px;
    right: -22px;
    font-size: 20px;
    color: blue;
    cursor: pointer;
  }
</style>
<div class="content-wrapper">
            <div class="page-header">
              <h3 class="page-title">
                <span class="page-title-icon bg-gradient-primary text-white me-2">
                  <i class="mdi mdi-clipboard-text"></i>
                </span> {{ $single_proc->procedure_name }} ({{ $single_proc->procedure_code }})  created by ({{ $single_proc->fname }} {{ $single_proc->lname }}) @if($single_proc->status == 0)
                      	<b style="color:red">Pending</b>
                      	@else
                      	<b style="color:green">Done</b>
                      	@endif
                         
              </h3>
            </div>

            <form method="POST" class="mb-3" action="{{ url('/admin_procedure_status/' .  $single_proc->id) }}">
                        @csrf
                    <input type="hidden" name="webpageid" value="{{ $single_proc->id }}">
                    <input type="text" name="proc_name" value="{{ $single_proc->procedure_name }}">
                    <select name="statusget" id="statusget">
                        <option @php if($single_proc->status == 1) { echo "selected"; } @endphp value="1">Done</option>
                        <option @php if($single_proc->status == 0) { echo "selected"; } @endphp value="0">Pending</option>
                    </select>
                    <button type="submit" class="btn btn-gradient-success btn-sm">Update</button>
                    </form>
            @include('admin.inc.notify')
           	

           	<div class="row">
              <div class="col-3 mb-2">
                      <button type="button" class="btn btn-gradient-secondary" id="addnewbenefit_modalopen" data-name="ben">Add Benefit</button>
                    </div>
              <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                   
                   <div class="row">
                   	<div class="col-6">
                   		<h5>Procedure Benefit</h5>
                   		<ul class="list-ticked">
                   		@foreach($single_proc_benfit as $single_proc_benfit_get )
                      <li><b>{{ $single_proc_benfit_get->code }}</b> - {{ $single_proc_benfit_get->benefit_name }} - {{ $single_proc_benfit_get->statistics }} <p>{{ $single_proc_benfit_get->detail }}</p>
                      	@if($single_proc_benfit_get->status == 0)
                      	<p>
                      	<b style="color:red">Pending</b> -- Create & view by only <b>{{ $single_proc_benfit_get->fname }} {{ $single_proc_benfit_get->lname }}</b>
                        <form method="POST" class="mb-3" action="{{ url('/admin_benfit_status/' .  $single_proc_benfit_get->code) }}">
                        @csrf
                    <input type="hidden" name="benfitcode" value="{{ $single_proc_benfit_get->code }}">
                    <select name="statusget_ben" class="statusget_ben">
                        <option @php if($single_proc_benfit_get->status == 1) { echo "selected"; } @endphp value="1">Done</option>
                        <option @php if($single_proc_benfit_get->status == 0) { echo "selected"; } @endphp value="0">Pending</option>
                    </select>
                    </form>
                      	</p>
                      	@else
                      	<p>
                      	<b style="color:green">Done</b> -- Created by <b>{{ $single_proc_benfit_get->fname }} {{ $single_proc_benfit_get->lname }}</b>
                      	</p>
                      	@endif
                        @if($single_proc_benfit_get->status == 1)
                        <i class="mdi mdi-subdirectory-arrow-right moverightside" data-id="{{ $single_proc_benfit_get->id }}" data-name="ben" data-code="{{ $single_proc_benfit_get->code }}" data-procid="{{ $single_proc->id }}"></i>
                        @endif
                      </li>
                   		@endforeach
                      </ul>
                   	</div>

                   	<div class="col-6">
                   		<h5>All Benefit</h5>
                   		<ul class="list-ticked">
                   		@foreach($single_proc_all_benfit as $single_proc_all_benfit_get )
                      <li><b>{{ $single_proc_all_benfit_get->code }}</b> - {{ $single_proc_all_benfit_get->benefit_name }} - {{ $single_proc_all_benfit_get->statistics }} <p>{{ $single_proc_all_benfit_get->detail }}</p>
                      	@if($single_proc_all_benfit_get->status == 0)
                      	<p>
                      	<b style="color:red">Pending</b> -- Create & view by only <b>{{ $single_proc_all_benfit_get->fname }} {{ $single_proc_all_benfit_get->lname }}</b>
                      	</p>
                      	@else
                      	<p>
                      	<b style="color:green">Done</b> -- Created by <b>{{ $single_proc_all_benfit_get->fname }} {{ $single_proc_all_benfit_get->lname }}</b>
                      	</p>
                      	@endif
                        <i class="mdi mdi-subdirectory-arrow-left moveleftside" data-name="ben" data-code="{{ $single_proc_all_benfit_get->code }}" data-procid="{{ $single_proc->id }}"></i>
                      </li>
                   		@endforeach
                      </ul>
                   	</div>
                   </div>

                  </div>
                </div>
              </div>
            </div>

            <div class="row">
              <div class="col-3 mb-2">
                      <button type="button" class="btn btn-gradient-secondary" id="addnewbenefit_modalopen" data-name="risk">Add Risk</button>
                    </div>
              <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                   
                   <div class="row">
                    <div class="col-6">
                      <h5>Procedure Risk</h5>
                      <ul class="list-ticked">
                      @foreach($single_proc_risk as $single_proc_risk_get )
                      <li><b>{{ $single_proc_risk_get->code }}</b> - {{ $single_proc_risk_get->risk_name }} - {{ $single_proc_risk_get->statistics }} <p>{{ $single_proc_risk_get->detail }}</p>
                        @if($single_proc_risk_get->status == 0)
                        <p>
                        <b style="color:red">Pending</b> -- Create & view by only <b>{{ $single_proc_risk_get->fname }} {{ $single_proc_risk_get->lname }}</b>
                        <form method="POST" class="mb-3" action="{{ url('/admin_risk_status/' .  $single_proc_risk_get->code) }}">
                        @csrf
                    <input type="hidden" name="riskcode" value="{{ $single_proc_risk_get->code }}">
                    <select name="statusget_risk" class="statusget_risk">
                        <option @php if($single_proc_risk_get->status == 1) { echo "selected"; } @endphp value="1">Done</option>
                        <option @php if($single_proc_risk_get->status == 0) { echo "selected"; } @endphp value="0">Pending</option>
                    </select>
                    </form>
                        </p>
                        @else
                        <p>
                        <b style="color:green">Done</b> -- Created by <b>{{ $single_proc_risk_get->fname }} {{ $single_proc_risk_get->lname }}</b>
                        </p>
                        @endif
                        @if($single_proc_risk_get->status == 1)
                        <i class="mdi mdi-subdirectory-arrow-right moverightside" data-id="{{ $single_proc_risk_get->id }}" data-name="risk" data-code="{{ $single_proc_risk_get->code }}" data-procid="{{ $single_proc->id }}"></i>
                        @endif
                      </li>
                      @endforeach
                      </ul>
                    </div>

                    <div class="col-6">
                      <h5>All Risk</h5>
                      <ul class="list-ticked">
                      @foreach($single_proc_all_risk as $single_proc_all_risk_get )
                      <li><b>{{ $single_proc_all_risk_get->code }}</b> - {{ $single_proc_all_risk_get->risk_name }} - {{ $single_proc_all_risk_get->statistics }} <p>{{ $single_proc_all_risk_get->detail }}</p>
                        @if($single_proc_all_risk_get->status == 0)
                        <p>
                        <b style="color:red">Pending</b> -- Create & view by only <b>{{ $single_proc_all_risk_get->fname }} {{ $single_proc_all_risk_get->lname }}</b>
                        </p>
                        @else
                        <p>
                        <b style="color:green">Done</b> -- Created by <b>{{ $single_proc_all_risk_get->fname }} {{ $single_proc_all_risk_get->lname }}</b>
                        </p>
                        @endif
                        <i class="mdi mdi-subdirectory-arrow-left moveleftside" data-name="risk" data-code="{{ $single_proc_all_risk_get->code }}" data-procid="{{ $single_proc->id }}"></i>
                      </li>
                      @endforeach

                      </ul>
                    </div>
                   </div>

                  </div>
                </div>
              </div>
            </div>
            
            
          </div>

<!-- new benefit modal -->
<div class="modal fade zoomIn" id="newBenefit_Modal" tabindex="-1" data-bs-keyboard="false" data-bs-backdrop="static" aria-hidden="true" role="dialog">
          <div class="modal-dialog modal-dialog-centered modal-md">
            <div class="modal-content">
                <div class="modal-header">
        <h4 class="modal-title">Add New Procedure</h4>
      </div>
      <form method="POST" action="{{ url('submit_new_benefitrisk_admin') }}" id="new_benefitrisk_form">
        @csrf
                <div class="modal-body" style="">
                <div class="row">
                            <div class="col-md-6">
                                <label class="form-label">Name</label>
                                <input name="new_benefit_status_input" type="hidden" class="new_benefit_status_input form-control input">
                                <input name="proc_id" type="hidden" class="proc_id form-control input" value="{{ $single_proc->id }}">
                                <input name="new_benefit_name_input" required type="text" class="new_benefit_name_input form-control input">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Statistics</label>
                                <input name="new_benefit_statistics_input" required type="text" class="new_benefit_statistics_input form-control input">
                            </div>
                            <div class="col-md-12 mt-2">
                                <label class="form-label">Detail</label>
                                <input name="new_benefit_detail_input" required type="text" class="new_benefit_detail_input form-control input">
                            </div>
                            </div>

                </div>
                 <div class="modal-footer">
        <button type="button" class="btn btn-gradient-danger btn-fw btn_close_modal" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-gradient-success btn-fw add_newben_submit_btn">SUBMIT</button>
        <button type="button" class="btn btn-gradient-success btn-fw add_newben_submit_btn_loader" style="display:none;">Waiting...</button>
      </div>
  </form>
                </div>
            </div>
          </div>
<!-- new benefit modal -->
<script type="text/javascript">

$(document).on('change','.statusget_ben',function(event){
this.form.submit();
})
$(document).on('change','.statusget_risk',function(event){
this.form.submit();
})
$(document).on('click','.moverightside',function(event){
var id = $(this).attr('data-id');
var name = $(this).attr('data-name');
var code = $(this).attr('data-code');
var procid = $(this).attr('data-procid');
let formData = new FormData();
formData.append('id',id);
formData.append('name',name);
formData.append('code',code);
formData.append('procid',procid);
        $.ajaxSetup({
          headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
      });
         $.ajax({
        // headers: {
        //     'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')
        // },
        url: "{{ url('admin_benrisk_moverightside') }}",
        type: "POST",
        data: formData,
         processData: false,
    contentType: false,
    cache: false,
        dataType: "json",
         success: function(data) {
          console.log(data)
          location.reload();
          }
        });
});

$(document).on('click','.moveleftside',function(event){
var name = $(this).attr('data-name');
var code = $(this).attr('data-code');
var procid = $(this).attr('data-procid');
let formData = new FormData();
formData.append('name',name);
formData.append('code',code);
formData.append('procid',procid);
        $.ajaxSetup({
          headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
      });
         $.ajax({
        // headers: {
        //     'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')
        // },
        url: "{{ url('admin_benrisk_moveleftside') }}",
        type: "POST",
        data: formData,
         processData: false,
    contentType: false,
    cache: false,
        dataType: "json",
         success: function(data) {
          console.log(data)
          location.reload();
          }
        });
});
$(document).on('click','#addnewbenefit_modalopen',function(event){
  var name = $(this).attr('data-name');
  if(name == 'ben'){
  $('.modal-title').text('Add New Benefit')
  }
  else{
  $('.modal-title').text('Add New Risk')
  }
  $('.new_benefit_status_input').val(name)
  $('#newBenefit_Modal').modal('show')
})

 $(document).on('click','.btn_close_modal',function(){
        $('#newBenefit_Modal').modal('hide');
    });

 $('#new_benefitrisk_form').submit(function(e) {
        e.preventDefault();
        $('.add_newben_submit_btn').hide();
        $('.add_newben_submit_btn_loader').show();
        let formData = new FormData(this);
        $.ajaxSetup({
          headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
      });
         $.ajax({
        // headers: {
        //     'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')
        // },
        url: $(this).attr('action'),
        type: $(this).attr('method'),
        data: formData,
         processData: false,
    contentType: false,
    cache: false,
        dataType: "json",
         success: function(data) {
            console.log(data);
            
        $('.add_newben_submit_btn').show();
        $('.add_newben_submit_btn_loader').hide();
        $('#newBenefit_Modal').modal('hide')
        // fetchproc($('#search_proc').val(),$('#search_status').val());
        location.reload()
        },
        error: function(err) {
            console.log(err)
        }
    });
    });
</script>
@endsection