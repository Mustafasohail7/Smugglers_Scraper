@extends('layouts.app2')

@section('content')
<div class="content-wrapper">
            <div class="page-header">
              <h3 class="page-title">
                <span class="page-title-icon bg-gradient-primary text-white me-2">
                  <i class="mdi mdi-clipboard-text"></i>
                </span> All Risks
              </h3>
            </div>
            @include('admin.inc.notify')
            <div class="row">
              <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title">All Risks</h4>
                    <table class="table table-striped">
                      <thead>
                        <tr>
                          <th> # </th>
                          <th> Procedure </th>
                          <th> Risk Code </th>
                          <th> Risk Name </th>
                          <th> Risk statistics </th>
                          <th> User </th>
                          <th> Status </th>
                          <th> Created_at </th>
                        </tr>
                      </thead>
                      <tbody>

                        @php
                        $count = 0;
                        @endphp
                        @foreach($new_risk_pending as $new_risk_pending_get)
@php
                        $count++;
                        @endphp
                        @php
                        $mnb = explode(',',$new_risk_pending_get->procedure_code);
                        @endphp
                        <tr>
                          <td> {{ $count }} </td>
                          <td>
                          @foreach($mnb as $singcode)
    <a href="{{ url('procedure', $singcode) }}">
        {{ $singcode }}
    </a>

    @if( !$loop->last)
        ,
    @endif
@endforeach
</td>
                          <td> {{ $new_risk_pending_get->code }} </td>
                          <td> {{ $new_risk_pending_get->risk_name }} </td>
                          <td> {{ $new_risk_pending_get->statistics }} </td>
                          <td> {{ $new_risk_pending_get->fname }} {{ $new_risk_pending_get->lname }} </td>
                          @if($new_risk_pending_get->status == 0)
                          <td> <label class="badge badge-gradient-danger">Pending</label> </td>
                          @else
                          <td> <label class="badge badge-gradient-success">Done</label> </td>
                          @endif
                          <td> {{ $new_risk_pending_get->created_at }} </td>
                        </tr>
                        @endforeach
                        
                        
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
            
            
          </div>
@endsection