@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">{{ __('My Account') }}</div>

                    <form action="{{ url('update-account') }}" method="POST">
                        @csrf
                        <div class="card-body">

                            <div class="mb-3">
                                <label for="fname" class="form-label">First Name</label>
                                <input name="fname" type="text" required class="form-control @error('fname') is-invalid @enderror" id="fname" placeholder="First Name" value="{{ Auth::user()->fname }}">
                                @error('fname')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                            <div class="mb-3">
                                <label for="lname" class="form-label">Last Name</label>
                                <input name="lname" type="text" required class="form-control @error('lname') is-invalid @enderror" id="lname" placeholder="Last Name" value="{{ Auth::user()->lname }}">
                                @error('lname')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                            <div class="mb-3">
                                <label for="email" class="form-label">Email</label>
                                <input name="email" type="email" required class="form-control @error('email') is-invalid @enderror" id="email" placeholder="Email" value="{{ Auth::user()->email }}">
                                @error('email')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>

                            <div class="mb-3">
                                <label for="phone" class="form-label">Phone</label>
                                <input id="phone" type="tel" class="form-control @error('phone') is-invalid @enderror" name="phone" required>
                                @error('phone')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>

                            <div class="mb-3">
                                <label for="qualification" class="form-label">Qualification</label>
                                <input id="qualification" type="name" class="form-control @error('qualification') is-invalid @enderror" name="qualification" required value="{{ Auth::user()->qualifications }}">
                                @error('qualification')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>

                            <div class="mb-3">
                                <label for="practicename" class="form-label">Practice Name</label>
                                <input id="practicename" type="name" class="form-control @error('practicename') is-invalid @enderror" name="practicename" required value="{{ Auth::user()->practice_name }}">
                                @error('practicename')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>

                        </div>

                        <div class="card-footer">
                            <button class="btn btn-success">Update Account</button>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>

    <script type="text/javascript">
        setTimeout(function(){
        document.getElementById('phone').value = '{{ Auth::user()->phone }}';
        },2000)
    </script>
@endsection