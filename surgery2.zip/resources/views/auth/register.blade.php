@extends('layouts.app')

@section('content')
<style type="text/css">
     .input-date {
  border: 0px solid #ccc;
  display: flex;
  widtH: 110px;
  position: relative;
  transition: 0.15s ease-in-out;
      padding: 0px 0px 0px 0px;
      border-top: 1px solid #ccc !important;
      border-bottom: 1px solid #ccc !important;
      height: 35px;

}
 
 .input-date:after {
  content: "/";
  position: absolute;
  color: #ccc;
  width: 3px;
  height: 22px;
  top: 50%;
  lefT: 35%;
  transform: translate(-50%, -50%);
}
 .input-date input {
  padding: 0px;
  width: 55px;
  text-transform: uppercase;
  display: block;
  border: none;
  outline: 0;
  background: none;
}
.input-date input:focus{
    background: none !important;
  outline: none !important;
  border: none !important;
  padding: 0px !important;
   box-shadow: none !important;
}
.input-date input:active{
    background: none !important;
  outline: none !important;
  border: none !important;
  padding: 0px !important;
   box-shadow: none !important;
}
.cvv input {
  width: 100%;
  padding: 5px;
  text-align: right;
  background: none;
  outline: 0;
  border: 0px solid #ccc;
/*  border:none;*/
border-radius: 0px 7px 7px 0px;
border-top: 1px solid #ccc !important;
      border-bottom: 1px solid #ccc !important;
      border-right: 1px solid #ccc !important;
}
.cvv input:focus{
    background: none !important;
  outline: none !important;
  border: 0px solid #ccc !important;
  padding: 5px !important;
   box-shadow: none !important;
   border-radius: 0px 7px 7px 0px;
border-top: 1px solid #ccc !important;
      border-bottom: 1px solid #ccc !important;
      border-right: 1px solid #ccc !important;
      border-left: px solid !important;
}
.cvv input:active{
    background: none !important;
  outline: none !important;
  border: 0px solid #ccc !important;
  padding: 5px !important;
   box-shadow: none !important;
   border-radius: 0px 7px 7px 0px;
border-top: 1px solid #ccc !important;
      border-bottom: 1px solid #ccc !important;
      border-right: 1px solid #ccc !important;
      border-left: px solid !important;
}
.cardnum input{
width: 100%;
  padding: 5px;
  background: none;
  outline: 0;
  border: 1px solid #ccc;
  border-radius: 7px 0px 0px 7px;
      border-right: 0px solid !important;
}
.cardnum input:focus{
    background: none !important;
  outline: none !important;
  border: 1px solid #ccc !important;
  padding: 5px !important;
   box-shadow: none !important;
   border-right: 0px solid !important;
}
.cardnum input:active{
    background: none !important;
  outline: none !important;
  border: 1px solid #ccc !important;
  padding: 5px !important;
   box-shadow: none !important;
   border-right: 0px solid !important;
}

.cardnum{
        padding: 0px 0px 0px 12px;
}
.cvv{
        padding: 0px 0px 0px 0px;
}
.input{
    background: none;
  outline: none;
  border: 1px solid #ccc !important;
  padding: 5px !important;
}
.input:focus{
    background: none !important;
  outline: none !important;
  border: 1px solid #ccc !important;
  padding: 5px !important;
   box-shadow: none !important;
}
.input:active{
    background: none !important;
  outline: none !important;
  border: 1px solid #ccc !important;
  padding: 5px !important;
   box-shadow: none !important;
}
.headingcard{
    text-align: center;
    margin: 0px 0px 0px 35px;
    font-size: 20px;
    font-weight: bold;
    font-family: inherit;
}
.cardwarning{
        margin: 0px 15px 0px 0px;
    font-size: 14px;
    text-align: right;
}
.invalid-feedback {
     display: block;
    }
</style>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('Register') }}</div>

                <div class="card-body">
                    <form method="POST" action="{{ route('register') }}">
                        @csrf

                        <div class="row mb-3">
                            <label for="fname" class="col-md-4 col-form-label text-md-end">{{ __('First Name') }}</label>

                            <div class="col-md-8">
                                <input id="fname" type="text" class="input form-control @error('fname') is-invalid @enderror" name="fname" value="{{ old('fname') }}" required autocomplete="fname" autofocus>

                                @error('fname')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="lname" class="col-md-4 col-form-label text-md-end">{{ __('Last Name') }}</label>

                            <div class="col-md-8">
                                <input id="lname" type="text" class="input form-control @error('lname') is-invalid @enderror" name="lname" value="{{ old('lname') }}" required autocomplete="lname" autofocus>

                                @error('lname')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="email" class="col-md-4 col-form-label text-md-end">{{ __('Email Address') }}</label>

                            <div class="col-md-8">
                                <input id="email" type="email" class="input form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" required autocomplete="email">

                                @error('email')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="phone" class="col-md-4 col-form-label text-md-end">{{ __('Mobile Number') }}</label>

                            <div class="col-md-6">
                                <input id="phone" type="tel" class="form-control @error('phone') is-invalid @enderror" name="phone" value="{{ old('phone') }}" required>

                                @error('phone')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        

                        <div class="row mb-3">
                            <label for="password" class="col-md-4 col-form-label text-md-end">{{ __('Password') }}</label>

                            <div class="col-md-8">
                                <input id="password" type="password" class="input form-control @error('password') is-invalid @enderror" name="password" minlength="6" required autocomplete="new-password">

                                @error('password')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="password-confirm" class="col-md-4 col-form-label text-md-end">{{ __('Confirm Password') }}</label>

                            <div class="col-md-8">
                                <input id="password-confirm" type="password" class="input form-control" name="password_confirmation" required autocomplete="new-password">
                            </div>
                        </div>

                        <div class="row mb-1">

                            <div class="col-md-12">
                                <p class="headingcard">Enter Credit or Debit card details.</p>
                            </div>
                        </div>

                        <div class="row mb-1">
                            <label for="password-confirm" class="col-md-4 col-form-label text-md-end">{{ __('Credit or Debit Card') }}</label>

                            <div class="col-md-5 cardnum">
                                <input id="cardnumber" type="text" class=" form-control" name="cardnumber" required placeholder="Card Number" maxlength='19' minlength='19'>
                                @error('cardnumber')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                                <div class='col-md-2 field input-date'>
                                <input type='text' class=" form-control" required placeholder="MM" maxlength='2' minlength='2' name="cdmonth" id='cdmonth'/>
                                <input type='text' class=" form-control" required placeholder="YY" maxlength='2' minlength='2' name="cdyear" id='cdyear'/>
                                @error('cdyear')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                                 @error('cdmonth')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                            <div class='col-md-1 field cvv'>
                                    <input type='text' class="form-control" required minlength='3' maxlength='4' name='cdcvv' id='cd-cvv' placeholder="CVC" />
                                    @error('cd-cvv')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                                </div> 
                        </div>
                        <div class="row mb-1">

                            <div class="col-md-12">
                                <p class="cardwarning">A valid Credit or Debit card is required when establishing a new account.</p>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-8">
                                <input id="roles" type="hidden" class="form-control" name="roles" value="2">
                            </div>
                        </div>


         <!-- Google Recaptcha -->
         <div class="row mb-3 mt-3">
            <div class="col-md-8 offset-md-4">
         {!! NoCaptcha::renderJs() !!}
         {!! NoCaptcha::display() !!}
          @error('g-recaptcha-response')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
    </div>
    </div>

<div class="row mb-3">
            <div class="col-md-8 offset-md-4">
    <div class="form-check">
  <input class="form-check-input" type="checkbox" id="privacy_policy" name="privacy_policy">
  <label class="form-check-label" for="privacy_policy">Check the box if you have read this <a href="">privacy</a></label>
</div>

<div class="form-check">
  <input class="form-check-input" type="checkbox" id="terms_and_conditions" name="terms_and_conditions">
  <label class="form-check-label" for="terms_and_conditions">Check the box if you have read this <a href="">tou</a></label>
</div>
@error('privacy_policy')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror

 @error('terms_and_conditions')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
</div>
</div>

                        <div class="row mb-0">
                            <div class="col-md-8 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    {{ __('Register') }}
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
