<?php

use Illuminate\Support\Facades\Route;

// use App\Http\Controllers\UserController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\HomeController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::group(['middleware'=>['auth','roles:admin']],function(){ 
Route::get('/admin', [AdminController::class,'index']);
Route::get('/admin_myaccount', [AdminController::class,'admin_myaccount']);
Route::get('/admin_changepassword', [AdminController::class,'admin_changepassword']);
Route::get('/allusers', [AdminController::class,'allusers']);
Route::get('/adduser', [AdminController::class,'adduser']);
Route::post('/add_user', [AdminController::class,'add_user']);
Route::get('/allbenefits', [AdminController::class,'allbenefits']);
Route::get('/allrisks', [AdminController::class,'allrisks']);
Route::get('/allprocedure', [AdminController::class,'allprocedure']);
Route::get('/fetch_admin_procedure', [AdminController::class,'fetch_admin_procedure']);
Route::post('/submit_new_procedure_admin', [AdminController::class,'submit_new_procedure_admin']);
Route::get('/procedure/{id}', [AdminController::class,'procedure']);
Route::post('/admin_procedure_status/{id}', [AdminController::class, 'admin_procedure_status']);
Route::post('/admin_benfit_status/{id}', [AdminController::class, 'admin_benfit_status']);
Route::post('/admin_risk_status/{id}', [AdminController::class, 'admin_risk_status']);
Route::post('/submit_new_benefitrisk_admin', [AdminController::class, 'submit_new_benefitrisk_admin']);
Route::post('/admin_benrisk_moveleftside', [AdminController::class, 'admin_benrisk_moveleftside']);
Route::post('/admin_benrisk_moverightside', [AdminController::class, 'admin_benrisk_moverightside']);
});
Route::get('/', function () {
    return redirect('/home');
});

Route::get('/home', [HomeController::class,'index']);
Route::get('/procedure_autocomplete', [HomeController::class,'procedure_autocomplete']);
Route::get('/fetch_procedure', [HomeController::class,'fetch_procedure']);
Route::post('/submit_new_procedure', [HomeController::class,'submit_new_procedure']);
Route::post('/submit_new_benefit', [HomeController::class,'submit_new_benefit']);
Route::post('/submit_new_risk', [HomeController::class,'submit_new_risk']);
Route::get('/change_password', [HomeController::class, 'changepassword']);
Route::get('/my_account', [HomeController::class, 'myaccount']);
Route::post('/update-account', [HomeController::class, 'updateaccount']);
Route::post('/update-password', [HomeController::class, 'updatePassword']);

Auth::routes([
'register' => false, // Registration Routes...
  'reset' => false, // Password Reset Routes...
  'verify' => false, // Email Verification Routes...
]);

Route::group(['middleware'=>['auth','roles:user']],function(){ 
});


// Route::controller(SearchController::class)->group(function(){

//     Route::get('demo-search', 'index');

//     Route::get('autocomplete', 'autocomplete')->name('autocomplete');

// });
