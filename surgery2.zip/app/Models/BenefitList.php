<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BenefitList extends Model
{
    use HasFactory;
    protected $table = 'benefit_list';
    protected $fillable = ['benefit_name','code','statistics','detail','procedure_id','status','userid'];
}
