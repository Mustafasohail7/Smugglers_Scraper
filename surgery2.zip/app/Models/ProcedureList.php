<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ProcedureList extends Model
{
    use HasFactory;
    protected $table = 'procedure_list';
    protected $fillable = ['procedure_name','status','userid','procedure_code'];
}
