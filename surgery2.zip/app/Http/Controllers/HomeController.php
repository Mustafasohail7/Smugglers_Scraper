<?php

namespace App\Http\Controllers;
use Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Models\User;
use App\Models\ProcedureList;
use App\Models\BenefitList;
use App\Models\RiskList;
use Illuminate\Validation\Rule;
use Carbon\Carbon;


class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    // public function __construct()
    // {
    //     $this->middleware('auth');
    // }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */

        
        public function changepassword()
    {
   return view('changepassword');
    }

    public function myaccount()
    {
   return view('myaccount');
    }

    public function updatePassword(Request $request)
{
        # Validation
        $request->validate([
            'old_password' => 'required',
            'new_password' => 'required|confirmed|string|min:8',
        ]);


        #Match The Old Password
        if(!Hash::check($request->old_password, auth()->user()->password)){
            return back()->with("error", "Old Password Doesn't match!");
        }


        #Update the new Password
        User::whereId(auth()->user()->id)->update([
            'password' => Hash::make($request->new_password)
        ]);

        return back()->with("message", "Password changed successfully!");
}


public function updateaccount(Request $request)
{
        # Validation
        $request->validate([
            'fname' => ['required'],
            'lname' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255',Rule::unique('users')->ignore(auth()->user()->id)],
            'phone' => ['required', 'string'],
            'qualification' => ['required'],
            'practicename' => ['required'],
        ]);


        #Update the new Password
        User::whereId(auth()->user()->id)->update([
            'fname' => $request->fname,
            'lname' => $request->lname,
            'email' => $request->email,
            'phone' => $request->phone,
            'qualifications' => $request->qualification,
            'practice_name' => $request->practicename,
        ]);

        return back()->with("message", "Account Detail Update successfully!");
}


    public function index()
    {
        
        return view('home');
    }

    public function submit_new_benefit(Request $request){
$last_id_ben = [];
$last_id_proc = [];
        for($ip=0; $ip<count($request['sepben_option']); $ip++)
{ 
    array_push($last_id_proc, $request->sepben_option[$ip]); 
for($i=0; $i<count($request['sep_new_benefit_name_input']); $i++)
{
    
if($request->sep_new_benefit_name_input[$i] == ''){
}
else{
if($request->sep_new_benefit_code_input[$i] == ''){
$code_gen_ben = random_int(100, 999);
}
else{
$code_gen_ben = $request->sep_new_benefit_code_input[$i];
}
$benefit_db_ins =  BenefitList::create([
        'benefit_name'=>$request->sep_new_benefit_name_input[$i],
        'code'=>'B-'.$code_gen_ben,
        'statistics'=>$request->sep_new_benefit_statistics_input[$i],
        'detail'=>$request->sep_new_benefit_detail_input[$i],
        'procedure_id'=>$request->sepben_option[$ip],
        'status'=>0,
        'userid'=>Auth::user()->id
]);
 array_push($last_id_ben, $benefit_db_ins->id);
}
}

}
        // return response()->json($last_id_proc);
$data = ProcedureList::whereIn('id',$last_id_proc)
                    ->first();
        $benefit = BenefitList::whereIn('id',$last_id_ben)
                    ->get();

        $dataArray = array(
  'procedure'   => $data,
  'benefit'   => $benefit
 );
    
        return response()->json($dataArray);
    }


    public function submit_new_risk(Request $request){
$last_id_risk = [];
$last_id_proc = [];
        for($ip=0; $ip<count($request['seprisk_option']); $ip++)
{ 
    array_push($last_id_proc, $request->seprisk_option[$ip]); 
for($i=0; $i<count($request['sep_new_risk_name_input']); $i++)
{
    
if($request->sep_new_risk_name_input[$i] == ''){
}
else{
if($request->sep_new_risk_code_input[$i] == ''){
$code_gen_risk = random_int(100, 999);
}
else{
$code_gen_risk = $request->sep_new_risk_code_input[$i];
}
$risk_db_ins =  riskList::create([
        'risk_name'=>$request->sep_new_risk_name_input[$i],
        'code'=>'B-'.$code_gen_risk,
        'statistics'=>$request->sep_new_risk_statistics_input[$i],
        'detail'=>$request->sep_new_risk_detail_input[$i],
        'procedure_id'=>$request->seprisk_option[$ip],
        'status'=>0,
        'userid'=>Auth::user()->id
]);
 array_push($last_id_risk, $risk_db_ins->id);
}
}

}
        // return response()->json($last_id_proc);
$data = ProcedureList::whereIn('id',$last_id_proc)
                    ->first();
        $risk = riskList::whereIn('id',$last_id_risk)
                    ->get();

        $dataArray = array(
  'procedure'   => $data,
  'risk'   => $risk
 );
    
        return response()->json($dataArray);
    }

    public function submit_new_procedure(Request $request)
    {
$code_gen = random_int(100, 999);
        $ProcedureList_db = ProcedureList::create([
            'procedure_name' => $request->new_procedure_input,
            'status' => 0,
            'userid' => Auth::user()->id,
            'procedure_code' => 'P-'.$code_gen
        ]);
       $ProcedureList_db_lastid = $ProcedureList_db->id;

for($i=0; $i<count($request['new_benefit_name_input']); $i++)
{    
if($request->new_benefit_name_input[$i] == ''){
}
else{
if($request->new_benefit_code_input[$i] == ''){
$code_gen_ben = random_int(100, 999);
}
else{
$code_gen_ben = $request->new_benefit_code_input[$i];
}
 BenefitList::create([
        'benefit_name'=>$request->new_benefit_name_input[$i],
        'code'=>'B-'.$code_gen_ben,
        'statistics'=>$request->new_benefit_statistics_input[$i],
        'detail'=>$request->new_benefit_detail_input[$i],
        'procedure_id'=>$ProcedureList_db_lastid,
        'status'=>0,
        'userid'=>Auth::user()->id
]);
}
}

for($i=0; $i<count($request['new_risk_name_input']); $i++)
{    
if($request->new_risk_name_input[$i] == ''){
}
else{
if($request->new_risk_code_input[$i] == ''){
$code_gen_risk = random_int(100, 999);
}
else{
$code_gen_risk = $request->new_risk_code_input[$i];
}
 RiskList::create([
        'risk_name'=>$request->new_risk_name_input[$i],
        'code'=>'R-'.$code_gen_risk,
        'statistics'=>$request->new_risk_statistics_input[$i],
        'detail'=>$request->new_risk_detail_input[$i],
        'procedure_id'=>$ProcedureList_db_lastid,
        'status'=>0,
        'userid'=>Auth::user()->id
]);
}
}

$data = ProcedureList::where('id',$ProcedureList_db_lastid)
                    ->first();
        $benefit = BenefitList::where('procedure_id',$ProcedureList_db_lastid)
                    ->get();
        $risk = RiskList::where('procedure_id',$ProcedureList_db_lastid)
                    ->get();

        $dataArray = array(
  'procedure'   => $data,
  'benefit'   => $benefit,
  'risk'   => $risk
 );
    
        return response()->json($dataArray);
        // return response()->json($ProcedureList_db_lastid);
    }
    public function procedure_autocomplete(Request $request)
    {
        
        $data = ProcedureList::select("procedure_name as value", "id")
                    // ->where('status',1)
                    ->whereIn('userid',[1,Auth::user()->id])
                    ->where('procedure_name', 'LIKE', '%'. $request->get('search'). '%')
                    ->get();
    
        return response()->json($data);
    }

     public function fetch_procedure(Request $request)
    {
        
        $data = ProcedureList::where('id',$request->get('proc_id'))
                    ->first();
        $benefit = BenefitList::where('procedure_id',$request->get('proc_id'))
                    // ->where('status',1)
                        ->whereIn('userid',[1,Auth::user()->id])
                    ->get();
        $risk = RiskList::where('procedure_id',$request->get('proc_id'))
                    // ->where('status',1)
                        ->whereIn('userid',[1,Auth::user()->id])
                    ->get();
        // $data = ProcedureList::join('benefit_list', 'benefit_list.procedure_id', '=', 'procedure_list.id')
        // ->join('risk_list', 'risk_list.procedure_id', '=', 'procedure_list.id')
        //             ->where('procedure_list.id',$request->get('proc_id'))
        //             ->where('benefit_list.status',1)
        //             ->where('risk_list.status',1)
        //             ->get(['benefit_list.benefit_name', 'risk_list.risk_name', 'procedure_list.*']);

        $dataArray = array(
  'procedure'   => $data,
  'benefit'   => $benefit,
  'risk'   => $risk
 );
    
        return response()->json($dataArray);
    }



     


}
