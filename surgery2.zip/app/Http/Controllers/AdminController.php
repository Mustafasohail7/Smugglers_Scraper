<?php

namespace App\Http\Controllers;

use Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Models\User;
use App\Models\ProcedureList;
use App\Models\BenefitList;
use App\Models\RiskList;
use Illuminate\Validation\Rule;
use Carbon\Carbon;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;

class AdminController extends Controller
{
     public function __construct()
    {
        $this->middleware('auth');
    }

    public function admin_myaccount(){
        return view('admin.admin_myaccount');
    }

    public function allbenefits(){
        $sql = "SELECT
    users.*,
    benefit_list.*,
    GROUP_CONCAT(procedure_list.procedure_name) AS procedure_names,
    GROUP_CONCAT(procedure_list.procedure_code) AS procedure_code
FROM benefit_list
INNER JOIN procedure_list ON benefit_list.procedure_id = procedure_list.id
INNER JOIN users ON benefit_list.userid = users.id
GROUP BY benefit_list.code
ORDER BY benefit_list.id DESC;";
$new_benefit_pending = DB::select(Db::raw($sql));
// dd($new_benefit_pending);
        // $new_benefit_pending = BenefitList::leftjoin('procedure_list', 'benefit_list.procedure_id', '=', 'procedure_list.id')
        // ->leftjoin('users', 'benefit_list.userid', '=', 'users.id')
        //             // ->where('benefit_list.status',0)
        //             ->orderBy('benefit_list.id','DESC')
        //             ->groupBy('benefit_list.code')
        //             ->get(['users.*', 'benefit_list.*', 'procedure_list.procedure_name','procedure_list.procedure_code']);
                    // dd($new_benefit_pending);
        return view('admin.allbenefits', compact('new_benefit_pending'));
    }

    public function allrisks(){
        $sql = "SELECT
    users.*,
    risk_list.*,
    GROUP_CONCAT(procedure_list.procedure_name) AS procedure_names,
    GROUP_CONCAT(procedure_list.procedure_code) AS procedure_code
FROM risk_list
INNER JOIN procedure_list ON risk_list.procedure_id = procedure_list.id
INNER JOIN users ON risk_list.userid = users.id
GROUP BY risk_list.code
ORDER BY risk_list.id DESC;";
$new_risk_pending = DB::select(Db::raw($sql));
        // $new_risk_pending = RiskList::join('procedure_list', 'risk_list.procedure_id', '=', 'procedure_list.id')
        // ->join('users', 'risk_list.userid', '=', 'users.id')
                    // ->where('risk_list.status',0)
                    // ->orderBy('risk_list.id','DESC')
                    // ->get(['users.*', 'risk_list.*', 'procedure_list.procedure_name','procedure_list.procedure_code']);
                    // dd($new_benefit_pending);
        return view('admin.allrisks', compact('new_risk_pending'));
    }

    public function allusers(){
        $all_user = User::where('id', '!=' ,4)->get();
        return view('admin.allusers', compact('all_user'));
        // return view('admin.allusers');
    }

    public function adduser(){
        return view('admin.adduser');
    }

    public function allprocedure(){
        return view('admin.allprocedure');
    }

    public function admin_changepassword(){
        return view('admin.admin_changepassword');
    }

    public function add_user(Request $request){
        $request->validate([
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
            'password' => ['required', 'min:8'],
        ]);

$user = User::create([
            'fname' => $request['fname'],
            'lname' => $request['lname'],
            'email' => $request['email'],
            'password' => Hash::make($request['password']),
            'roles' => $request['roles'],
            'phone' => $request['phone'],
            'qualifications' => $request['qualification'],
            'practice_name' => $request['practicename'],
        ]);
    $user->roles()->attach($request['roles']);

    return back()->with("message", "User Created successfully!");
    }
    public function index()
    {

        $user_count = User::where('id', '!=' ,4)->count();
        $new_procedure = ProcedureList::where('status',0)->count();
        $new_benefit = BenefitList::where('status',0)->count();
        $new_risk = RiskList::where('status',0)->count();
        $new_procedure_pending = ProcedureList::join('users', 'users.id', '=', 'procedure_list.userid')
                    ->where('procedure_list.status',0)
                    ->orderBy('procedure_list.id','DESC')
                    ->get(['users.*', 'procedure_list.*']);
        $new_benefit_pending = BenefitList::leftjoin('procedure_list', 'benefit_list.procedure_id', '=', 'procedure_list.id')
        ->leftjoin('users', 'benefit_list.userid', '=', 'users.id')
                    ->where('benefit_list.status',0)
                    ->orderBy('benefit_list.id','DESC')
                    ->get(['users.*', 'benefit_list.*', 'procedure_list.procedure_name','procedure_list.procedure_code']);
        $new_risk_pending = RiskList::join('procedure_list', 'risk_list.procedure_id', '=', 'procedure_list.id')
        ->join('users', 'risk_list.userid', '=', 'users.id')
                    ->where('risk_list.status',0)
                    ->orderBy('risk_list.id','DESC')
                    ->get(['users.*', 'risk_list.*', 'procedure_list.procedure_name','procedure_list.procedure_code']);
        return view('admin.home', compact('user_count','new_procedure','new_benefit','new_risk','new_procedure_pending','new_benefit_pending','new_risk_pending'));
        // return view('admin.home');
    }

    public function fetch_admin_procedure(Request $request){
        
        $data = ProcedureList::leftjoin('users', 'users.id', '=', 'procedure_list.userid')
        ->where(function ($q) use ($request){

            if($request->get('searchval') != ''){
                $q->orwhere('procedure_list.procedure_name','like', '%' . $request->get('searchval') . '%');
        }
        if($request->get('statusval') != ''){
                $q->where('procedure_list.status',$request->get('statusval'));
        }

        })
                    ->orderBy('procedure_list.id','DESC')
                    ->get(['users.*', 'procedure_list.*']);

        $dataArray = array(
  'procedure'   => $data
 );
    
        return response()->json($dataArray);
    }

    
    public function submit_new_procedure_admin(Request $request)
    {
$code_gen = random_int(100, 999);
        $ProcedureList_db = ProcedureList::create([
            'procedure_name' => $request->new_procedure_input,
            'status' => 1,
            'userid' => Auth::user()->id,
            'procedure_code' => 'P-'.$code_gen
        ]);
       $ProcedureList_db_lastid = $ProcedureList_db->id;
       return response()->json($ProcedureList_db_lastid);
   }

   public function procedure($id)
    {
        $single_proc = ProcedureList::where('procedure_list.procedure_code',$id)
        ->join('users', 'procedure_list.userid', '=', 'users.id')
                    ->first(['users.fname','users.lname','procedure_list.*']);
                    // dd($single_proc);
        $single_proc_benfit = BenefitList::where('benefit_list.procedure_id',$single_proc->id)
        ->join('users', 'benefit_list.userid', '=', 'users.id')
        ->orderBy('benefit_list.id','DESC')
                    ->get(['users.*','benefit_list.*']);
        $getallid_select_benefit = BenefitList::where('procedure_id',$single_proc->id)
        ->pluck('code');
        // dd($getallid_select_benefit);
        $single_proc_all_benfit = BenefitList::join('users', 'benefit_list.userid', '=', 'users.id')
            ->whereNotIn('benefit_list.code',$getallid_select_benefit)
            ->where('benefit_list.status',1)
            ->groupBy('benefit_list.code')
            ->orderBy('benefit_list.id','DESC')
                    ->get(['users.*','benefit_list.*']);

        $single_proc_risk = RiskList::where('risk_list.procedure_id',$single_proc->id)
        ->join('users', 'risk_list.userid', '=', 'users.id')
        ->orderBy('risk_list.id','DESC')
                    ->get(['users.*','risk_list.*']);
        $getallid_select_risk = RiskList::where('procedure_id',$single_proc->id)
        ->pluck('code');
        // dd($getallid_select_risk);
        $single_proc_all_risk = RiskList::join('users', 'risk_list.userid', '=', 'users.id')
            ->whereNotIn('risk_list.code',$getallid_select_risk)
            ->where('risk_list.status',1)
            ->groupBy('risk_list.code')
            ->orderBy('risk_list.id','DESC')
                    ->get(['users.*','risk_list.*']);
        return view('admin.procedure', compact('single_proc','single_proc_benfit','single_proc_all_benfit','single_proc_risk','single_proc_all_risk'));
    }

    public function admin_procedure_status(Request $request, $id){

        $upd_procstatus = ProcedureList::findOrFail($id);
        $upd_procstatus['status'] = $request->statusget;
        $upd_procstatus['procedure_name'] = $request->proc_name;
        $upd_procstatus->update();

        session()->flash('message', 'Successfully updated the status!');
        return redirect()->back();
}


public function submit_new_benefitrisk_admin(Request $request){

if($request->new_benefit_status_input == 'ben'){


$code_gen_ben = random_int(100, 999);

$benefit_db_ins =  BenefitList::create([
        'benefit_name'=>$request->new_benefit_name_input,
        'code'=>'B-'.$code_gen_ben,
        'statistics'=>$request->new_benefit_statistics_input,
        'detail'=>$request->new_benefit_detail_input,
        'procedure_id'=>$request->proc_id,
        'status'=>1,
        'userid'=>Auth::user()->id
]);
 
    
        session()->flash('message', 'Successfully Created Benefit!');
        return response()->json($code_gen_ben);
    }
    else{

$code_gen_ben = random_int(100, 999);

$benefit_db_ins =  RiskList::create([
        'risk_name'=>$request->new_benefit_name_input,
        'code'=>'R-'.$code_gen_ben,
        'statistics'=>$request->new_benefit_statistics_input,
        'detail'=>$request->new_benefit_detail_input,
        'procedure_id'=>$request->proc_id,
        'status'=>1,
        'userid'=>Auth::user()->id
]);
 
    
        session()->flash('message', 'Successfully Created Risk!');
        return response()->json($code_gen_ben);
    }
    }

    
    public function admin_benrisk_moveleftside(Request $request){
        if($request->name == 'ben'){
            $single_proc = BenefitList::where('code',$request->code)
                    ->first();
        $benefit_db_ins =  BenefitList::create([
        'benefit_name'=>$single_proc->benefit_name,
        'code'=>$single_proc->code,
        'statistics'=>$single_proc->statistics,
        'detail'=>$single_proc->detail,
        'procedure_id'=>$request->procid,
        'status'=>$single_proc->status,
        'userid'=>$single_proc->userid
]);
        }
        else{
$single_proc = RiskList::where('code',$request->code)
                    ->first();
        $benefit_db_ins =  RiskList::create([
        'risk_name'=>$single_proc->risk_name,
        'code'=>$single_proc->code,
        'statistics'=>$single_proc->statistics,
        'detail'=>$single_proc->detail,
        'procedure_id'=>$request->procid,
        'status'=>$single_proc->status,
        'userid'=>$single_proc->userid
]);
        }
        return response()->json($request);
    }

    public function admin_benrisk_moverightside(Request $request){
        if($request->name == 'ben'){
            $single_proc_count = BenefitList::where('code',$request->code)
                    ->count();
            if($single_proc_count > 1){
                $delete = BenefitList::findOrFail($request->id);
                $delete->delete();
            }
            else{
        $upd = BenefitList::findOrFail($request->id);
        $upd['procedure_id'] = 0;
        $upd->update();
            }
        
        return response()->json($single_proc_count);
        }
        else{
            $single_proc_count = RiskList::where('code',$request->code)
                    ->count();
            if($single_proc_count > 1){
                $delete = RiskList::findOrFail($request->id);
                $delete->delete();
            }
            else{
        $upd = RiskList::findOrFail($request->id);
        $upd['procedure_id'] = 0;
        $upd->update();
            }
        
        return response()->json($single_proc_count);
        }
    }

    
     public function admin_benfit_status(Request $request, $id){

        $upd = BenefitList::where('code',$id)
        ->update([
           'status' => $request->statusget_ben
        ]);

        session()->flash('message', 'Successfully updated the status!');
        return redirect()->back();
}

 public function admin_risk_status(Request $request, $id){

        $upd = RiskList::where('code',$id)
        ->update([
           'status' => $request->statusget_risk
        ]);

        session()->flash('message', 'Successfully updated the status!');
        return redirect()->back();
}
}
