

<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
            <div class="page-header">
              <h3 class="page-title">
                <span class="page-title-icon bg-gradient-primary text-white me-2">
                  <i class="mdi mdi-clipboard-text"></i>
                </span> Edited Benefit & Risk
              </h3>
            </div>
            <?php echo $__env->make('admin.inc.notify', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="row">
              <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title">All Benefits & Risks</h4>
                    <table class="table table-striped">
                      <thead>
                        <tr>
                          <th> # </th>
                          <!-- <th> Procedure </th> -->
                          <th> Code </th>
                          <th> Name </th>
                          <th> Edited Name </th>
                          <th> Edited Detail </th>
                          <th> Type</th>
                          <th> User </th>
                          <th> Status </th>
                          <th> Created_at </th>
                          <th> Action </th>
                        </tr>
                      </thead>
                      <tbody>

                        <?php
                        $count = 0;
                        ?>
                        <?php $__currentLoopData = $new_benefit_pending; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new_benefit_pending_get): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        $count++;
                        ?>
                        <tr>
                          <td> <?php echo e($count); ?> </td>
                          <td> <?php echo e($new_benefit_pending_get->code); ?> </td>
                          <td> <?php echo e($new_benefit_pending_get->oldname); ?> </td>
                          <td> <?php echo e($new_benefit_pending_get->edit_name); ?> </td>
                          <td> <?php echo e($new_benefit_pending_get->edit_detail); ?> </td>
                          <td> <?php echo e($new_benefit_pending_get->type); ?> </td>
                          <td> <?php echo e($new_benefit_pending_get->fname); ?> <?php echo e($new_benefit_pending_get->lname); ?> </td>
                          <?php if($new_benefit_pending_get->status == 0): ?>
                          <td> <label class="badge badge-gradient-danger">Pending</label> </td>
                          <?php else: ?>
                          <td> <label class="badge badge-gradient-success">Done</label> </td>
                          <?php endif; ?>
                          <td> <?php echo e($new_benefit_pending_get->created_at); ?> </td>
                          <td> <a href="javascript:void(0);" class="changestatus_alternate_proc" data-code="<?php echo e($new_benefit_pending_get->code); ?>" data-id="<?php echo e($new_benefit_pending_get->id); ?>" data-status="<?php echo e($new_benefit_pending_get->status); ?>">change status</a> <a href="javascript:void(0);" class="delete_benrisk" data-code="<?php echo e($new_benefit_pending_get->id); ?>">delete</a></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
            
            
          </div>

<div class="modal fade zoomIn" id="newBenefit_Modal" tabindex="-1" data-bs-keyboard="false" data-bs-backdrop="static" aria-hidden="true" role="dialog">
          <div class="modal-dialog modal-dialog-centered modal-md">
            <div class="modal-content">
                <div class="modal-header">
        <h4 class="modal-title">Edit Benefits</h4>
      </div>
      <form method="POST" action="<?php echo e(url('submit_edit_benefitrisk_admin')); ?>" id="edit_benefitrisk_form">
        <?php echo csrf_field(); ?>
                <div class="modal-body" style="">
                <div class="row">
                            <div class="col-md-6">
                                <label class="form-label">Name</label>
                                <input name="new_benefit_code_input" type="hidden" class="new_benefit_code_input form-control input" value="">
                                <input name="statusval" type="hidden" class="statusval form-control input" value="ben">
                                <input name="new_benefit_name_input" required type="text" class="new_benefit_name_input form-control input">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Statistics</label>
                                <input name="new_benefit_statistics_input" type="text" class="new_benefit_statistics_input form-control input">
                            </div>
                            <div class="col-md-12 mt-2">
                                <label class="form-label">Detail</label>
                                <input name="new_benefit_detail_input" required type="text" class="new_benefit_detail_input form-control input">
                            </div>
                            <div class="col-md-12 mt-2">
                              <label class="form-label">Status</label>
                            <select name="statusget_benrisk" class="statusget_benrisk form-control input">
                        <option value="1">Done</option>
                        <option value="0">Pending</option>
                    </select>
                  </div>
                            </div>

                </div>
                 <div class="modal-footer">
        <button type="button" class="btn btn-gradient-danger btn-fw btn_close_modal" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-gradient-success btn-fw add_newben_submit_btn">SUBMIT</button>
        <button type="button" class="btn btn-gradient-success btn-fw add_newben_submit_btn_loader" style="display:none;">Waiting...</button>
      </div>
  </form>
                </div>
            </div>
          </div>
<script type="text/javascript">
  $(document).on('click','.edit_benrisk',function(){
    var code = $(this).attr('data-code');
    // alert(code)
    var path_get_procedure = "<?php echo e(url('fetch_admin_benrisk_edit')); ?>";
    $.ajax({
            url: path_get_procedure,
            type: 'GET',
            dataType: "json",
            data: {
               code: code,
               statusval: 'ben'
            },
            success: function( data ) { 
              console.log(data)
for (var i = 0; i < data.length; i++) {
$('.new_benefit_code_input').val(data[i].code)
$('.new_benefit_name_input').val(data[i].benefit_name)
$('.new_benefit_statistics_input').val(data[i].statistics)
$('.new_benefit_detail_input').val(data[i].detail)
$(".statusget_benrisk option[value="+data[i].status+"]").prop("selected", true);
}
              $('#newBenefit_Modal').modal('show')
              
            }
          });
  })

  $(document).on('click','.delete_benrisk',function(){
    var code = $(this).attr('data-code');
    // alert(code)
    // Prompt the user for their password
    var adminPassword = prompt('Enter admin password:');

    if (adminPassword === null) {
        // User clicked Cancel
        return;
    }

// Continue with form submission if the admin password matches
    if (checkAdminPassword(adminPassword)) {
    var path_get_procedure = "<?php echo e(url('edited_admin_benrisk_delete')); ?>";
    $.ajax({
            url: path_get_procedure,
            type: 'GET',
            dataType: "json",
            data: {
               code: code,
               statusval: 'ben'
            },
            success: function( data ) { 
              console.log(data)
              location.reload(true)
              
            }
          });
     } else {
        // Show an alert if the passwords do not match
        alert('Incorrect admin password!');
    }
  })

  $(document).on('click','.btn_close_modal',function(){
        $('#newBenefit_Modal').modal('hide');
    });


$('#edit_benefitrisk_form').submit(function(e) {
        e.preventDefault();
        $('.add_newben_submit_btn').hide();
        $('.add_newben_submit_btn_loader').show();
        let formData = new FormData(this);
        $.ajaxSetup({
          headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
      });
         $.ajax({
        // headers: {
        //     'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')
        // },
        url: $(this).attr('action'),
        type: $(this).attr('method'),
        data: formData,
         processData: false,
    contentType: false,
    cache: false,
        dataType: "json",
         success: function(data) {
            console.log(data);
            
        $('.add_newben_submit_btn').show();
        $('.add_newben_submit_btn_loader').hide();
        $('#newBenefit_Modal').modal('hide')
        // fetchproc($('#search_proc').val(),$('#search_status').val());
        location.reload()
        },
        error: function(err) {
            console.log(err)
        }
    });
    });

$(document).on('click','.changestatus_alternate_proc',function(){
    var id = $(this).attr('data-id');
    var code = $(this).attr('data-code');
    var status = $(this).attr('data-status');
    if(status == 1){
      status = 0;
    }
    else{
      status = 1;
    }
    var adminPassword = prompt('Enter admin password:');

    if (adminPassword === null) {
        // User clicked Cancel
        return;
    }

// Continue with form submission if the admin password matches
    if (checkAdminPassword(adminPassword)) {
    var path_get_procedure = "<?php echo e(url('changestatus_edited_benrisk')); ?>";
    $.ajaxSetup({
          headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
      });
    $.ajax({
            url: path_get_procedure,
            type: 'POST',
            dataType: "json",
            data: {
               id: id,
               code: code,
               status: status
            },
            success: function( data ) { 
              console.log(data)
              location.reload(true)
              
            }
          });
     } else {
        // Show an alert if the passwords do not match
        alert('Incorrect admin password!');
    }
  })
function checkAdminPassword(password) {
    return password === 'admin@123';
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\surgery\resources\views/admin/edited_benrisk.blade.php ENDPATH**/ ?>