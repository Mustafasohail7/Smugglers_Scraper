

<?php $__env->startSection('content'); ?>
<style type="text/css">
	.card .card-body {
    padding: 0.5rem 0.5rem;
}

</style>
<div class="content-wrapper">
            <div class="page-header">
              <h3 class="page-title">
                <span class="page-title-icon bg-gradient-primary text-white me-2">
                  <i class="mdi mdi-home"></i>
                </span> Dashboard
              </h3>
            </div>
            <?php echo $__env->make('admin.inc.notify', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="row">
              <div class="col-md-3 stretch-card grid-margin">
                <div class="card bg-gradient-danger card-img-holder text-white">
                  <div class="card-body">
                    <img src="assets/images/dashboard/circle.svg" class="card-img-absolute" alt="circle-image" />
                    <h4 class="font-weight-normal mb-3">Total Users
                    </h4>
                    <h2 class=""><?php echo e($user_count); ?></h2>
                  </div>
                </div>
              </div>
              <div class="col-md-3 stretch-card grid-margin">
                <div class="card bg-gradient-info card-img-holder text-white">
                  <div class="card-body">
                    <img src="assets/images/dashboard/circle.svg" class="card-img-absolute" alt="circle-image" />
                    <h4 class="font-weight-normal mb-3">New Procedures
                    </h4>
                    <h2 class=""><?php echo e($new_procedure); ?></h2>
                  </div>
                </div>
              </div>
              <div class="col-md-3 stretch-card grid-margin">
                <div class="card bg-gradient-success card-img-holder text-white">
                  <div class="card-body">
                    <img src="assets/images/dashboard/circle.svg" class="card-img-absolute" alt="circle-image" />
                    <h4 class="font-weight-normal mb-3">New Benefits
                    </h4>
                    <h2 class="mb-5"><?php echo e($new_benefit); ?></h2>
                  </div>
                </div>
              </div>

              <div class="col-md-3 stretch-card grid-margin">
                <div class="card bg-gradient-primary card-img-holder text-white">
                  <div class="card-body">
                    <img src="assets/images/dashboard/circle.svg" class="card-img-absolute" alt="circle-image" />
                    <h4 class="font-weight-normal mb-3">New Risks
                    </h4>
                    <h2 class="mb-5"><?php echo e($new_risk); ?></h2>
                  </div>
                </div>
              </div>
            </div>

            <div class="row">
              <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title">New Procedure (Pending)</h4>
                    <table class="table table-striped">
                      <thead>
                        <tr>
                          <th> #</th>
                          <th> Procedure Code </th>
                          <th> Procedure Name </th>
                          <th> User </th>
                          <th> Status </th>
                          <th> Created_at </th>
                        </tr>
                      </thead>
                      <tbody>

                        <?php
                        $count = 0;
                        ?>
                        <?php $__currentLoopData = $new_procedure_pending; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new_procedure_pending_get): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php
                        $count++;
                        ?>
                        <tr>
                          <td> <?php echo e($count); ?> </td>
                          <td> <a href="<?php echo e(url('/procedure/'.$new_procedure_pending_get->procedure_code)); ?>"><?php echo e($new_procedure_pending_get->procedure_code); ?></a> </td>
                          <td> <?php echo e($new_procedure_pending_get->procedure_name); ?> </td>
                          <td> <?php echo e($new_procedure_pending_get->fname); ?> <?php echo e($new_procedure_pending_get->lname); ?> </td>
                          <?php if($new_procedure_pending_get->status == 0): ?>
                          <td> <label class="badge badge-gradient-danger">Pending</label> </td>
                          <?php else: ?>
                          <td> <label class="badge badge-gradient-danger">Done</label> </td>
                          <?php endif; ?>
                          <td> <?php echo e($new_procedure_pending_get->created_at); ?> </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>

            <div class="row">
              <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title">New Benefit (Pending)</h4>
                    <table class="table table-striped">
                      <thead>
                        <tr>
                          <th> # </th>
                          <!-- <th> Procedure </th> -->
                          <th> Benefit Code </th>
                          <th> Benefit Name </th>
                          <th> Benefit statistics </th>
                          <th> User </th>
                          <th> Status </th>
                          <th> Created_at </th>
                        </tr>
                      </thead>
                      <tbody>

                        <?php
                        $count = 0;
                        ?>
                        <?php $__currentLoopData = $new_benefit_pending; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new_benefit_pending_get): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php
                        $count++;
                        ?>
                        <tr>
                          <td> <?php echo e($count); ?> </td>
                          <!-- <td> <a href="<?php echo e(url('/procedure/'.$new_benefit_pending_get->procedure_code)); ?>"><?php echo e($new_benefit_pending_get->procedure_name); ?> (<?php echo e($new_benefit_pending_get->procedure_code); ?>)</a> </td> -->
                          <td> <?php echo e($new_benefit_pending_get->code); ?> </td>
                          <td> <?php echo e($new_benefit_pending_get->benefit_name); ?> </td>
                          <td> <?php echo e($new_benefit_pending_get->statistics); ?> </td>
                          <td> <?php echo e($new_benefit_pending_get->fname); ?> <?php echo e($new_benefit_pending_get->lname); ?> </td>
                          <?php if($new_benefit_pending_get->status == 0): ?>
                          <td> <label class="badge badge-gradient-danger">Pending</label> </td>
                          <?php else: ?>
                          <td> <label class="badge badge-gradient-success">Done</label> </td>
                          <?php endif; ?>
                          <td> <?php echo e($new_benefit_pending_get->created_at); ?> </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>

            <div class="row">
              <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title">New Risk (Pending)</h4>
                    <table class="table table-striped">
                      <thead>
                        <tr>
                          <th> # </th>
                          <!-- <th> Procedure </th> -->
                          <th> Risk Code </th>
                          <th> Risk Name </th>
                          <th> Risk statistics </th>
                          <th> User </th>
                          <th> Status </th>
                          <th> Created_at </th>
                        </tr>
                      </thead>
                      <tbody>

                        <?php
                        $count = 0;
                        ?>
                        <?php $__currentLoopData = $new_risk_pending; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new_risk_pending_get): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php
                        $count++;
                        ?>
                        <tr>
                          <td> <?php echo e($count); ?> </td>
                          <!-- <td> <a href="<?php echo e(url('/procedure/'.$new_risk_pending_get->procedure_code)); ?>"><?php echo e($new_risk_pending_get->procedure_name); ?> (<?php echo e($new_risk_pending_get->procedure_code); ?>)</a> </td> -->
                          <td> <?php echo e($new_risk_pending_get->code); ?> </td>
                          <td> <?php echo e($new_risk_pending_get->risk_name); ?> </td>
                          <td> <?php echo e($new_risk_pending_get->statistics); ?> </td>
                          <td> <?php echo e($new_risk_pending_get->fname); ?> <?php echo e($new_risk_pending_get->lname); ?> </td>
                          <?php if($new_risk_pending_get->status == 0): ?>
                          <td> <label class="badge badge-gradient-danger">Pending</label> </td>
                          <?php else: ?>
                          <td> <label class="badge badge-gradient-danger">Done</label> </td>
                          <?php endif; ?>
                          <td> <?php echo e($new_risk_pending_get->created_at); ?> </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
            
            
          </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\surgery\resources\views/admin/home.blade.php ENDPATH**/ ?>