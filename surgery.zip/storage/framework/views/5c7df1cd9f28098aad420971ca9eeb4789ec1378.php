

<?php $__env->startSection('content'); ?>
<script src="https://cdn.ckeditor.com/ckeditor5/39.0.1/classic/ckeditor.js"></script>
<style>
.ck-editor__editable_inline {
    min-height: 300px;
}
</style>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Create new web page')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                     <form method="POST" action="<?php echo e(url('createwebpage')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="row mb-3">
                            <label for="name" class="col-md-12 col-form-label"><?php echo e(__('Web Page Name')); ?></label>

                            <div class="col-md-12">
                                <input id="name" type="text" class="input form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>

                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="content" class="col-md-12 col-form-label"><?php echo e(__('Web Page Content')); ?></label>

                            <div class="col-md-12">
                                <textarea class="form-control" id="content" name="content"></textarea>

                                <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                         <div class="row mb-0">
                            <div class="col-md-12">
                                <button type="submit" class="btn btn-primary roundbtn">
                                    <?php echo e(__('Save')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                    <!-- <?php echo e(Crypt::decryptString(Auth::user()->cardnumber)); ?> -->
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    ClassicEditor
        // .create( document.querySelector( '#webpagecontent' ) )
     .create( document.querySelector( '#content' ),{
                ckfinder: {
                    uploadUrl: '<?php echo e(url('image.upload').'?_token='.csrf_token()); ?>',
        }
            })
        .then( editor => {
        editor.ui.view.editable.element.style.height = '300px';
    } )
        .catch( error => {
            console.error( error );
        } );
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\qrcode\resources\views/createWebpage.blade.php ENDPATH**/ ?>