<?php $__env->startSection('content'); ?>
<style type="text/css">
     .input-date {
  border: 0px solid #ccc;
  display: flex;
  widtH: 110px;
  position: relative;
  transition: 0.15s ease-in-out;
      padding: 0px 0px 0px 0px;
      border-top: 1px solid #ccc !important;
      border-bottom: 1px solid #ccc !important;
      height: 35px;

}
 
 .input-date:after {
  content: "/";
  position: absolute;
  color: #ccc;
  width: 3px;
  height: 22px;
  top: 50%;
  lefT: 35%;
  transform: translate(-50%, -50%);
}
 .input-date input {
  padding: 0px;
  width: 55px;
  text-transform: uppercase;
  display: block;
  border: none;
  outline: 0;
  background: none;
}
.input-date input:focus{
    background: none !important;
  outline: none !important;
  border: none !important;
  padding: 0px !important;
   box-shadow: none !important;
}
.input-date input:active{
    background: none !important;
  outline: none !important;
  border: none !important;
  padding: 0px !important;
   box-shadow: none !important;
}
.cvv input {
  width: 100%;
  padding: 5px;
  text-align: right;
  background: none;
  outline: 0;
  border: 0px solid #ccc;
/*  border:none;*/
border-radius: 0px 7px 7px 0px;
border-top: 1px solid #ccc !important;
      border-bottom: 1px solid #ccc !important;
      border-right: 1px solid #ccc !important;
}
.cvv input:focus{
    background: none !important;
  outline: none !important;
  border: 0px solid #ccc !important;
  padding: 5px !important;
   box-shadow: none !important;
   border-radius: 0px 7px 7px 0px;
border-top: 1px solid #ccc !important;
      border-bottom: 1px solid #ccc !important;
      border-right: 1px solid #ccc !important;
      border-left: px solid !important;
}
.cvv input:active{
    background: none !important;
  outline: none !important;
  border: 0px solid #ccc !important;
  padding: 5px !important;
   box-shadow: none !important;
   border-radius: 0px 7px 7px 0px;
border-top: 1px solid #ccc !important;
      border-bottom: 1px solid #ccc !important;
      border-right: 1px solid #ccc !important;
      border-left: px solid !important;
}
.cardnum input{
width: 100%;
  padding: 5px;
  background: none;
  outline: 0;
  border: 1px solid #ccc;
  border-radius: 7px 0px 0px 7px;
      border-right: 0px solid !important;
}
.cardnum input:focus{
    background: none !important;
  outline: none !important;
  border: 1px solid #ccc !important;
  padding: 5px !important;
   box-shadow: none !important;
   border-right: 0px solid !important;
}
.cardnum input:active{
    background: none !important;
  outline: none !important;
  border: 1px solid #ccc !important;
  padding: 5px !important;
   box-shadow: none !important;
   border-right: 0px solid !important;
}

.cardnum{
        padding: 0px 0px 0px 12px;
}
.cvv{
        padding: 0px 0px 0px 0px;
}
.input{
    background: none;
  outline: none;
  border: 1px solid #ccc !important;
  padding: 5px !important;
}
.input:focus{
    background: none !important;
  outline: none !important;
  border: 1px solid #ccc !important;
  padding: 5px !important;
   box-shadow: none !important;
}
.input:active{
    background: none !important;
  outline: none !important;
  border: 1px solid #ccc !important;
  padding: 5px !important;
   box-shadow: none !important;
}
.headingcard{
    text-align: center;
    margin: 0px 0px 0px 35px;
    font-size: 20px;
    font-weight: bold;
    font-family: inherit;
}
.cardwarning{
        margin: 0px 15px 0px 0px;
    font-size: 14px;
    text-align: right;
}
.invalid-feedback {
     display: block;
    }
 .terms_box{
    background: #e9e6e6;
    /* color: beige; */
    font-size: 16px;
    padding: 10px;
    border-radius: 10px;
    height: 150px;
    overflow-y: auto;
}
.terms_box:hover{
background: #f8fafe;
}
.btn-custom{
    background: grey !important;

}
</style>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header"><?php echo e(__('Register')); ?></div>

                <div class="card-body">
                    <form id="payment-form" method="POST" action="<?php echo e(url('registerstore')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="row mb-3">

                             <label for="title" class="col-md-2 col-form-label text-md-end">Title</label>

                            <div class="col-md-10">
                                 <select class="form-control" id="title" name="title">
                                    <option value="Dr">Dr</option>
                                    <option value="Mr">Mr</option>
                                    <option value="Mrs">Mrs</option>
                                </select>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="fname" class="col-md-2 col-form-label text-md-end">First Name</label>

                            <div class="col-md-10">
                                <input name="fname" type="text" required class="form-control <?php $__errorArgs = ['fname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="fname" placeholder="First Name">
                                <?php $__errorArgs = ['fname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="lname" class="col-md-2 col-form-label text-md-end">Last Name</label>

                            <div class="col-md-10">
                                 <input name="lname" type="text" required class="form-control <?php $__errorArgs = ['lname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="lname" placeholder="Last Name">
                                <?php $__errorArgs = ['lname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="email" class="col-md-2 col-form-label text-md-end">Email</label>

                            <div class="col-md-10">
                                <input name="email" type="email" required class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email" placeholder="Email">
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        

                        <div class="row mb-3">
                            <label for="password" class="col-md-2 col-form-label text-md-end"><?php echo e(__('Password')); ?></label>

                            <div class="col-md-10" style="position:relative;">
                                <p style="position: absolute;
    right: 20px;
    font-size: 14px;
    color: orange;
    font-weight: bold;bottom: -15px;">The password must be atleast 8 characters.</p>
                                <input id="password" type="password" class="input form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" minlength="6" required autocomplete="new-password" placeholder="Password">

                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="password-confirm" class="col-md-2 col-form-label text-md-end"><?php echo e(__('Confirm Password')); ?></label>

                            <div class="col-md-10">
                                <input id="password-confirm" type="password" class="input form-control" name="password_confirmation" required autocomplete="new-password" placeholder="Confrim Password">
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="phone" class="col-md-2 col-form-label text-md-end">Phone</label>

                            <div class="col-md-10">
                                <input id="phone" type="tel" class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="phone" placeholder="Phone" >
                                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="qualification" class="col-md-2 col-form-label text-md-end">Qualification</label>

                            <div class="col-md-10">
                                <input id="qualification" type="tel" class="form-control <?php $__errorArgs = ['qualification'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="qualification" required placeholder="Qualification">
                                <?php $__errorArgs = ['qualification'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="practicename" class="col-md-2 col-form-label text-md-end">Practice Name</label>

                            <div class="col-md-10">
                                <input id="practicename" type="tel" class="form-control <?php $__errorArgs = ['practicename'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="practicename" required placeholder="Practice Name">
                                <?php $__errorArgs = ['practicename'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                         <div class="row mb-3">
                            <label for="practicename" class="col-md-2 col-form-label text-md-end">EULA</label>

                            <div class="col-md-10">
                                <div class="terms_box"><?php echo $eula->text; ?></div>
                            </div>
                        </div>

                        

                        <div class="row">
                            <div class="col-md-10">
                                <input id="roles" type="hidden" class="form-control" name="roles" value="2">
                            </div>
                        </div>

<div class="row mb-3">
            <div class="col-md-10 offset-md-4">
    <div class="form-check">
  <input class="form-check-input" type="checkbox" id="privacy_policy" name="privacy_policy">
  <label class="form-check-label" for="privacy_policy">I have read and accept the terms above</label>
</div>

<?php $__errorArgs = ['privacy_policy'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong>The terms must be accepted.</strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
</div>

                        <div class="row mb-0">
                            <div class="col-md-10 offset-md-4">
                                <button type="submit" class="btn btn-primary btnsubmit btn-custom" disabled>
                                    <?php echo e(__('Register')); ?>

                                </button>
                                <a href="<?php echo e(route('login')); ?>"><?php echo e(__('Login Now')); ?></a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    $(document).on('change','#privacy_policy',function(){
        if($(this).is(':checked')){
            $('.btnsubmit').removeClass('btn-custom')
            $('.btnsubmit').removeAttr('disabled')
        }
        else{
            $('.btnsubmit').addClass('btn-custom')
            $('.btnsubmit').attr('disabled','disabled')
        }
    })
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\surgery\resources\views/auth/register.blade.php ENDPATH**/ ?>