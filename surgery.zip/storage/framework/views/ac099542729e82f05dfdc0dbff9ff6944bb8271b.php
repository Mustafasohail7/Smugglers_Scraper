<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="icon" type="image/png" href="<?php echo e(asset('favicon.ico')); ?>">
    <title>My QR Code Page</title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=Nunito" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>

    <!-- <script src="https://www.google.com/recaptcha/api.js" async defer></script> -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
<link rel="stylesheet" href="<?php echo e(asset('build/css/intlTelInput.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">

  <link rel="stylesheet" href="<?php echo e(asset('build/css/demo.css')); ?>">

    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>
</head>
<body>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
            <div class="container">
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    <img src="<?php echo e(url('/images/logo.png')); ?>" alt="logo" style="width: 200px;">
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav me-auto">

                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ms-auto">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <?php if(Route::has('login')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                                </li>
                            <?php endif; ?>

                            <?php if(Route::has('register')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php else: ?>
                        <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(url('home')); ?>"><?php echo e(__('Home')); ?></a>
                                </li>
                        <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(url('webpage')); ?>"><?php echo e(__('Create a web page')); ?></a>
                                </li>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(Auth::user()->fname); ?> <?php echo e(Auth::user()->lname); ?>

                                </a>

                                <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        <main class="py-4">
            
            <?php if($flash = session('message')): ?>
        <div class="container" style="justify-content: center;display: flex;">
            <div class="col-md-4">
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e($flash); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
            </div>
        </div>
        <?php elseif($flash = session('error')): ?>
        <div class="container" style="justify-content: center;display: flex;">
            <div class="col-md-4">
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo e($flash); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            </div>
        </div>
        <?php endif; ?>
            <?php echo $__env->yieldContent('content'); ?>
        </main>

        <footer class="footer text-center text-white" style="background-color: #f1f1f1;">
  <!-- Grid container -->
  <div class="container pt-4">
    <!-- Section: Social media -->
    <section class="mb-4">
      <!-- Facebook -->
      <a
        class="btn btn-link btn-floating btn-lg text-dark m-1"
        href="#!"
        role="button"
        data-mdb-ripple-color="dark"
        >Privacy</i
      ></a>

      <!-- Twitter -->
      <a
        class="btn btn-link btn-floating btn-lg text-dark m-1"
        href="#!"
        role="button"
        data-mdb-ripple-color="dark"
        >Terms and Conditions</i
      ></a>

      <!-- Google -->
      <a
        class="btn btn-link btn-floating btn-lg text-dark m-1"
        href="#!"
        role="button"
        data-mdb-ripple-color="dark"
        >Tou</i
      ></a>

      <!-- Instagram -->
      <a
        class="btn btn-link btn-floating btn-lg text-dark m-1"
        href="#!"
        role="button"
        data-mdb-ripple-color="dark"
        >Abuse</i
      ></a>
    </section>
    <!-- Section: Social media -->
  </div>
  <!-- Grid container -->

  <!-- Copyright -->
  <div class="text-center text-dark p-3" style="background-color: rgba(0, 0, 0, 0.2);">
    © 2023 Copyright:
    <a class="text-dark" href="https://mdbootstrap.com/">My Qr Code Page</a>
  </div>
  <!-- Copyright -->
</footer>
    </div>
</body>
</html>

<script src="<?php echo e(asset('build/js/intlTelInput.js')); ?>"></script>
<!-- <script src="<?php echo e(asset('js/html2canvas.js')); ?>"></script> -->
       <script src="https://unpkg.com/jspdf@latest/dist/jspdf.umd.min.js"></script>
       <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js" integrity="sha512-GsLlZN/3F2ErC5ifS5QtgpiJtWd43JWSuIgh7mbzZ8zBps+dvLusV+eNQATqgA/HdeKFVgA5v3S/cIrLF7QnIg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script> -->
       <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>



<script type="text/javascript">

 $('.saveimg1_qr').click(function(){
    // html2canvas($('#img1_qr'), {
    html2canvas($("#img1_qr")[0]).then((canvas) => {
    // onrendered: function(canvas) {                    
      var img = canvas.toDataURL("image/png");
      
      var uri = img.replace(/^data:image\/[^;]/, 'data:application/octet-stream');
      
      var link = document.createElement('a');
          if (typeof link.download === 'string') {
              document.body.appendChild(link); 
              link.download = 'QRCode_56x56.png';
              link.href = uri;
              link.click();
              document.body.removeChild(link);
          } else {
              location.replace(uri);
          }
      
    // }
  }); 
  })


 $('.saveimg2_qr').click(function(){
    // html2canvas($('#img1_qr'), {
    html2canvas($("#img2_qr")[0]).then((canvas) => {
    // onrendered: function(canvas) {                   
      var img = canvas.toDataURL("image/png");
      
      var uri = img.replace(/^data:image\/[^;]/, 'data:application/octet-stream');
      
      var link = document.createElement('a');
          if (typeof link.download === 'string') {
              document.body.appendChild(link); 
              link.download = 'QRCode_95x95.png';
              link.href = uri;
              link.click();
              document.body.removeChild(link);
          } else {
              location.replace(uri);
          }
      
    // }
  }); 
  })


 $('.saveimg3_qr').click(function(){
    // html2canvas($('#img1_qr'), {
    html2canvas($("#img3_qr")[0]).then((canvas) => {
    // onrendered: function(canvas) {                     
      var img = canvas.toDataURL("image/png");
      
      var uri = img.replace(/^data:image\/[^;]/, 'data:application/octet-stream');
      
      var link = document.createElement('a');
          if (typeof link.download === 'string') {
              document.body.appendChild(link); 
              link.download = 'QRCode_150x150.png';
              link.href = uri;
              link.click();
              document.body.removeChild(link);
          } else {
              location.replace(uri);
          }
      
    // }
  }); 
  })

const { jsPDF } = window.jspdf;

    var doc = new jsPDF('l', 'mm', [1200, 1210]);

 $(document).on('click','.savepdf_qr',function(){
      window.html2canvas = html2canvas;
    var pdfjs = document.querySelector('#pdfmaindiv');
    // alert(pdfjs)
    doc.html(pdfjs, {
        callback: function(doc) {
            doc.save("QRCode.pdf");
        },
        x: 10,
        y: 10
    });
});
    $(document).on('click','.viewdwlmodal',function(){
        var hrf = $(this).attr('data-att');
        var name = $(this).attr('data-name');
        $('.webpagenameget').text(name);
        // alert(hrf)
        $('.formmodal_del').attr('action',hrf);
        $('#smallModal').modal('show');

    });
    
    $(document).on('click','.closemodal',function(){
        $('#smallModal').modal('hide');
    });
     $('#cardnumber').on('keyup', function(e){
    // get value of the input field
    var val = $(this).val();
    var newval = '';
    // write regex to remove any space
    val = val.replace(/\s/g, '');
    // iterate through each numver
    for(var i = 0; i < val.length; i++) {
        // add space if modulus of 4 is 0
        if(i%4 == 0 && i > 0) newval = newval.concat(' ');
        // concatenate the new value
        newval = newval.concat(val[i]);
    }
    // update the final value in the html input
    $(this).val(newval);
});

    var input = document.querySelector("#phone");

    window.intlTelInput(input, {

      allowDropdown: true,

      autoHideDialCode: true,

      autoPlaceholder: "on",

      dropdownContainer: document.body,

    //   excludeCountries: ["us"],

      formatOnDisplay: false,

      geoIpLookup: function(callback) {

          callback('au');

        //  $.get("https://ipinfo.io", function() {}, "jsonp").always(function(resp) {

        //   var countryCode = (resp && resp.country) ? resp.country : "";

        //   callback(countryCode);

        //  });

      },

      // hiddenInput: "full_number",

      initialCountry: "auto",

    //   localizedCountries: { 'de': 'Deutschland' },

      nationalMode: true,

    //   onlyCountries: ['us', 'gb', 'ch', 'ca', 'do'],

      placeholderNumberType: "MOBILE",

    //   preferredCountries: ['cn', 'jp'],

      separateDialCode: true,

      utilsScript: "build/js/utils.js",

    });
</script><?php /**PATH C:\xampp\htdocs\qrcode\resources\views/layouts/app.blade.php ENDPATH**/ ?>