<?php $__env->startSection('content'); ?>
<style type="text/css">
  .my_account_orders {
  border-collapse: collapse;
  border-spacing: 0;
/*  max-width: 600px;*/
  width: 100%;
}

.my_account_orders th {
  text-align: left;
}

tr {
  border-bottom: 1px solid #ccc;
}

th,
td {
  padding: 6px;
}

@media 
only screen and (max-width: 600px) {
  /* Force table to not be like tables anymore */
    table, thead, tbody, th, td, tr { 
        display: block; 
    }
  
  /* Hide table headers (but not display: none;, for accessibility) */
    thead tr { 
        position: absolute;
        top: -9999px;
        left: -9999px;
    }
  
  td { 
        /* Behave  like a "row" */
        border: none;
    border-bottom: 1px solid #eee;
    position: relative;
    padding-left: 45%;
    width: 100%;
    justify-content: left;
    display: flex;
    }
  
  td:last-child { 
         border-width: 0;
    }
  
  td:before { 
     content: attr(data-title);
     color: black;
        /* Now like a table header */
        position: absolute;
        /* Top/left values mimic padding */
        top: 6px;
        left: 6px;
        width: 45%; 
        padding-right: 10px; 
        white-space: nowrap;
    }
}
</style>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('All Web Pages')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <table class="my_account_orders">
    <thead>
      <tr>
        <th class="Web Page Name">Web Page Name</th>
        <th></th>
        <th></th>
        <th></th>
      </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $webpage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $webpages): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
      <tr>
        <td width="50%" class="Web Page Name" data-title="Web Page Name"><a href="<?php echo e(url('/page/' . $webpages->pageid)); ?>"><?php echo e($webpages->name); ?></a></td>
        <td style="" data-title="Edit Web Page"><a href="<?php echo e(url('/webpage/' . $webpages->pageid . '/edit')); ?>" class="btn btn-success roundbtn">Edit</a></td>
        <td style="justify-content: center;
    display: flex;" data-title="Download QR Code"><a href="<?php echo e(url('/webpage/' . $webpages->pageid)); ?>" class="btn btn-warning roundbtn">QR Code Download</a></td>
        <td style="" data-title="Delete Web Page"><a href="javascript:void(0);" data-att="<?php echo e(url('/webpage', $webpages->id)); ?>" data-name="<?php echo e($webpages->name); ?>" class="btn btn-danger roundbtn viewdwlmodal">Delete</a></td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table> 
                    <!-- <?php echo e(Crypt::decryptString(Auth::user()->cardnumber)); ?> -->
                </div>
            </div>
        </div>
    </div>
</div>

<!-- small modal -->
<div class="modal fade" id="smallModal" tabindex="-1" role="dialog" aria-labelledby="smallModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-md" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Alert</h3>
                <button type="button" style="    border: none;" class="close closemodal" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="" class="formmodal_del" method="POST">
    <div class="modal-body">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <h5 class="text-center">Are you sure you want to delete this "<span class="webpagenameget"></span>" webpage ?</h5>
    </div>
    <div class="modal-footer">
        <button type="button" class="btn btn-secondary closemodal" data-dismiss="modal">Cancel</button>
        <button type="submit" class="btn btn-danger">Yes, Delete Webpage</button>
    </div>
</form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\qrcode\resources\views/home.blade.php ENDPATH**/ ?>