<div>
    <?php if($flash = session('message')): ?>
        <div class="container" style="justify-content: center;display: flex;">
            <div class="col-md-4">
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e($flash); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
            </div>
        </div>
        <?php elseif($flash = session('error')): ?>
        <div class="container" style="justify-content: center;display: flex;">
            <div class="col-md-4">
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo e($flash); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            </div>
        </div>
        <?php endif; ?>
</div><?php /**PATH C:\xampp\htdocs\surgery\resources\views/admin/inc/notify.blade.php ENDPATH**/ ?>