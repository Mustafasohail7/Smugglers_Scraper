

<?php $__env->startSection('content'); ?>
<script src="https://cdn.ckeditor.com/ckeditor5/39.0.1/classic/ckeditor.js"></script>
<style>
.ck-editor__editable_inline {
    min-height: 300px;
}
</style>
<div class="content-wrapper">
            <div class="page-header">
              <h3 class="page-title">
                <span class="page-title-icon bg-gradient-primary text-white me-2">
                  <i class="mdi mdi-settings"></i>
                </span> Website Setting
              </h3>
            </div>
            <?php echo $__env->make('admin.inc.notify', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="row justify-content-center">
              
              <div class="col-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <form class="forms-sample" action="<?php echo e(url('update_pd_agree')); ?>" method="POST">
                    	<?php echo csrf_field(); ?>
                      <div class="form-group">
                        <label for="title" class="form-label">Medicolegal Patient Agreement</label>
                        <input type="hidden" name="id" value="<?php echo e($pd_agree->id); ?>">
                            <textarea class="form-control" name="mp_agree" style="height: 100px;"><?php echo e($pd_agree->mp_agree); ?></textarea>
                      </div>

                      <div class="form-group">
                        <label for="title" class="form-label">Medicolegal Doctor Agreement</label>
                            <textarea class="form-control" name="md_agree" style="height: 100px;"><?php echo e($pd_agree->md_agree); ?></textarea>
                      </div>


                      
                      <button type="submit" class="btn btn-gradient-primary me-2">Update</button>
                    </form>


                    <form class="forms-sample mt-5" action="<?php echo e(url('update_eula')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                      <div class="form-group">
                        <label for="title" class="form-label">EULA</label>
                         <input type="hidden" name="id" value="<?php echo e($eula->id); ?>">
                            <textarea id="content" name="content"><?php echo e($eula->text); ?></textarea>
                      </div>


                      
                      <button type="submit" class="btn btn-gradient-primary me-2">Update</button>
                    </form>
                  </div>
                </div>
              </div>

            </div>
            
            
          </div>
<script type="text/javascript">
          ClassicEditor
        // .create( document.querySelector( '#webpagecontent' ) )
     .create( document.querySelector( '#content' ),{
                ckfinder: {
                    uploadUrl: '<?php echo e(url('image.upload').'?_token='.csrf_token()); ?>',
        }
            })
        .then( editor => {
        editor.ui.view.editable.element.style.height = '300px';
    } )
        .catch( error => {
            console.error( error );
        } );
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\surgery\resources\views/admin/admin_websetting.blade.php ENDPATH**/ ?>