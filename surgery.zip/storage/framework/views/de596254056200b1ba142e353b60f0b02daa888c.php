<style>
    .spiinerdiv {
  background-color: #000000a6;
    width: 100%;
    height: 100vh;
    margin: 0;
    display: grid;
    place-items: center;
    z-index: 9999;
    position: absolute;
}

.spinner {
  display: grid;
  place-items: center;
  width: 150px;
  height: 150px;
  border-radius: 50%;
  background: conic-gradient(
    from 180deg at 50% 50%,
    rgba(82, 0, 255, 0) 0deg,
    #5200ff 360deg
  );
  animation: spin 2s infinite linear;
}
.spinner::before {
  content: "";
  border-radius: 50%;
  width: 80%;
  height: 80%;
  background-color: #000;
}

@keyframes spin {
  to {
    transform: rotate(1turn);
  }
}
   </style>
<?php if(auth()->guard()->guest()): ?>
<div class="spiinerdiv">
<div class="spinner"></div>
</div>
<?php else: ?>
<?php endif; ?>


<?php $__env->startSection('content'); ?>
<style>
    .pageheading{
        text-align: center;
        font-weight: bold;
        font-size: 25px;
    }
    .smallheading{
        font-size: 15px;
    }
.form-label {
    margin-bottom: 0rem;
    text-align: center !important;
    width: 100%;
    color: black;
    font-weight: 500;
}
.input{
    background: none;
  outline: none;
  border: 2px solid black !important;
  border-radius: inherit;
  text-align: center;
    font-size: 20px;
    font-weight: 700;
/*    text-transform: uppercase;*/
  padding: 0px !important;
}
.input:focus{
    background: none !important;
  outline: none !important;
  border: 2px solid black !important;
  border-radius: inherit;
  padding: 0px !important;
   box-shadow: none !important;
}
.input:active{
    background: none !important;
  outline: none !important;
  border: 2px solid black !important;
  border-radius: inherit;
  padding: 0px !important;
   box-shadow: none !important;
}
.btnanotherproc {
    width: 100%;
    border: 1px solid #a79696 !important;
    border-radius: 0;
    color: #a79696;
/*    text-transform: uppercase;*/
    text-align: center;
}
.btnanotherproc:focus{
    background: none !important;
  outline: none !important;
  border: 1px solid #a79696 !important;
  border-radius: inherit;
/*  padding: 0px !important;*/
   box-shadow: none !important;
}
.btnanotherproc:active{
    background: none !important;
  outline: none !important;
  border: 1px solid #a79696 !important;
  border-radius: inherit;
/*  padding: 0px !important;*/
   box-shadow: none !important;
}
.btnanotherproc_plus, .btnanotherproc_classaddremove{
    font-size: 30px;
    /* border: 1px solid; */
    color: #aad9aa;
    font-weight: bold;
    position: absolute;
    font-family: sans-serif;
    top: 20px;
    cursor: pointer;
}
.btnanotherproc_plus:hover{
color: #12b712;
}

.btnsubmit{
        background: #b5ddb5;
    border: 1px solid #12b712;
    color: black;
    font-weight: bold;
    padding: 10px 30px 10px 30px;
    border-radius: 0;
    width: 200px;
}
.btnsubmit:hover{
        background: #b5ddb5;
    border: 1px solid #12b712;
    color: black;
    font-weight: bold;
    padding: 10px 30px 10px 30px;
    border-radius: 0;
    width: 200px;
}
.py-4 {
    padding-top: 1.5rem!important;
    padding-bottom: 0rem!important;
}

@import url(https://fonts.googleapis.com/css?family=Roboto);

/****** LOGIN MODAL ******/
.loginmodal-container {
  padding: 30px;
  max-width: 350px;
  width: 100% !important;
  background-color: #F7F7F7;
  margin: 0 auto;
  border-radius: 2px;
  box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
  overflow: hidden;
  font-family: roboto;
}

.loginmodal-container h1 {
  text-align: center;
  font-size: 1.8em;
  font-family: roboto;
}

.loginmodal-container input[type=submit] {
  width: 100%;
  display: block;
  margin-bottom: 10px;
  position: relative;
}

.loginmodal-container input[type=text], input[type=password], input[type=email] {
  height: 44px;
  font-size: 16px;
  width: 100%;
  margin-bottom: 10px;
  -webkit-appearance: none;
  background: #fff;
  border: 1px solid #d9d9d9;
  border-top: 1px solid #c0c0c0;
  /* border-radius: 2px; */
  padding: 0 8px;
  box-sizing: border-box;
  -moz-box-sizing: border-box;
}

.loginmodal-container input[type=text]:hover, input[type=password]:hover, input[type=email]:hover {
  border: 1px solid #b9b9b9;
  border-top: 1px solid #a0a0a0;
  -moz-box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
  -webkit-box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
  box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
}

.loginmodal {
  text-align: center;
  font-size: 14px;
  font-family: 'Arial', sans-serif;
  font-weight: 700;
  height: 36px;
  padding: 0 8px;
/* border-radius: 3px; */
/* -webkit-user-select: none;
  user-select: none; */
}

.loginmodal-submit {
  /* border: 1px solid #3079ed; */
  border: 0px;
  color: #fff;
  text-shadow: 0 1px rgba(0,0,0,0.1); 
  background-color: #4d90fe;
  padding: 17px 0px;
  font-family: roboto;
  font-size: 14px;
  /* background-image: -webkit-gradient(linear, 0 0, 0 100%,   from(#4d90fe), to(#4787ed)); */
}

.loginmodal-submit:hover {
  /* border: 1px solid #2f5bb7; */
  border: 0px;
  text-shadow: 0 1px rgba(0,0,0,0.3);
  background-color: #357ae8;
  /* background-image: -webkit-gradient(linear, 0 0, 0 100%,   from(#4d90fe), to(#357ae8)); */
}

.loginmodal-container a {
  text-decoration: none;
  color: #666;
  font-weight: 400;
  text-align: center;
  display: inline-block;
  opacity: 0.6;
  transition: opacity ease 0.5s;
} 

.login-help{
  font-size: 12px;
}

.login-btn {
  text-align:center;
  margin-top: 50px;
}

.button {
  line-height: 55px;
  padding: 0 30px;
  background: #004a80;
  color: #fff;
  display: inline-block;
  font-family: roboto;
  text-decoration: none;
  font-size: 18px;
}

.button:hover,
.button:visited {
  background: #006cba;
  color: #fff;
}

.btnprocedure_minus{
    font-size: 30px;
    /* border: 1px solid; */
    color: #12b712;
    font-weight: bold;
    position: absolute;
    font-family: sans-serif;
    top: 25px;
    cursor: pointer;
}
.parag{
    margin: 0;
    color: black;
    font-weight: 600;
    position: relative;
}
.btnminusbenefist_minus{
    font-size: 50px;
    color: #12b712;
    font-weight: bold;
    font-family: sans-serif;
    cursor: pointer;
/*    width: 35px;*/
    position: absolute;
/*    top: -27px;*/
margin: -29px 0px 0px 0px;

}
.btneditbenefist_edit{
    font-size: 20px;
    color: #12b712;
    font-weight: bold;
    font-family: sans-serif;
    cursor: pointer;
    width: 35px;
    position: relative;
    top: 0px;
    /* left: 12px; */
    margin: 28px;
}
.btnanotherbenefit_plus{
    font-size: 30px;
    /* border: 1px solid; */
    color: #aad9aa;
    font-weight: bold;
    position: absolute;
    font-family: sans-serif;
    top: 5px;
    cursor: pointer;
}
.btnanotherbenefit_plus:hover{
color: #12b712;
}
.btnanotherbenefit{
    width: 100%;
        border: 1px solid #a79696;
    border-radius: 0;
    color: #a79696;
}
.btnanotherbenefit:hover{
    width: 100%;
        border: 1px solid black;
    border-radius: 0;
    color: black;
}
.proc_identity{
    color: grey;
    font-size: 13px;
}
.data_unq_code{
    position: absolute;
    top: 23px;
    font-size: 20px;
    font-weight: 700;
    left: -50px;
}
.btn_close_modal{
        padding: 12px;
    border-radius: 100px;
    width: 50px;
    height: 50px;
}
.btn_close_modal_remove_ben_risk{
    padding: 12px;
    border-radius: 100px;
    width: 50px;
    height: 50px; 
}

.btn_close_modal_another_ben_risk{
    padding: 12px;
    border-radius: 100px;
    width: 50px;
    height: 50px; 
}
.btn_close_modal_another_risk_risk{
    padding: 12px;
    border-radius: 100px;
    width: 50px;
    height: 50px; 
}

.btn_close_modal_patient{
    padding: 12px;
    border-radius: 100px;
    width: 50px;
    height: 50px; 
}

.btn_close_Edit_benrisk_new_proc{
    padding: 12px;
    border-radius: 100px;
    width: 50px;
    height: 50px; 
}

.btn_close_Edit_benrisk_existing_proc{
    padding: 12px;
    border-radius: 100px;
    width: 50px;
    height: 50px; 
}

.btn_close_modal_patientsign{
    padding: 12px;
    border-radius: 100px;
    width: 50px;
    height: 50px; 
}
.btn_new_proc_benrisk_plus{
    font-size: 30px;
    /* border: 1px solid; */
    color: #aad9aa;
    font-weight: bold;
    position: absolute;
    font-family: sans-serif;
    top: 35px;
    cursor: pointer;
}
.btn_new_proc_benrisk_plus:hover{
color: #12b712;
}

.temp_save_new_bene{
/*    background: #33a8de1f;*/
    padding: 0px;
    border-radius: 10px;
    position: relative;
/*    box-shadow: 0 3px 6px rgba(0,0,0,0.16), 0 3px 6px rgba(0,0,0,0.23);*/
}
.temp_save_new_bene p{
    margin: 0;
}
.temp_save_new_bene i{
   /* position: absolute;
    color: #aad9aa;
    top: 0;
    right: 10px;
    cursor: pointer;*/
}

.sep_temp_save_new_bene{
/*    background: #33a8de1f;*/
    padding: 0px;
    border-radius: 10px;
    position: relative;
/*    box-shadow: 0 3px 6px rgba(0,0,0,0.16), 0 3px 6px rgba(0,0,0,0.23);*/
}
.sep_temp_save_new_bene p{
    margin: 0;
}
.sep_temp_save_new_bene i{
    /*position: absolute;
    color: #aad9aa;
    top: 0;
    right: 10px;
    cursor: pointer;*/
}

.sep_temp_save_new_risk{
/*    background: #33a8de1f;*/
    padding: 0px;
    border-radius: 10px;
    position: relative;
/*    box-shadow: 0 3px 6px rgba(0,0,0,0.16), 0 3px 6px rgba(0,0,0,0.23);*/
}
.sep_temp_save_new_risk p{
    margin: 0;
}
.sep_temp_save_new_risk i{
   /* position: absolute;
    color: #aad9aa;
    top: 0;
    right: 10px;
    cursor: pointer;*/
}
.p_existing_ben_ask{
    text-align: center;
    color: #2b2f2b;
    cursor: pointer;
    text-decoration: underline;
    font-family: monospace;
    margin-top: 10px;
}
/*.p_existing_ben_ask:hover{
color: green;
}*/

.temp_save_new_risk{
/*    background: #33a8de1f;*/
    padding: 0px;
    border-radius: 10px;
    position: relative;
/*    box-shadow: 0 3px 6px rgba(0,0,0,0.16), 0 3px 6px rgba(0,0,0,0.23);*/
}
.temp_save_new_risk p{
    margin: 0;
}
.temp_save_new_risk i{
    /*position: absolute;
    color: #aad9aa;
    top: 0;
    right: 10px;
    cursor: pointer;*/
}
.p_existing_risk_ask{
    text-align: center;
    color: #2b2f2b;
    cursor: pointer;
    text-decoration: underline;
    font-family: monospace;
    margin-top: 10px;
}
/*.p_existing_risk_ask:hover{
color: green;
}
*/
 .fetch_all_gen_benefit div > .gen_benefit_div{
/*    background: #efe9e9;*/
    border-radius: 10px;
     padding: 0px 5px 0px 5px; 
/*    border: 1px solid #7c7d7f;*/
    cursor: pointer;
        color: black;
    font-weight: 500;
    font-size: 18px;
}
.fetch_all_gen_benefit div > .gen_benefit_div:hover{
/*    background: #e8f0fe47;*/
    }
.fetch_all_gen_benefit div > h2 {
    font-size: 16px;
    padding: 0;
    margin: 0;
    font-weight: bold;
}
.fetch_all_gen_benefit div > p {
    padding: 0;
    margin: 0;
}

.fetch_all_gen_risk div > .gen_risk_div{
/*    background: #efe9e9;*/
    border-radius: 10px;
     padding: 0px 5px 0px 5px; 
/*    border: 1px solid #7c7d7f;*/
    cursor: pointer;
        color: black;
    font-weight: 500;
    font-size: 18px;
}
.fetch_all_gen_risk div > .gen_risk_div:hover{
/*    background: #e8f0fe47;*/
    }

.fetch_all_gen_risk div > h2 {
    font-size: 16px;
    padding: 0;
    margin: 0;
    font-weight: bold;
}
.fetch_all_gen_risk div > p {
    padding: 0;
    margin: 0;
}
.py-4{
    overflow-y: scroll;
    height: 570px;
}

.btngen_plus {
    font-size: 23px;
    /* border: 1px solid; */
    color: #12b712;
    font-weight: bold;
    position: absolute;
    font-family: sans-serif;
    bottom: -2px;
    cursor: pointer;
    /* right: 9px; */
    margin: 0px 0px 0px 10px;
}

.btngen_edit {
    font-size: 20px;
    /* border: 1px solid; */
    color: #12b712;
    font-weight: bold;
    position: absolute;
    font-family: sans-serif;
    bottom: -1px;
    cursor: pointer;
    le: -2px;
    margin: 0px 0px 0px 32px;
}
    #signature-pad {
/*      border: 1px solid #ccc;*/
      margin: 10px 0;
    }

    canvas {
      border: 1px solid #ccc;
    }

.btnprocedure_edit{
    font-size: 30px;
    /* border: 1px solid; */
    color: #12b712;
    font-weight: bold;
    position: absolute;
    font-family: sans-serif;
    top: 25px;
    cursor: pointer;
    right: -10px;
}
.btnprocedure_save{
    font-size: 30px;
    /* border: 1px solid; */
    color: #12b712;
    font-weight: bold;
    position: absolute;
    font-family: sans-serif;
    top: 25px;
    cursor: pointer;
    right: -10px;
}
.singleproc{
    position: relative;
  }
@media only screen and (max-width: 500px) {
  .frontform_side {
    width: 50%;
  }
  .frontform_site {
   width: 50%;
  }
  .frontform_proc {
   width: 90%;
   margin-top: 0 !important;
  }
  .btnanotherproc_plus, .btnanotherproc_classaddremove{
    top: 5px;
  }
  .footer .p-3{
    font-size: 13px;
  }
  .frontform_plus {
   width: 10%;
  }

  .singleproc .btnprocedure_edit{
    right: 10%;
  }
  .singleproc{
    justify-content: right;
    position: relative;
  }
  .singleproc .col-md-2{
    width: 40%;
    margin-top: 10px;
  }
  .singleproc .col-md-7{
    width: 80%;
    margin: 20px 0px 0px 0px;
  }
  .singleproc .col-md-1{
    width: 20%;
  }
  .singleproc .data_unq_code {
    top: 3px;
    }
    .btnminusbenefist_minus{
        font-size:60px;
        margin:-35px 0px 0px 0px;
    }
    .btneditbenefist_edit{
        font-size:15px;
    }
    .btnprocedure_save {
    right: 10px;
    }
  .super_parentbenefit .col-md-6{
    width: 90%;
  }
  .super_parentbenefit .col-md-2{
    width: 10%;
  }
   .super_parentrisk .col-md-6{
    width: 90%;
  }
  .super_parentrisk .col-md-2{
    width: 10%;
  }
  .py-4{
        height: 500px;
  }
 .sep_add_new_proc_bene_single .col-md-11{
    width: 90%;
 }
 .sep_add_new_proc_bene_single .col-md-1{
    width: 10%;
 }
 .sep_add_new_proc_risk_single .col-md-11{
    width: 90%;
 }
 .sep_add_new_proc_risk_single .col-md-1{
    width: 10%;
 }
 .add_new_proc_bene_single .col-md-11{
    width: 90%;
 }
 .add_new_proc_bene_single .col-md-1{
    width: 10%;
 }
 .add_new_proc_risk_single .col-md-11{
    width: 90%;
 }
 .add_new_proc_risk_single .col-md-1{
    width: 10%;
 }
 ul.navbar-nav.leftnav{
    width: 100%;
 }
 .singleproc .form-label{
    display: none;
 }
}
</style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.css" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<div class="container" style="min-height:60px;">
    <div class="row justify-content-center">
        <div class="col-md-7">
            <h3 class="pageheading mb-4">Consent for surgical procedure</h3>
            <div class="parentprocedure">
            </div>
                        <div class="row">
                            <div class="col-md-1 mb-3 mt-3 frontform_side">
                                <select class="form-control btnanotherproc" id="plusmin_pre" style="font-size: 15px;
    padding: 0px;
    margin: 8px 0px 0px 0px;display: none;">
                                <option value="+/-">+/-</option>
                                <option value="+">+</option>
                                </select>
                            </div>
                            <div class="col-md-2 mb-3 mt-3 frontform_side">
                                <input type="text" class="form-control btnanotherproc" id="side_pre" placeholder="Side">
                                
                            </div>
                            <div class="col-md-2 mb-3 mt-3 frontform_site">
                                <input type="text" class="form-control btnanotherproc" id="site_pre" placeholder="Site">
                                
                            </div>
                            <div class="col-md-6 mb-3 mt-3 frontform_proc">
                                <input type="text" class="form-control btnanotherproc" id="btnanotherproc" placeholder="type here procedure">
                                
                            </div>
                            <div class="col-md-1 mb-3 p-0 frontform_plus" style="position:relative;">
                                <span class="btnanotherproc_classaddremove btnanotherproc_plus"><i class="icon_plus_btnanotherproc fa fa-plus"></i></span>
                            </div>
                        </div>
        </div>
    </div>

    <div class="row super_parentbenefit" style="display:none;">
        <h3 class="smallheading p-0">Benefits:</h3>
        <div class="col-md-12 parentbenefit">
        </div>
                            <div class="col-md-6 mb-3">
                                <a href="javascript:void(0);" class="btn btnanotherbenefit_plus_click btnanotherbenefit">Add another benefit</a>
                                
                            </div>
                            <div class="col-md-2 mb-3 p-0" style="position:relative;">
                                <span class="btnanotherbenefit_plus_click btnanotherbenefit_plus"><i class="fa fa-plus"></i></span>
                            </div>
                        </div>

                        <div class="row super_parentrisk" style="display:none;">
        <h3 class="smallheading p-0">Risks:</h3>
        <div class="col-md-12 parentrisk">
        
        </div>
                            <div class="col-md-6 mb-3">
                                <a href="javascript:void(0);" class="btn btnanotherrisk_plus_click btnanotherbenefit">Add another risks</a>
                                
                            </div>
                            <div class="col-md-2 mb-3 p-0" style="position:relative;">
                                <span class="btnanotherrisk_plus_click btnanotherbenefit_plus"><i class="fa fa-plus"></i></span>
                            </div>
                        </div>

    

</div>



<!-- procedure another -->
<!-- Modal -->
    <div class="modal fade zoomIn" id="loginModal" tabindex="-1" data-bs-keyboard="false" data-bs-backdrop="static" aria-hidden="true" role="dialog">
          <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content" style="    background: transparent;
    border: none;">
                <div class="modal-body">
                <div class="loginmodal-container">
                    <h3 class="pageheading mb-4">Login to Your Account</h3><br>
                  <form method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo csrf_field(); ?>
                    <input id="email" type="email" class=" <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>

                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <input id="password" type="password" class=" <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password">

                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <input type="submit" name="login" class="login loginmodal-submit" value="Login">
                  </form>
                    
                  <div class="login-help">
                    <?php if(Route::has('password.request')): ?>
                                    <a href="<?php echo e(route('password.request')); ?>">
                                        <?php echo e(__('Forgot Your Password?')); ?>

                                    </a>
                                <?php endif; ?>
                            <a href="<?php echo e(route('register')); ?>"><?php echo e(__('Register Now')); ?></a>
                    <!-- <a href="#">Forgot Password</a> -->
                  </div>
                </div>
                </div>
                </div>
            </div>
          </div>

 
<footer class="footer fixed-bottom text-center text-white" style="background-color:#e8f0fe47">
<div class="container mb-2">
 <div class="row justify-content-center">
        <div class="col-md-2">
            <button class="btn btnsubmit btnsubmit_procedure_all">SUBMIT</button>
        </div>
    </div>
    </div>
  <!-- Copyright -->
  <div class="text-center text-dark p-3" style="background-color: rgba(0, 0, 0, 0.2);">
    © 2023 Copyright:
    <a class="text-dark" style="text-transform:uppercase;" href="https://surgeryconsent.com.au/">Surgery Consent Companion</a>
  </div>
  <!-- Copyright -->
</footer>

<!-- new procedure modal -->
<div class="modal fade zoomIn" id="newProc_Modal" tabindex="-1" data-bs-keyboard="false" data-bs-backdrop="static" aria-hidden="true" role="dialog">
          <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-header">
        <h4 class="modal-title">Add New Procedure</h4>
      </div>
      <form method="POST" action="<?php echo e(url('submit_new_procedure')); ?>" id="new_procedure_form">
        <?php echo csrf_field(); ?>
                <div class="modal-body" style="height: 600px;
    overflow-y: scroll;">
                <div class="row">
                            <div class="col-md-12">
                                <label for="new_procedure_input" class="form-label">Type New Procedure</label>
                                <input name="new_procedure_input" id="new_procedure_input" type="text" required class="form-control input">
                            </div>
                            </div>

                            <!-- benefit -->
                            <div class="add_new_proc_bene_parent mt-3" style="border: 1px solid #ccc;
    border-radius: 10px;
    padding: 10px;
    margin: 0;">
    <div class="col-md-12">
                            <h3 class="smallheading p-0" style="text-align: center;
    font-weight: bold;
    font-size: 20px;
    text-decoration: underline;">Benefits:</h3>
                            </div>
        <div class="row" style="justify-content:center;">
            <div class="col-md-12 fetch_all_gen_benefit" style="">
                
            </div>
        
        </div>
        <!-- <hr> -->
        <div class="row temp_save_new_bene_parent mb-3">
          
        </div>

                            <div class="row add_new_proc_bene_single">
                            <div class="col-md-6">
                                <label class="form-label">Benefit Name</label>
                                <input name="new_benefit_code_input[]" type="hidden" class="new_benefit_code_input form-control input">
                                <input name="new_benefit_status_input[]" type="hidden" class="new_risk_status_input form-control input" value="0">
                                <input name="new_benefit_userid_input[]" type="hidden" class="new_benefit_userid_input form-control input" value="">
                                <input name="new_benefit_name_input[]" type="text" class="new_benefit_name_input form-control input">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Benefit Statistics</label>
                                <input name="new_benefit_statistics_input[]" type="text" class="new_benefit_statistics_input form-control input">
                            </div>
                            <div class="col-md-11 mt-2">
                                <label class="form-label">Benefit Detail</label>
                                <input name="new_benefit_detail_input[]" type="text" class="new_benefit_detail_input form-control input">
                            </div>
                            <div class="col-md-1 mb-3 p-0" style="position:relative;">
                                <span class="btn_new_proc_ben_plus_click btn_new_proc_benrisk_plus"><i class="fa fa-plus"></i></span>
                            </div>
                            </div>
                            </div>
                            <!-- <p class="p_existing_ben_ask">if you want to use existing benefit's for this procedure.?</p> -->
                            <!-- benefit -->

                            <!-- risk -->
                            <div class="add_new_proc_risk_parent mt-3" style="border: 1px solid #ccc;
    border-radius: 10px;
    padding: 10px;
    margin: 0;">
    <div class="col-md-12">
                            <h3 class="smallheading p-0" style="text-align: center;
    font-weight: bold;
    font-size: 20px;
    text-decoration: underline;">Risks:</h3>
                            </div>

         <div class="row" style="justify-content: center;">
            <div class="col-md-12 fetch_all_gen_risk" style="">
                
            </div>
        
        </div>
        <!-- <hr> -->
        <div class="row temp_save_new_risk_parent mb-3">
          
        </div>

                            <div class="row add_new_proc_risk_single">
                            <div class="col-md-6">
                                <label class="form-label">Risk Name</label>
                                <input name="new_risk_code_input[]" type="hidden" class="new_risk_code_input form-control input">
                                <input name="new_risk_status_input[]" type="hidden" class="new_risk_status_input form-control input" value="0">
                                <input name="new_risk_userid_input[]" type="hidden" class="new_risk_status_input form-control input" value="">
                                <input name="new_risk_name_input[]" type="text" class="new_risk_name_input form-control input">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Risk Statistics</label>
                                <input name="new_risk_statistics_input[]" type="text" class="new_risk_statistics_input form-control input">
                            </div>
                            <div class="col-md-11 mt-2">
                                <label class="form-label">Risk Detail</label>
                                <input name="new_risk_detail_input[]" type="text" class="new_risk_detail_input form-control input">
                            </div>
                            <div class="col-md-1 mb-3 p-0" style="position:relative;">
                                <span class="btn_new_proc_risk_plus_click btn_new_proc_benrisk_plus"><i class="fa fa-plus"></i></span>
                            </div>
                            </div>
                            </div>
                            <!-- <p class="p_existing_risk_ask">if you want to use existing risk's for this procedure.?</p> -->
                            <!-- risk -->

                           

                </div>
                 <div class="modal-footer">
        <button type="button" class="btn btn-danger btn_close_modal" data-dismiss="modal"><i class="fa fa-times"></i></button>
        <button type="submit" class="btn btnsubmit add_newproc_submit_btn">SUBMIT</button>
        <button type="button" class="btn btnsubmit add_newproc_submit_btn_loader" style="display:none;"><i class="fa fa-circle-o-notch fa-spin"></i></button>
      </div>
  </form>
                </div>
            </div>
          </div>
<!-- new procedure modal -->

<!-- remove benefi and risk modal -->
<div class="modal fade zoomIn" id="rembenrisk_Modal" tabindex="-1" data-bs-keyboard="false" data-bs-backdrop="static" aria-hidden="true" role="dialog">
          <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-header">
        <h4 class="modal-title">Remove <span class="modaltitle_rem_benrisk" style="text-transform:capitalize;"></span> (<span class="modaltitle_rem_benrisk_name"></span>)</h4>
      </div>
                <div class="modal-body rembenrisk_modalbody">
                </div>
                 <div class="modal-footer">
        <button type="button" class="btn btn-danger btn_close_modal_remove_ben_risk" data-dismiss="modal"><i class="fa fa-times"></i></button>
        <button type="button" class="btn btnsubmit rem_benrisk_btn">SUBMIT</button>
        <button type="button" class="btn btnsubmit rem_benrisk_btn_loader" style="display:none;"><i class="fa fa-circle-o-notch fa-spin"></i></button>
      </div>
                </div>
            </div>
          </div>
<!-- remove benefi and risk modal -->

<!-- add another benefit -->
<div class="modal fade zoomIn" id="anotherbenefit_Modal" tabindex="-1" data-bs-keyboard="false" data-bs-backdrop="static" aria-hidden="true" role="dialog">
          <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-header">
        <h4 class="modal-title">Add New Benefit</h4>
      </div>
      <form method="POST" action="<?php echo e(url('submit_new_benefit')); ?>" id="new_benefit_form">
        <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="fetch_procedure_another_benefit">
                        <p style="color: #2b2f2b;text-decoration: underline;font-family: monospace;margin-top: 10px;">please select atleast one procedure</p>
                        
                    </div>
                    <!-- benefit -->
                            <div class="sep_add_new_proc_bene_parent mt-3" style="border: 1px solid #ccc;
    border-radius: 10px;
    padding: 10px;
    margin: 0;">
    <div class="col-md-12">
                            <h3 class="smallheading p-0" style="text-align: center;
    font-weight: bold;
    font-size: 20px;
    text-decoration: underline;">Benefits:</h3>
                            </div>
        <div class="row sep_temp_save_new_bene_parent mb-3">
          
        </div>

                            <div class="row sep_add_new_proc_bene_single">
                            <div class="col-md-6">
                                <label class="form-label">Benefit Name</label>
                                <input name="sep_new_benefit_code_input[]" type="hidden" class="sep_new_benefit_code_input form-control input">
                                <input name="sep_new_benefit_name_input[]" type="text" class="sep_new_benefit_name_input form-control input">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Benefit Statistics</label>
                                <input name="sep_new_benefit_statistics_input[]" type="text" class="sep_new_benefit_statistics_input form-control input">
                            </div>
                            <div class="col-md-11 mt-2">
                                <label class="form-label">Benefit Detail</label>
                                <input name="sep_new_benefit_detail_input[]" type="text" class="sep_new_benefit_detail_input form-control input">
                            </div>
                            <div class="col-md-1 mb-3 p-0" style="position:relative;">
                                <span class="sep_btn_new_proc_ben_plus_click btn_new_proc_benrisk_plus"><i class="fa fa-plus"></i></span>
                            </div>
                            </div>
                            </div>
                            <!-- <p class="p_existing_ben_ask">if you want to use existing benefit's for this procedure.?</p> -->
                            <!-- benefit -->
                </div>
                 <div class="modal-footer">
        <button type="button" class="btn btn-danger btn_close_modal_another_ben_risk" data-dismiss="modal"><i class="fa fa-times"></i></button>
        <button type="submit" class="btn btnsubmit anotherbenefit_btn">SUBMIT</button>
        <button type="button" class="btn btnsubmit anotherbenefit_btn_loader" style="display:none;"><i class="fa fa-circle-o-notch fa-spin"></i></button>
      </div>
  </form>
                </div>
            </div>
          </div>
<!-- add another benefit -->

<!-- add another risk -->
<div class="modal fade zoomIn" id="anotherrisk_Modal" tabindex="-1" data-bs-keyboard="false" data-bs-backdrop="static" aria-hidden="true" role="dialog">
          <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-header">
        <h4 class="modal-title">Add New Risk</h4>
      </div>
      <form method="POST" action="<?php echo e(url('submit_new_risk')); ?>" id="new_risk_form">
        <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="fetch_procedure_another_risk">
                        <p style="color: #2b2f2b;text-decoration: underline;font-family: monospace;margin-top: 10px;">please select atleast one procedure</p>
                        
                    </div>
                    <!-- risk -->
                            <div class="sep_add_new_proc_risk_parent mt-3" style="border: 1px solid #ccc;
    border-radius: 10px;
    padding: 10px;
    margin: 0;">
    <div class="col-md-12">
                            <h3 class="smallheading p-0" style="text-align: center;
    font-weight: bold;
    font-size: 20px;
    text-decoration: underline;">Risks:</h3>
                            </div>
        <div class="row sep_temp_save_new_risk_parent mb-3">
          
        </div>

                            <div class="row sep_add_new_proc_risk_single">
                            <div class="col-md-6">
                                <label class="form-label">Risk Name</label>
                                <input name="sep_new_risk_code_input[]" type="hidden" class="sep_new_risk_code_input form-control input">
                                <input name="sep_new_risk_name_input[]" type="text" class="sep_new_risk_name_input form-control input">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Risk Statistics</label>
                                <input name="sep_new_risk_statistics_input[]" type="text" class="sep_new_risk_statistics_input form-control input">
                            </div>
                            <div class="col-md-11 mt-2">
                                <label class="form-label">Risk Detail</label>
                                <input name="sep_new_risk_detail_input[]" type="text" class="sep_new_risk_detail_input form-control input">
                            </div>
                            <div class="col-md-1 mb-3 p-0" style="position:relative;">
                                <span class="sep_btn_new_proc_risk_plus_click btn_new_proc_benrisk_plus"><i class="fa fa-plus"></i></span>
                            </div>
                            </div>
                            </div>
                            <!-- <p class="p_existing_ben_ask">if you want to use existing risk's for this procedure.?</p> -->
                            <!-- risk -->
                </div>
                 <div class="modal-footer">
        <button type="button" class="btn btn-danger btn_close_modal_another_risk_risk" data-dismiss="modal"><i class="fa fa-times"></i></button>
        <button type="submit" class="btn btnsubmit anotherrisk_btn">SUBMIT</button>
        <button type="button" class="btn btnsubmit anotherrisk_btn_loader" style="display:none;"><i class="fa fa-circle-o-notch fa-spin"></i></button>
      </div>
  </form>
                </div>
            </div>
          </div>
<!-- add another risk -->

<!-- add patient -->
<div class="modal fade zoomIn" id="Patient_Modal" tabindex="-1" data-bs-keyboard="false" data-bs-backdrop="static" aria-hidden="true" role="dialog">
          <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-header">
        <h4 class="modal-title">Patient Detail</h4>
      </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6">
                                <label class="form-label">Patient First Name *</label>
                                <input name="pat_fname" type="text" id="pat_fname" class="form-control input">
                        </div>
                        <div class="col-md-6">
                                <label class="form-label">Patient Last Name *</label>
                                <input name="pat_lname" type="text" id="pat_lname" class="form-control input">
                        </div>
                        <div class="col-md-6 mt-3">
                                <label class="form-label">Patient DOB</label>
                                <input name="pat_dob" type="text" id="pat_dob" class="form-control input">
                        </div>
                        <div class="col-md-6 mt-3">
                                <label class="form-label">Patient Email</label>
                                <input name="pat_email" type="text" id="pat_email" class="form-control input">
                        </div>
                        <div class="col-md-6 mt-3">
                                <label class="form-label">Patient Phone No</label>
                                <input name="pat_phone" type="text" id="pat_phone" class="form-control input">
                        </div>
                         <div class="col-md-6 mt-3">
                                <label class="form-label">Patient Gender</label>
                                <select name="pat_gender" id="pat_gender" class="form-control input" style="text-align: left;padding: 5px 4px !important;
    font-size: 12px;">
                                <option value="">Select Patient Gender</option>
                                <option value="male">Male</option>
                                <option value="female">Female</option>
                                <option value="other">Other</option>
                                </select>
                        </div>
                         <div class="col-md-12 mt-3">
                                <label class="form-label">Patient Address</label>
                                <input name="pat_address" type="text" id="pat_address" class="form-control input">
                        </div>

                        <div class="col-md-12 mt-3">
                            <div class="form-check">
                            <input type="checkbox" class="form-check-input" id="emailcopyrosurgeon_checkbox" name="emailcopyrosurgeon_checkbox" checked>
                            <label class="form-check-label" for="emailcopyrosurgeon_checkbox">email copy to surgeon</label>
                            </div>
                            <div class="form-check">
                            <input type="checkbox" class="form-check-input" id="emailcopyropatient_checkbox" name="emailcopyropatient_checkbox">
                            <label class="form-check-label" for="emailcopyropatient_checkbox">email copy to patient</label>
                            </div>
                            <div class="form-check">
                            <input type="checkbox" class="form-check-input" id="digitalsignnow_checkbox" name="digitalsignnow_checkbox">
                            <label class="form-check-label" for="digitalsignnow_checkbox">digitally sign now</label>
                            </div>
                        </div>
                    </div>
                </div>
                 <div class="modal-footer">
        <button type="button" class="btn btn-danger btn_close_modal_patient" data-dismiss="modal"><i class="fa fa-times"></i></button>
        <button type="submit" class="btn btnsubmit patient_submit_btn" id="generate_consent_btn">Generate Consent</button>
        <button type="button" class="btn btnsubmit patient_submit_loader" style="display:none;"><i class="fa fa-circle-o-notch fa-spin"></i></button>
      </div>
                </div>
            </div>
          </div>
<!-- add patient -->

<!-- add patient sign -->
<div class="modal fade zoomIn" id="Patient_Modalsign" tabindex="-1" data-bs-keyboard="false" data-bs-backdrop="static" aria-hidden="true" role="dialog">
          <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-header">
        <h4 class="modal-title">Signature Pad</h4>
      </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12 mt-3 patient_sign_content">
                            <p><?php echo e($pd_agree->mp_agree); ?>.</p>
                        </div>
                        <div class="col-md-12 mt-3 doctor_sign_content" style="display:none;">
                            <p><?php echo e($pd_agree->md_agree); ?>.</p>
                        </div>
                        <div class="col-md-12 mt-3">
                            <div id="signature-pad">
  <canvas id="canvas" width="400" height="250"></canvas>
</div>

<button id="clearBtn">Clear</button>
<button id="saveBtn">Save</button>
                        </div>
                    </div>
                </div>
                 <div class="modal-footer">
        <button type="button" class="btn btn-danger btn_close_modal_patientsign" data-dismiss="modal"><i class="fa fa-times"></i></button>
        <!-- <button type="submit" class="btn btnsubmit patientsign_submit_btn">SUBMIT</button>
        <button type="button" class="btn btnsubmit patientsign_submit_loader" style="display:none;"><i class="fa fa-circle-o-notch fa-spin"></i></button> -->
      </div>
                </div>
            </div>
          </div>
<!-- add patient sign -->


<!-- edit ben risk new procedure -->
<div class="modal fade zoomIn" id="Edit_benrisk_new_proc" tabindex="-1" data-bs-keyboard="false" data-bs-backdrop="static" aria-hidden="true" role="dialog">
          <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                <h4 class="modal-title Edit_benrisk_new_proc_title"></h4>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6">
                                <label class="form-label">Name</label>
                                <input name="Edit_benrisk_new_proc_name" type="text" id="Edit_benrisk_new_proc_name" class="form-control input">
                        </div>
                        <div class="col-md-6">
                                <label class="form-label">Statistics</label>
                                <input name="Edit_benrisk_new_proc_statistics" type="text" id="Edit_benrisk_new_proc_statistics" class="form-control input">
                        </div>
                        <div class="col-md-12 mt-3">
                                <label class="form-label">Detail</label>
                                <input name="Edit_benrisk_new_proc_detail" type="text" id="Edit_benrisk_new_proc_detail" class="form-control input">
                        </div>
                    </div>
                </div>
                 <div class="modal-footer">
        <button type="button" class="btn btn-danger btn_close_Edit_benrisk_new_proc" data-dismiss="modal"><i class="fa fa-times"></i></button>
        <button type="submit" class="btn btnsubmit" id="Edit_benrisk_new_proc_done">Done</button>
      </div>
                </div>
            </div>
          </div>
<!-- edit ben risk new procedure -->


<!-- edit ben risk existing procedure -->
<div class="modal fade zoomIn" id="Edit_benrisk_existing_proc" tabindex="-1" data-bs-keyboard="false" data-bs-backdrop="static" aria-hidden="true" role="dialog">
          <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                <h4 class="modal-title Edit_benrisk_existing_proc_title"></h4>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12">
                                <label class="form-label">Name</label>
                                <input name="Edit_benrisk_existing_proc_name" type="text" id="Edit_benrisk_existing_proc_name" class="form-control input">
                        </div>
                        <div class="col-md-12 mt-3">
                                <label class="form-label">Detail</label>
                                <input name="Edit_benrisk_existing_proc_detail" type="text" id="Edit_benrisk_existing_proc_detail" class="form-control input">
                        </div>
                    </div>
                </div>
                 <div class="modal-footer">
        <button type="button" class="btn btn-danger btn_close_Edit_benrisk_existing_proc" data-dismiss="modal"><i class="fa fa-times"></i></button>
        <button type="submit" class="btn btnsubmit" id="Edit_benrisk_existing_proc_done">Done</button>
        <button type="button" class="btn btnsubmit existing_benrisk_edit_submit_loader" style="display:none;"><i class="fa fa-circle-o-notch fa-spin"></i></button>
      </div>
                </div>
            </div>
          </div>
<!-- edit ben risk existing procedure -->
<?php if(auth()->guard()->guest()): ?>
<script type="text/javascript">
    $(document).ready(function () {
    setTimeout(function(){
    $('#loginModal').modal('show');
    $('.spiinerdiv').hide();
    },2000)
});
</script>
<?php else: ?>
<?php echo $__env->make('print', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
<?php endif; ?>
<script type="text/javascript">
var array_surgery_ben = [];
var array_surgery_risk = [];
var procedure_code_array = [];
var array_surgery_parent = [];
var procedure_codes=[];

function groupBy(array, key) {
  return array.reduce((result, obj) => {
    const keyValue = obj[key];
    if (!result[keyValue]) {
      result[keyValue] = [];
    }
    result[keyValue].push(obj);
    return result;
  }, {});
}

    $(document).on('click','.btnanotherbenefit_plus_click',function(){
        $('#anotherbenefit_Modal').modal('show');
    });
    $(document).on('click','.btn_close_modal_another_ben_risk',function(){
        $('#anotherbenefit_Modal').modal('hide');
    });

    $(document).on('click','.btnanotherrisk_plus_click',function(){
        $('#anotherrisk_Modal').modal('show');
    });
    $(document).on('click','.btn_close_modal_another_risk_risk',function(){
        $('#anotherrisk_Modal').modal('hide');
    });
    $(document).on('click','.btn_close_modal',function(){
        $('#newProc_Modal').modal('hide');
    });
    $(document).on('click','.btn_close_modal_remove_ben_risk',function(){
        $('#rembenrisk_Modal').modal('hide');
    });
    $(document).on('keyup','#btnanotherproc',function(event){
        // alert('f')
        var proc_val = $( "#btnanotherproc" ).val();
        if(event.keyCode == 13) {
            if(proc_val == 'No Procedure Found'){

            }
            else{
            $('.btnanotherproc_plus').click();
            }
        }
        else{
        $( this ).attr('data-id','');
        }
    });
$(document).on('click','.btnanotherproc_plus',function(){
    var proc_val = $( "#btnanotherproc" ).val();
    var side_pre = $( "#side_pre" ).val();
    var site_pre = $( "#site_pre" ).val();
    var proc_id = $( "#btnanotherproc" ).attr('data-id');
    if(side_pre == ''){ 
        $("#side_pre").focus();
    }
    else if(site_pre == ''){ 
        $("#site_pre").focus();
    }
    else if(proc_val == ''){ 
        $( "#btnanotherproc" ).focus();
    }
    else{
        $('.btnanotherproc_classaddremove').removeClass('btnanotherproc_plus')
        $('.icon_plus_btnanotherproc').removeClass('fa-plus')
    $('.icon_plus_btnanotherproc').addClass('fa-circle-o-notch fa-spin')
        if (proc_id == '') {
    var path_get_generic_rb = "<?php echo e(url('fetch_generic_rb')); ?>";
    $.ajax({
            url: path_get_generic_rb,
            type: 'GET',
            dataType: "json",
            success: function( data ) { 
            console.log(data)
            var gen_ben_html = '';
            // '<p class="p_existing_ben_ask">if you want to use existing benefits for this .? click the existing benefit.</p>';
            for (var i = 0; i < data.benefit.length; i++) {
                var count_b = i + 1;
                gen_ben_html += '<div class="col-md-12 mb-1">'+
                                '<div class="gen_benefit_div" data-name="'+data.benefit[i].benefit_name+'" data-code="'+data.benefit[i].code+'" data-statistics="'+data.benefit[i].statistics+'" data-detail="'+data.benefit[i].detail+'" data-status="'+data.benefit[i].status+'" data-userid="'+data.benefit[i].userid+'">'+
                                '<p class="parag" style="position:relative">'+count_b+'. '+data.benefit[i].benefit_name+' - '+data.benefit[i].detail+' <span class="proc_identity">('+data.benefit[i].code+')</span> <span class="btngen_plus"><i class="icon_plus_btngen fa fa-plus"></i></span></p>'+
                                '</div>'+
                                '</div>';
            }
            $('.fetch_all_gen_benefit').html(gen_ben_html);

            var gen_risk_html = '';
            // '<p class="p_existing_risk_ask">if you want to use existing risks for this .? click the existing risk.</p>';
            for (var i = 0; i < data.risk.length; i++) {
                var count_r = i + 1;
                gen_risk_html += '<div class="col-md-12 mb-1">'+
                                '<div class="gen_risk_div" data-name="'+data.risk[i].risk_name+'" data-code="'+data.risk[i].code+'" data-statistics="'+data.risk[i].statistics+'" data-detail="'+data.risk[i].detail+'" data-status="'+data.risk[i].status+'" data-userid="'+data.risk[i].userid+'">'+
                                '<p class="class="parag"" style="position:relative">'+count_r+'. '+data.risk[i].risk_name+' - '+data.risk[i].detail+' <span class="proc_identity">('+data.risk[i].code+')</span> <span class="btngen_plus"><i class="icon_plus_btngen fa fa-plus"></i></span></p>'+
                                '</div>'+
                                '</div>';
            }
            $('.fetch_all_gen_risk').html(gen_risk_html);

            $('#new_procedure_input').val(proc_val)
            $('.btnanotherproc_classaddremove').addClass('btnanotherproc_plus')
            $('.icon_plus_btnanotherproc').removeClass('fa-circle-o-notch fa-spin')
            $('.icon_plus_btnanotherproc').addClass('fa-plus')
            $( "#btnanotherproc" ).val('');
            $( "#btnanotherproc" ).attr('data-id','');
            $('.temp_save_new_bene_parent').html('')
            $('.temp_save_new_risk_parent').html('')
            $('.add_new_proc_bene_single').each(function() {
            if ($(this).css('display') === 'none') {
            $(this).remove();
            }
            });
            $('.add_new_proc_risk_single').each(function() {
            if ($(this).css('display') === 'none') {
            $(this).remove();
            }
            });
            $('.fetch_all_gen_benefit').each(function(){

              $(this).find('.gen_benefit_div').click()
            })
            $('.fetch_all_gen_risk').each(function(){

              $(this).find('.gen_risk_div').click()
            })
            $('#newProc_Modal').modal('show')
            }
        });

}
else{
var path_get_procedure = "<?php echo e(url('fetch_procedure')); ?>";
    $.ajax({
            url: path_get_procedure,
            type: 'GET',
            dataType: "json",
            data: {
               proc_id: proc_id
            },
            success: function( data ) { 
                console.log(data)
                if(procedure_code_array.find((element) => element == data.procedure.procedure_code)){
                    alert('procedure already exist')
                     $('.btnanotherproc_classaddremove').addClass('btnanotherproc_plus')
                $('.icon_plus_btnanotherproc').removeClass('fa-circle-o-notch fa-spin')
    $('.icon_plus_btnanotherproc').addClass('fa-plus')
                $( "#btnanotherproc" ).val('');
                $( "#btnanotherproc" ).attr('data-id','');
                    }
                    else{
                var in_html_sep_ben = '<div class="row sepben_option_row" data-id="'+data.procedure.procedure_code+'">'+
                            '<div class="col-md-12">';
      in_html_sep_ben += '<div class="form-check">'+
      '<input type="radio" class="form-check-input sepben_option" id="check'+data.procedure.procedure_code+'" name="sepben_option[]" value="'+data.procedure.id+'">'+
      '<label class="form-check-label" for="check'+data.procedure.procedure_code+'">'+data.procedure.procedure_code+' '+data.procedure.procedure_name+'</label>'+
    '</div>';
                            in_html_sep_ben += '</div></div>';
                        $('.fetch_procedure_another_benefit').append(in_html_sep_ben);
                        var in_html_sep_risk = '<div class="row seprisk_option_row" data-id="'+data.procedure.procedure_code+' ">'+
                            '<div class="col-md-12">';
      in_html_sep_risk += '<div class="form-check">'+
      '<input type="radio" class="form-check-input seprisk_option" id="check'+data.procedure.procedure_code+'" name="seprisk_option[]" value="'+data.procedure.id+'">'+
      '<label class="form-check-label" for="check'+data.procedure.procedure_code+'">'+data.procedure.procedure_code+' '+data.procedure.procedure_name+'</label>'+
    '</div>';
                            in_html_sep_risk += '</div></div>';
                        $('.fetch_procedure_another_risk').append(in_html_sep_risk);
                procedure_code_array.push(data.procedure.procedure_code)
                // console.log(procedure_code_array)
                array_surgery_parent.push(data);
                // window.ar = array_surgery_parent;
                // console.log(array_surgery_parent)
                for (var i = 0; i < data.benefit.length; i++) {
                var array_surgery_child_ben = new Object();
                array_surgery_child_ben.procedure_code = data.procedure.procedure_code;
                array_surgery_child_ben.procedure_name = data.procedure.procedure_name;
                array_surgery_child_ben.benefit_code = data.benefit[i].code;
                array_surgery_child_ben.benefit_name = data.benefit[i].benefit_name;
                array_surgery_child_ben.benefit_statistics = data.benefit[i].statistics;
                array_surgery_child_ben.benefit_detail = data.benefit[i].detail;
                array_surgery_ben.push(array_surgery_child_ben);
            }
            for (var i = 0; i < data.risk.length; i++) {
                var array_surgery_child_risk = new Object();
                array_surgery_child_risk.procedure_code = data.procedure.procedure_code;
                array_surgery_child_risk.procedure_name = data.procedure.procedure_name;
                array_surgery_child_risk.risk_code = data.risk[i].code;
                array_surgery_child_risk.risk_name = data.risk[i].risk_name;
                array_surgery_child_risk.risk_statistics = data.risk[i].statistics;
                array_surgery_child_risk.risk_detail = data.risk[i].detail;
                array_surgery_risk.push(array_surgery_child_risk);
            }
                
                const result_ben = groupBy(array_surgery_ben, 'benefit_code');
                // var result_ben = Object.groupBy(array_surgery_ben, ({ benefit_code }) => benefit_code);
                array_surgery_ben['benefit'] = result_ben;
                // alert(data.procedure.procedure_code);
                // console.log('resl benfit', result_ben)
                // var result_risk = Object.groupBy(array_surgery_risk, ({ risk_code }) => risk_code);
                const result_risk = groupBy(array_surgery_risk, 'risk_code');
                array_surgery_risk['risk'] = result_risk;
                // console.log('resl risk', result_risk)
                riskben_fetch(array_surgery_ben,array_surgery_risk);
              var in_html_proc = '<div class="row singleproc" data-code="'+data.procedure.procedure_code+'">'+
                            '<div class="col-md-2" style="position:relative;">'+
                            '<span class="data_unq_code">'+data.procedure.procedure_code+'</span>'+
                                '<label for="side" class="form-label">Side</label>'+
                                '<input name="side" type="text" required class="side form-control input <?php $__errorArgs = ['side'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">'+
                            '</div>'+
                            '<div class="col-md-2">'+
                                '<label for="site" class="form-label">Site</label>'+
                                '<input name="site" type="text" required class="site form-control input <?php $__errorArgs = ['site'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">'+
                            '</div>'+
                            '<div class="col-md-7">'+
                                '<label for="procedureseach" class="form-label">Procedure</label>'+
                                '<input name="procedure" type="text" required id="procedureseach" class="procedureseach form-control input <?php $__errorArgs = ['procedure'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="'+window.autoname+'" readonly>'+
                            '</div>'+
                            '<div class="col-md-1 mb-3 p-0" style="position:relative;">'+
                                '<span class="btnprocedure_minus" data-id="'+data.procedure.procedure_code+'"><i class="fa fa-minus"></i></span>'+
                                '<span class="btnprocedure_edit" data-id="'+data.procedure.id+'"><i class="fa fa-edit"></i></span>'+
                            '</div>'+
                            '<p class="p_plusmin_pre" style="    position: absolute;top: 23px;left: 34%;color: green;font-size: 20px;    width: 30px;">'+$('#plusmin_pre').val()+'</p>'+
                        '</div>';
        $('.parentprocedure').append(in_html_proc);
         $('.btnanotherproc_classaddremove').addClass('btnanotherproc_plus')
                $('.icon_plus_btnanotherproc').removeClass('fa-circle-o-notch fa-spin')
    $('.icon_plus_btnanotherproc').addClass('fa-plus')
                $( "#btnanotherproc" ).val('');
                $( "#btnanotherproc" ).attr('data-id','');
                $('.super_parentbenefit').show();
                $('.super_parentrisk').show();
                $('.singleproc:last .side').val($('#side_pre').val());
                $('.singleproc:last .site').val($('#site_pre').val());
                $('#side_pre').val('')
                $('#site_pre').val('')
                checkproc();

            }
            },
             error: function(err) {
                 alert('err')
            console.log(err)
        }
          });
}
    }
})

 $(document).on('click','.rem_benrisk_btn',function(){
    var cat = $(this).attr('data-cat');
    var id = $(this).attr('data-id');
    if($('.rembenrisk_option:checked').length == 0){
        alert('please atleast one procedure')
    }
    else{
        $('.rem_benrisk_btn').hide();
        $('.rem_benrisk_btn_loader').show();
    if(cat == 'benefit'){
        $('.rembenrisk_option:checked').each(function(){
            var procedureCodeToRemove = $(this).val();
    array_surgery_ben = $.grep(array_surgery_ben, function(item) {
    return item.benefit_code !== id || item.procedure_code !== procedureCodeToRemove;
    });
    // var result_ben = Object.groupBy(array_surgery_ben, ({ benefit_code }) => benefit_code);
    const result_ben = groupBy(array_surgery_ben, 'benefit_code');
    array_surgery_ben['benefit'] = result_ben;
    riskben_fetch(array_surgery_ben,array_surgery_risk)
    $('.rem_benrisk_btn').show();
        $('.rem_benrisk_btn_loader').hide();
        $('#rembenrisk_Modal').modal('hide');
})
    }
    else{
$('.rembenrisk_option:checked').each(function(){
            var procedureCodeToRemove = $(this).val();
    array_surgery_risk = $.grep(array_surgery_risk, function(item) {
    return item.risk_code !== id || item.procedure_code !== procedureCodeToRemove;
    });
    // var result_risk = Object.groupBy(array_surgery_risk, ({ risk_code }) => risk_code);
    const result_risk = groupBy(array_surgery_risk, 'risk_code');
    array_surgery_risk['risk'] = result_risk;
    riskben_fetch(array_surgery_ben,array_surgery_risk)
    $('.rem_benrisk_btn').show();
        $('.rem_benrisk_btn_loader').hide();
        $('#rembenrisk_Modal').modal('hide');
})
    }
}
 });
 $(document).on('click','.btnminusbenrisk_click',function(){
    var cat = $(this).attr('data-cat');
    var id = $(this).attr('data-id');
    var procid = $(this).attr('data-procid');
    var name = $(this).attr('data-name');
    $('.rem_benrisk_btn').attr('data-id',id)
    $('.rem_benrisk_btn').attr('data-cat',cat)
    $('.modaltitle_rem_benrisk').text(cat)
    $('.modaltitle_rem_benrisk_name').text(name)
    var in_html_rembenrisk = '<div class="row">'+
                            '<div class="col-md-12">'+
                            '<p style="color: #2b2f2b;text-decoration: underline;font-family: monospace;margin-top: 10px;">please select atleast one procedure</p>';
    var array = procid.split(",");
for (var i in array){
    var remben_proc_name = $('.singleproc[data-code='+array[i]+']').find('.procedureseach').val();
      in_html_rembenrisk += '<div class="form-check">'+
      '<input type="checkbox" class="form-check-input rembenrisk_option" id="check'+array[i]+'" name="option'+array[i]+'" value="'+array[i]+'">'+
      '<label class="form-check-label" for="check'+array[i]+'">'+array[i]+' '+remben_proc_name+'</label>'+
    '</div>';
}
                            in_html_rembenrisk += '</div></div>';
    $('.rembenrisk_modalbody').html(in_html_rembenrisk)
    $('#rembenrisk_Modal').modal('show');
    // console.log(array_surgery_parent)
    // console.log(array_surgery_ben)
   // var benefitCodeToRemove = "RP-002"; // The benefit_code to remove
    // var procedureCodeToRemove = "P-966"; // The procedure_code to remove

   // array_surgery_ben = $.grep(array_surgery_ben, function(item) {
   //  return item.benefit_code !== benefitCodeToRemove || item.procedure_code !== procedureCodeToRemove;
   //  });
   // var result_ben = Object.groupBy(array_surgery_ben, ({ benefit_code }) => benefit_code);
   //  array_surgery_ben['benefit'] = result_ben;
// array_surgery_ben['benefit'] = result_ben;
// console.log(array_surgery_ben)
// riskben_fetch(array_surgery_ben,array_surgery_risk)
 });
 $(document).on('click','.btnprocedure_minus',function(){
    var proc_code = $(this).attr('data-id');
    $('.sepben_option_row[data-id='+proc_code+']').remove();
    $('.seprisk_option_row[data-id='+proc_code+']').remove();
    var index = procedure_code_array.findIndex((element) => element == proc_code);
    procedure_code_array.splice(index);

    var procedureCodeToRemove = proc_code; // The procedure_code you want to remove

// Find and remove the object with the specified "procedure_code"
array_surgery_parent = array_surgery_parent.filter(function (obj) {
    return obj.procedure.procedure_code !== procedureCodeToRemove;
});
var data = array_surgery_parent;
array_surgery_ben = [];
array_surgery_risk = [];
for (var id = 0; id < data.length; id++) {
for (var i = 0; i < data[id].benefit.length; i++) {
                var array_surgery_child_ben = new Object();
                array_surgery_child_ben.procedure_code = data[id].procedure.procedure_code;
                array_surgery_child_ben.procedure_name = data[id].procedure.procedure_name;
                array_surgery_child_ben.benefit_code = data[id].benefit[i].code;
                array_surgery_child_ben.benefit_name = data[id].benefit[i].benefit_name;
                array_surgery_child_ben.benefit_statistics = data[id].benefit[i].statistics;
                array_surgery_child_ben.benefit_detail = data[id].benefit[i].detail;
                array_surgery_ben.push(array_surgery_child_ben);
            }
            for (var i = 0; i < data[id].risk.length; i++) {
                var array_surgery_child_risk = new Object();
                array_surgery_child_risk.procedure_code = data[id].procedure.procedure_code;
                array_surgery_child_risk.procedure_name = data[id].procedure.procedure_name;
                array_surgery_child_risk.risk_code = data[id].risk[i].code;
                array_surgery_child_risk.risk_name = data[id].risk[i].risk_name;
                array_surgery_child_risk.risk_statistics = data[id].risk[i].statistics;
                array_surgery_child_risk.risk_detail = data[id].risk[i].detail;
                array_surgery_risk.push(array_surgery_child_risk);
            }
        }
                // var result_ben = Object.groupBy(array_surgery_ben, ({ benefit_code }) => benefit_code);
                const result_ben = groupBy(array_surgery_ben, 'benefit_code');
                array_surgery_ben['benefit'] = result_ben;
                // console.log('resl benfit', result_ben)
                // var result_risk = Object.groupBy(array_surgery_risk, ({ risk_code }) => risk_code);
                const result_risk = groupBy(array_surgery_risk, 'risk_code');
                array_surgery_risk['risk'] = result_risk;
                // console.log('resl risk', result_risk)
                riskben_fetch(array_surgery_ben,array_surgery_risk)
    // console.log(array_surgery_parent)
    if(data.length == 0){
        $('.super_parentbenefit').hide();
                $('.super_parentrisk').hide();
    }
        $(this).closest('.singleproc').remove();
        checkproc();
    });


var path = "<?php echo e(url('procedure_autocomplete')); ?>";
    function autocomp(){
    $( "#btnanotherproc" ).each(function(){
    $(this).autocomplete({
         autoFocus: true,
        source: function( request, response ) {
          $.ajax({
            url: path,
            type: 'GET',
            dataType: "json",
            data: {
               search: request.term
            },
            success: function( data ) {
                // console.log(data)
            // window.autoname = ui.item.label;
                if (data.length === 0) {
 var result = [
            {
                label: 'No Procedure Found', 
                value: response.term
            }
        ];
        response(result);
}
else{
               response( data );
}

            }
          });
        },
        select: function (event, ui) {
            // alert('ffffffff')
            if(ui.item.label == 'No Procedure Found'){

            }
            else{
            window.autoname = ui.item.label;
           $(this).val(ui.item.label);
           $(this).attr('data-id',ui.item.id);
           $('.btnanotherproc_plus').click();
       }
           // console.log(ui.item); 
           return false;
        }
      });
  });
}
autocomp();

function riskben_fetch(ben_res,risk_res){
    $('.parentbenefit').html('');
    $('.parentrisk').html('');
    $('.A4_benefit_fetch').html('');
    $('.A4_risk_fetch').html('');
    var count = 0;
    $.each( ben_res.benefit, function( key, value ) {
    count = count + 1;

    var proce_ben = '';
    var proce_ben2 = '';
  for (var ib = 0; ib < value.length; ib++) {
    var resultString_pr = value[ib].procedure_code.replace(/^P-/i, '');
    proce_ben += value[ib].procedure_code+',';
    proce_ben2 += resultString_pr+',';
  }
  proce_ben = proce_ben.slice(0, -1);
  proce_ben2 = proce_ben2.slice(0, -1);
        var in_html_ben = ' <p class="parag" data-code="'+value[0].benefit_code+'">'+count+'. <span class="existing_ben_name">'+value[0].benefit_name+'</span> – <span class="existing_ben_detail">'+value[0].benefit_detail+'</span> <span class="proc_identity">('+proce_ben+')</span> <span class="btnminusbenrisk_click btnminusbenefist_minus" data-cat="benefit" data-id="'+value[0].benefit_code+'" data-procid="'+proce_ben+'" data-name="'+value[0].benefit_name+'">-</span> <span class="btneditbenrisk_click btneditbenefist_edit" data-cat="benefit" data-id="'+value[0].benefit_code+'" data-procid="'+proce_ben+'" data-name="'+value[0].benefit_name+'"><i class="fa fa-edit"></i></span></p>';
                    $('.parentbenefit').append(in_html_ben);
    var A4_benefit_fetch = '<tr class="parag_tr" data-code="'+value[0].benefit_code+'"><td class="custom-bullet existing_ben_name_td">'+value[0].benefit_name+'</td> <td class="existing_ben_detail_td">'+value[0].benefit_detail+'</td> <td style="align-items: center;display: flex;">'+proce_ben2+' <span class="form_check_rb"></span></td></tr>';
                    $('.A4_benefit_fetch').append(A4_benefit_fetch);
    
  // console.log('value',value.length)
});

    var count = 0;
    $.each( risk_res.risk, function( key, value ) {
    count = count + 1;

    var proce_risk = '';
    var proce_risk2 = '';
  for (var ir = 0; ir < value.length; ir++) {
    var resultString_pr = value[ir].procedure_code.replace(/^P-/i, '');
    proce_risk += value[ir].procedure_code+',';
    proce_risk2 += resultString_pr+',';
  }
  proce_risk = proce_risk.slice(0, -1);
  proce_risk2 = proce_risk2.slice(0, -1);
        var in_html_ben = ' <p class="parag" data-code="'+value[0].risk_code+'">'+count+'. <span class="existing_risk_name">'+value[0].risk_name+'</span> – <span class="existing_risk_detail">'+value[0].risk_detail+'</span> <span class="proc_identity">('+proce_risk+')</span> <span class="btnminusbenrisk_click btnminusbenefist_minus" data-cat="risk" data-id="'+value[0].risk_code+'" data-procid="'+proce_risk+'" data-name="'+value[0].risk_name+'">-</span> <span class="btneditbenrisk_click btneditbenefist_edit" data-cat="risk" data-id="'+value[0].risk_code+'" data-procid="'+proce_risk+'" data-name="'+value[0].risk_name+'"><i class="fa fa-edit"></i></span></p>';
                    $('.parentrisk').append(in_html_ben);
                    var A4_risk_fetch = '<tr class="parag_tr" data-code="'+value[0].risk_code+'"><td class="custom-bullet existing_risk_name_td">'+value[0].risk_name+'</td> <td class="existing_risk_detail_td">'+value[0].risk_detail+'</td> <td style="align-items: center;display: flex;">'+proce_risk2+' <span class="form_check_rb"></span></td></tr>';
                    $('.A4_risk_fetch').append(A4_risk_fetch);
    
  // console.log('value',value.length)
});
    // console.log(ben_res)
    // console.log(risk_res.risk)
}
 
    $('#btnanotherproc').on('autocompleteselect', function (e, ui) {
        if(ui.item.label == 'No Procedure Found'){

            }
            else{
           $('#btnanotherproc').val(ui.item.label);
           $('#btnanotherproc').attr('data-id',ui.item.id);
       }
    });


// add new procedure
    $(document).on('click','.btn_new_proc_ben_plus_click',function(){
var new_benefit_name_input = $(this).parents('.add_new_proc_bene_single').find('.new_benefit_name_input').val();
var new_benefit_statistics_input = $(this).parents('.add_new_proc_bene_single').find('.new_benefit_statistics_input').val();
var new_benefit_detail_input = $(this).parents('.add_new_proc_bene_single').find('.new_benefit_detail_input').val();
if(new_benefit_name_input == ''){
$(this).parents('.add_new_proc_bene_single').find('.new_benefit_name_input').focus();
}
// else if(new_benefit_statistics_input == ''){
// $(this).parents('.add_new_proc_bene_single').find('.new_benefit_statistics_input').focus();
// }
else if(new_benefit_detail_input == ''){
   $(this).parents('.add_new_proc_bene_single').find('.new_benefit_detail_input').focus(); 
}
else{
$(this).parents('.add_new_proc_bene_single').attr('data-name',new_benefit_name_input);
$(this).parents('.add_new_proc_bene_single').hide();
var new_benefit_detail_input_limit = new_benefit_detail_input.slice(0, 40)+'...';
var in_html_ben_new = '<div class="col-md-12 temp_save_new_bene_single mt-1">'+
              '<div class="temp_save_new_bene">'+
                  '<p class="parag"><span class="Edit_ben_new_proc_name_text">'+new_benefit_name_input+'</span> - <span class="Edit_ben_new_proc_name_detail">'+new_benefit_detail_input+'</span> <span class="btngen_plus"><i class="fa fa-minus close_temp_save_new_bene_single" data-id="'+new_benefit_name_input+'"></i></span> <span class="btngen_edit"><i class="fa fa-edit edit_temp_save_new_bene_single" data-id="'+new_benefit_name_input+'"></i></span> </p>'+
              '</div>'+
          '</div>';
 $('.temp_save_new_bene_parent').append(in_html_ben_new);
var in_html_proc_new = '<div class="row add_new_proc_bene_single">'+
                            '<div class="col-md-6">'+
                                '<label class="form-label">Benefit Name</label>'+
                                '<input name="new_benefit_code_input[]" type="hidden" class="new_benefit_code_input form-control input">'+
                                '<input name="new_benefit_status_input[]" type="hidden" class="new_benefit_status_input form-control input" value="0">'+
                                '<input name="new_benefit_userid_input[]" type="hidden" class="new_benefit_userid_input form-control input" value="">'+
                                '<input name="new_benefit_name_input[]" type="text" class="new_benefit_name_input form-control input">'+
                            '</div>'+
                            '<div class="col-md-6">'+
                                '<label class="form-label">Benefit Statistics</label>'+
                                '<input name="new_benefit_statistics_input[]" type="text" class="new_benefit_statistics_input form-control input">'+
                            '</div>'+
                            '<div class="col-md-11 mt-2">'+
                                '<label class="form-label">Benefit Detail</label>'+
                                '<input name="new_benefit_detail_input[]" type="text" class="new_benefit_detail_input form-control input">'+
                            '</div>'+
                            '<div class="col-md-1 mb-3 p-0" style="position:relative;">'+
                                '<span class="btn_new_proc_ben_plus_click btn_new_proc_benrisk_plus"><i class="fa fa-plus"></i></span>'+
                            '</div>'+
                            '</div>';
        $('.add_new_proc_bene_parent').append(in_html_proc_new);
    }
    });

    $(document).on('click','.btn_new_proc_risk_plus_click',function(){
var new_risk_name_input = $(this).parents('.add_new_proc_risk_single').find('.new_risk_name_input').val();
var new_risk_statistics_input = $(this).parents('.add_new_proc_risk_single').find('.new_risk_statistics_input').val();
var new_risk_detail_input = $(this).parents('.add_new_proc_risk_single').find('.new_risk_detail_input').val();
if(new_risk_name_input == ''){
$(this).parents('.add_new_proc_risk_single').find('.new_risk_name_input').focus();
}
// else if(new_risk_statistics_input == ''){
// $(this).parents('.add_new_proc_risk_single').find('.new_risk_statistics_input').focus();
// }
else if(new_risk_detail_input == ''){
   $(this).parents('.add_new_proc_risk_single').find('.new_risk_detail_input').focus(); 
}
else{
$(this).parents('.add_new_proc_risk_single').attr('data-name',new_risk_name_input);
$(this).parents('.add_new_proc_risk_single').hide();
var new_risk_detail_input_limit = new_risk_detail_input.slice(0, 40)+'...';
var in_html_risk_new = '<div class="col-md-12 temp_save_new_risk_single mt-1">'+
              '<div class="temp_save_new_risk">'+
                  '<p class="parag"><span class="Edit_risk_new_proc_name_text">'+new_risk_name_input+'</span> - <span class="Edit_risk_new_proc_name_detail">'+new_risk_detail_input+'</span> <span class="btngen_plus"><i class="fa fa-minus close_temp_save_new_risk_single" data-id="'+new_risk_name_input+'"></i></span> <span class="btngen_edit"><i class="fa fa-edit edit_temp_save_new_risk_single" data-id="'+new_risk_name_input+'"></i></span> </p>'+
              '</div>'+
          '</div>';
 $('.temp_save_new_risk_parent').append(in_html_risk_new);
var in_html_proc_new = '<div class="row add_new_proc_risk_single">'+
                            '<div class="col-md-6">'+
                                '<label class="form-label">Risk Name</label>'+
                                '<input name="new_risk_code_input[]" type="hidden" class="new_risk_code_input form-control input">'+
                                '<input name="new_risk_status_input[]" type="hidden" class="new_risk_status_input form-control input" value="0">'+
                                 '<input name="new_risk_userid_input[]" type="hidden" class="new_risk_userid_input form-control input" value="">'+
                                '<input name="new_risk_name_input[]" type="text" class="new_risk_name_input form-control input">'+
                            '</div>'+
                            '<div class="col-md-6">'+
                                '<label class="form-label">Risk Statistics</label>'+
                                '<input name="new_risk_statistics_input[]" type="text" class="new_risk_statistics_input form-control input">'+
                            '</div>'+
                            '<div class="col-md-11 mt-2">'+
                                '<label class="form-label">Risk Detail</label>'+
                                '<input name="new_risk_detail_input[]" type="text" class="new_risk_detail_input form-control input">'+
                            '</div>'+
                            '<div class="col-md-1 mb-3 p-0" style="position:relative;">'+
                                '<span class="btn_new_proc_risk_plus_click btn_new_proc_benrisk_plus"><i class="fa fa-plus"></i></span>'+
                            '</div>'+
                            '</div>';
        $('.add_new_proc_risk_parent').append(in_html_proc_new);
    }
    });

    $('#new_procedure_form').submit(function(e) {
        e.preventDefault();
        $('.add_newproc_submit_btn').hide();
        $('.add_newproc_submit_btn_loader').show();
        let formData = new FormData(this);
        $.ajaxSetup({
          headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
      });
         $.ajax({
        // headers: {
        //     'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')
        // },
        url: $(this).attr('action'),
        type: $(this).attr('method'),
        data: formData,
         processData: false,
    contentType: false,
    cache: false,
        dataType: "json",
         success: function(data) {
            console.log(data);
            var in_html_sep_ben = '<div class="row sepben_option_row" data-id="'+data.procedure.procedure_code+'">'+
                            '<div class="col-md-12">';
      in_html_sep_ben += '<div class="form-check">'+
      '<input type="radio" class="form-check-input sepben_option" id="check'+data.procedure.procedure_code+'" name="sepben_option[]" value="'+data.procedure.id+'">'+
      '<label class="form-check-label" for="check'+data.procedure.procedure_code+'">'+data.procedure.procedure_code+' '+data.procedure.procedure_name+'</label>'+
    '</div>';
                            in_html_sep_ben += '</div></div>';
                        $('.fetch_procedure_another_benefit').append(in_html_sep_ben);
                        var in_html_sep_risk = '<div class="row seprisk_option_row" data-id="'+data.procedure.procedure_code+'">'+
                            '<div class="col-md-12">';
      in_html_sep_risk += '<div class="form-check">'+
      '<input type="radio" class="form-check-input seprisk_option" id="check'+data.procedure.procedure_code+'" name="seprisk_option[]" value="'+data.procedure.id+'">'+
      '<label class="form-check-label" for="check'+data.procedure.procedure_code+'">'+data.procedure.procedure_code+' '+data.procedure.procedure_name+'</label>'+
    '</div>';
                            in_html_sep_risk += '</div></div>';
                        $('.fetch_procedure_another_risk').append(in_html_sep_risk);
             procedure_code_array.push(data.procedure.procedure_code)
                // console.log(procedure_code_array)
                array_surgery_parent.push(data);
                // window.ar = array_surgery_parent;
                // console.log(array_surgery_parent)

                for (var i = 0; i < data.benefit.length; i++) {
                var array_surgery_child_ben = new Object();
                array_surgery_child_ben.procedure_code = data.procedure.procedure_code;
                array_surgery_child_ben.procedure_name = data.procedure.procedure_name;
                array_surgery_child_ben.benefit_code = data.benefit[i].code;
                array_surgery_child_ben.benefit_name = data.benefit[i].benefit_name;
                array_surgery_child_ben.benefit_statistics = data.benefit[i].statistics;
                array_surgery_child_ben.benefit_detail = data.benefit[i].detail;
                array_surgery_ben.push(array_surgery_child_ben);
            }
            for (var i = 0; i < data.risk.length; i++) {
                var array_surgery_child_risk = new Object();
                array_surgery_child_risk.procedure_code = data.procedure.procedure_code;
                array_surgery_child_risk.procedure_name = data.procedure.procedure_name;
                array_surgery_child_risk.risk_code = data.risk[i].code;
                array_surgery_child_risk.risk_name = data.risk[i].risk_name;
                array_surgery_child_risk.risk_statistics = data.risk[i].statistics;
                array_surgery_child_risk.risk_detail = data.risk[i].detail;
                array_surgery_risk.push(array_surgery_child_risk);
            }
                // var result_ben_new = Object.groupBy(array_surgery_ben, ({ benefit_code }) => benefit_code);
                const result_ben_new = groupBy(array_surgery_ben, 'benefit_code');
                array_surgery_ben['benefit'] = result_ben_new;
                console.log('resl benfit', result_ben_new)
                // var result_risk_new = Object.groupBy(array_surgery_risk, ({ risk_code }) => risk_code);
                const result_risk_new = groupBy(array_surgery_risk, 'risk_code');
                array_surgery_risk['risk'] = result_risk_new;
                console.log('resl risk', result_risk_new)
                riskben_fetch(array_surgery_ben,array_surgery_risk)
              var in_html_proc = '<div class="row singleproc" data-code="'+data.procedure.procedure_code+'">'+
                            '<div class="col-md-2" style="position:relative;">'+
                            '<span class="data_unq_code">'+data.procedure.procedure_code+'</span>'+
                                '<label for="side" class="form-label">Side</label>'+
                                '<input name="side" type="text" required class="side form-control input <?php $__errorArgs = ['side'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">'+
                            '</div>'+
                            '<div class="col-md-2">'+
                                '<label for="site" class="form-label">Site</label>'+
                                '<input name="site" type="text" required class="site form-control input <?php $__errorArgs = ['site'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">'+
                            '</div>'+
                            '<div class="col-md-7">'+
                                '<label for="procedureseach" class="form-label">Procedure</label>'+
                                '<input name="procedure" type="text" required id="procedureseach" class="procedureseach form-control input <?php $__errorArgs = ['procedure'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="'+data.procedure.procedure_name+'" readonly>'+
                            '</div>'+
                            '<div class="col-md-1 mb-3 p-0" style="position:relative;">'+
                                '<span class="btnprocedure_minus" data-id="'+data.procedure.procedure_code+'"><i class="fa fa-minus"></i></span>'+
                                '<span class="btnprocedure_edit" data-id="'+data.procedure.id+'"><i class="fa fa-edit"></i></span>'+
                            '</div>'+
                            '<p class="p_plusmin_pre" style="    position: absolute;top: 23px;left: 34%;color: green;font-size: 20px;    width: 30px;">'+$('#plusmin_pre').val()+'</p>'+
                        '</div>';
        $('.parentprocedure').append(in_html_proc);
        $('#newProc_Modal').modal('hide')
        $('.temp_save_new_bene_parent').html('')
        $('.temp_save_new_risk_parent').html('')
        $('.add_new_proc_risk_single').remove('')
        $('.add_new_proc_bene_single').remove('')
        var in_html_proc_new_risk = '<div class="row add_new_proc_risk_single">'+
                            '<div class="col-md-6">'+
                                '<label class="form-label">Risk Name</label>'+
                                '<input name="new_risk_code_input[]" type="hidden" class="new_risk_code_input form-control input">'+
                                '<input name="new_risk_status_input[]" type="hidden" class="new_risk_status_input form-control input" value="0">'+
                                 '<input name="new_risk_userid_input[]" type="hidden" class="new_risk_userid_input form-control input" value="">'+
                                '<input name="new_risk_name_input[]" type="text" class="new_risk_name_input form-control input">'+
                            '</div>'+
                            '<div class="col-md-6">'+
                                '<label class="form-label">Risk Statistics</label>'+
                                '<input name="new_risk_statistics_input[]" type="text" class="new_risk_statistics_input form-control input">'+
                            '</div>'+
                            '<div class="col-md-11 mt-2">'+
                                '<label class="form-label">Risk Detail</label>'+
                                '<input name="new_risk_detail_input[]" type="text" class="new_risk_detail_input form-control input">'+
                            '</div>'+
                            '<div class="col-md-1 mb-3 p-0" style="position:relative;">'+
                                '<span class="btn_new_proc_risk_plus_click btn_new_proc_benrisk_plus"><i class="fa fa-plus"></i></span>'+
                            '</div>'+
                            '</div>';
        $('.add_new_proc_risk_parent').append(in_html_proc_new_risk);

        var in_html_proc_new_bene = '<div class="row add_new_proc_bene_single">'+
                            '<div class="col-md-6">'+
                                '<label class="form-label">Benefit Name</label>'+
                                '<input name="new_benefit_code_input[]" type="hidden" class="new_benefit_code_input form-control input">'+
                                '<input name="new_benefit_status_input[]" type="hidden" class="new_benefit_status_input form-control input" value="0">'+
                                '<input name="new_benefit_userid_input[]" type="hidden" class="new_benefit_userid_input form-control input" value="">'+
                                '<input name="new_benefit_name_input[]" type="text" class="new_benefit_name_input form-control input">'+
                            '</div>'+
                            '<div class="col-md-6">'+
                                '<label class="form-label">Benefit Statistics</label>'+
                                '<input name="new_benefit_statistics_input[]" type="text" class="new_benefit_statistics_input form-control input">'+
                            '</div>'+
                            '<div class="col-md-11 mt-2">'+
                                '<label class="form-label">Benefit Detail</label>'+
                                '<input name="new_benefit_detail_input[]" type="text" class="new_benefit_detail_input form-control input">'+
                            '</div>'+
                            '<div class="col-md-1 mb-3 p-0" style="position:relative;">'+
                                '<span class="btn_new_proc_ben_plus_click btn_new_proc_benrisk_plus"><i class="fa fa-plus"></i></span>'+
                            '</div>'+
                            '</div>';
        $('.add_new_proc_bene_parent').append(in_html_proc_new_bene);
        $('.add_newproc_submit_btn').show();
        $('.add_newproc_submit_btn_loader').hide();
        $('.super_parentbenefit').show();
                $('.super_parentrisk').show();
                $('.singleproc:last .side').val($('#side_pre').val());
                $('.singleproc:last .site').val($('#site_pre').val());
                $('#side_pre').val('')
                $('#site_pre').val('')
                checkproc();
        },
        error: function(err) {
            console.log(err)
        }
    });
    });

// add new benefit
    $(document).on('click','.sep_btn_new_proc_ben_plus_click',function(){
var sep_new_benefit_name_input = $(this).parents('.sep_add_new_proc_bene_single').find('.sep_new_benefit_name_input').val();
var sep_new_benefit_statistics_input = $(this).parents('.sep_add_new_proc_bene_single').find('.sep_new_benefit_statistics_input').val();
var sep_new_benefit_detail_input = $(this).parents('.sep_add_new_proc_bene_single').find('.sep_new_benefit_detail_input').val();
if(sep_new_benefit_name_input == ''){
$(this).parents('.sep_add_new_proc_bene_single').find('.sep_new_benefit_name_input').focus();
}
// else if(sep_new_benefit_statistics_input == ''){
// $(this).parents('.sep_add_new_proc_bene_single').find('.sep_new_benefit_statistics_input').focus();
// }
else if(sep_new_benefit_detail_input == ''){
   $(this).parents('.sep_add_new_proc_bene_single').find('.sep_new_benefit_detail_input').focus(); 
}
else{
$(this).parents('.sep_add_new_proc_bene_single').attr('data-name',sep_new_benefit_name_input);
$(this).parents('.sep_add_new_proc_bene_single').hide();
var sep_new_benefit_detail_input_limit = sep_new_benefit_detail_input.slice(0, 20)+'...';
var sep_in_html_ben_new = '<div class="col-md-12 sep_temp_save_new_bene_single mt-1">'+
              '<div class="sep_temp_save_new_bene">'+
                  '<p class="parag">'+sep_new_benefit_name_input+' - '+sep_new_benefit_detail_input+' <span class="btngen_plus"> <i class="fa fa-minus close_sep_temp_save_new_bene_single" data-id="'+sep_new_benefit_name_input+'"></i></span> </p>'+
              '</div>'+
          '</div>';
 $('.sep_temp_save_new_bene_parent').append(sep_in_html_ben_new);
var in_html_ben_new = '<div class="row sep_add_new_proc_bene_single">'+
                            '<div class="col-md-6">'+
                                '<label class="form-label">Benefit Name</label>'+
                                '<input name="sep_new_benefit_code_input[]" type="hidden" class="sep_new_benefit_code_input form-control input">'+
                                '<input name="sep_new_benefit_name_input[]" type="text" class="sep_new_benefit_name_input form-control input">'+
                            '</div>'+
                            '<div class="col-md-6">'+
                                '<label class="form-label">Benefit Statistics</label>'+
                                '<input name="sep_new_benefit_statistics_input[]" type="text" class="sep_new_benefit_statistics_input form-control input">'+
                            '</div>'+
                            '<div class="col-md-11 mt-2">'+
                                '<label class="form-label">Benefit Detail</label>'+
                                '<input name="sep_new_benefit_detail_input[]" type="text" class="sep_new_benefit_detail_input form-control input">'+
                            '</div>'+
                            '<div class="col-md-1 mb-3 p-0" style="position:relative;">'+
                                '<span class="sep_btn_new_proc_ben_plus_click btn_new_proc_benrisk_plus"><i class="fa fa-plus"></i></span>'+
                            '</div>'+
                            '</div>';
        $('.sep_add_new_proc_bene_parent').append(in_html_ben_new);
    }
    });

    $('#new_benefit_form').submit(function(e) {
        e.preventDefault();
        if($('.sepben_option:checked').length == 0){
        alert('please atleast one procedure')
    }
    else{
        $('.anotherbenefit_btn').hide();
        $('.anotherbenefit_btn_loader').show();
        let formData = new FormData(this);
        $.ajaxSetup({
          headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
      });
         $.ajax({
        // headers: {
        //     'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')
        // },
        url: $(this).attr('action'),
        type: $(this).attr('method'),
        data: formData,
         processData: false,
    contentType: false,
    cache: false,
        dataType: "json",
         success: function(data) {

            // console.log(array_surgery_ben);
            console.log(data);
            for (var i = 0; i < data.benefit.length; i++) {
                var array_surgery_child_ben = new Object();
                array_surgery_child_ben.procedure_code = data.procedure.procedure_code;
                array_surgery_child_ben.procedure_name = data.procedure.procedure_name;
                array_surgery_child_ben.benefit_code = data.benefit[i].code;
                array_surgery_child_ben.benefit_name = data.benefit[i].benefit_name;
                array_surgery_child_ben.benefit_statistics = data.benefit[i].statistics;
                array_surgery_child_ben.benefit_detail = data.benefit[i].detail;
                array_surgery_ben.push(array_surgery_child_ben);
            }
                // var result_ben_new = Object.groupBy(array_surgery_ben, ({ benefit_code }) => benefit_code);
                const result_ben_new = groupBy(array_surgery_ben, 'benefit_code');
                array_surgery_ben['benefit'] = result_ben_new;
                riskben_fetch(array_surgery_ben,array_surgery_risk)
        
        $('.anotherbenefit_btn').show();
        $('.anotherbenefit_btn_loader').hide();
        $('#anotherbenefit_Modal').modal('hide')
        },
        error: function(err) {
            console.log(err)
        }
    });
     }
    });

// add new risk
    $(document).on('click','.sep_btn_new_proc_risk_plus_click',function(){
var sep_new_risk_name_input = $(this).parents('.sep_add_new_proc_risk_single').find('.sep_new_risk_name_input').val();
var sep_new_risk_statistics_input = $(this).parents('.sep_add_new_proc_risk_single').find('.sep_new_risk_statistics_input').val();
var sep_new_risk_detail_input = $(this).parents('.sep_add_new_proc_risk_single').find('.sep_new_risk_detail_input').val();
if(sep_new_risk_name_input == ''){
$(this).parents('.sep_add_new_proc_risk_single').find('.sep_new_risk_name_input').focus();
}
// else if(sep_new_risk_statistics_input == ''){
// $(this).parents('.sep_add_new_proc_risk_single').find('.sep_new_risk_statistics_input').focus();
// }
else if(sep_new_risk_detail_input == ''){
   $(this).parents('.sep_add_new_proc_risk_single').find('.sep_new_risk_detail_input').focus(); 
}
else{
$(this).parents('.sep_add_new_proc_risk_single').attr('data-name',sep_new_risk_name_input);
$(this).parents('.sep_add_new_proc_risk_single').hide();
var sep_new_risk_detail_input_limit = sep_new_risk_detail_input.slice(0, 20)+'...';
var sep_in_html_risk_new = '<div class="col-md-12 sep_temp_save_new_risk_single mt-1">'+
              '<div class="sep_temp_save_new_risk">'+
                  '<p class="parag">'+sep_new_risk_name_input+' - '+sep_new_risk_detail_input+' <span class="btngen_plus"><i class="fa fa-minus close_sep_temp_save_new_risk_single" data-id="'+sep_new_risk_name_input+'"></i></span> </p>'+
              '</div>'+
          '</div>';
 $('.sep_temp_save_new_risk_parent').append(sep_in_html_risk_new);
var in_html_risk_new = '<div class="row sep_add_new_proc_risk_single">'+
                            '<div class="col-md-6">'+
                                '<label class="form-label">Risk Name</label>'+
                                '<input name="sep_new_risk_code_input[]" type="hidden" class="sep_new_risk_code_input form-control input">'+
                                '<input name="sep_new_risk_name_input[]" type="text" class="sep_new_risk_name_input form-control input">'+
                            '</div>'+
                            '<div class="col-md-6">'+
                                '<label class="form-label">Risk Statistics</label>'+
                                '<input name="sep_new_risk_statistics_input[]" type="text" class="sep_new_risk_statistics_input form-control input">'+
                            '</div>'+
                            '<div class="col-md-11 mt-2">'+
                                '<label class="form-label">Risk Detail</label>'+
                                '<input name="sep_new_risk_detail_input[]" type="text" class="sep_new_risk_detail_input form-control input">'+
                            '</div>'+
                            '<div class="col-md-1 mb-3 p-0" style="position:relative;">'+
                                '<span class="sep_btn_new_proc_risk_plus_click btn_new_proc_benrisk_plus"><i class="fa fa-plus"></i></span>'+
                            '</div>'+
                            '</div>';
        $('.sep_add_new_proc_risk_parent').append(in_html_risk_new);
    }
    });

    $('#new_risk_form').submit(function(e) {
        e.preventDefault();
        if($('.seprisk_option:checked').length == 0){
        alert('please atleast one procedure')
    }
    else{
        $('.anotherrisk_btn').hide();
        $('.anotherrisk_btn_loader').show();
        let formData = new FormData(this);
        $.ajaxSetup({
          headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
      });
         $.ajax({
        // headers: {
        //     'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')
        // },
        url: $(this).attr('action'),
        type: $(this).attr('method'),
        data: formData,
         processData: false,
    contentType: false,
    cache: false,
        dataType: "json",
         success: function(data) {

            // console.log(array_surgery_risk);
            console.log(data);
            for (var i = 0; i < data.risk.length; i++) {
                var array_surgery_child_risk = new Object();
                array_surgery_child_risk.procedure_code = data.procedure.procedure_code;
                array_surgery_child_risk.procedure_name = data.procedure.procedure_name;
                array_surgery_child_risk.risk_code = data.risk[i].code;
                array_surgery_child_risk.risk_name = data.risk[i].risk_name;
                array_surgery_child_risk.risk_statistics = data.risk[i].statistics;
                array_surgery_child_risk.risk_detail = data.risk[i].detail;
                array_surgery_risk.push(array_surgery_child_risk);
            }
                // var result_risk_new = Object.groupBy(array_surgery_risk, ({ risk_code }) => risk_code);
                const result_risk_new = groupBy(array_surgery_risk, 'risk_code');
                array_surgery_risk['risk'] = result_risk_new;
                riskben_fetch(array_surgery_ben,array_surgery_risk)
        
        $('.anotherrisk_btn').show();
        $('.anotherrisk_btn_loader').hide();
        $('#anotherrisk_Modal').modal('hide')
        },
        error: function(err) {
            console.log(err)
        }
    });
     }
    });

    $(document).on('click','.close_sep_temp_save_new_risk_single',function(){
        var name = $(this).attr('data-id');
        $(this).parents('.sep_temp_save_new_risk_single').remove();
        $('.sep_add_new_proc_risk_single[data-name='+name+']').remove();
    })

     $(document).on('click','.close_temp_save_new_risk_single',function(){
        var name = $(this).attr('data-id');
        $(this).parents('.temp_save_new_risk_single').remove();
        $('.add_new_proc_risk_single[data-name="'+name+'"]').remove();
        // $('.gen_risk_div[data-name="'+name+'"]').parent('.col-md-12').show();
    })

    $(document).on('click','.close_sep_temp_save_new_bene_single',function(){
        var name = $(this).attr('data-id');
        $(this).parents('.sep_temp_save_new_bene_single').remove();
        $('.sep_add_new_proc_bene_single[data-name="'+name+'"]').remove();
    })

    $(document).on('click','.close_temp_save_new_bene_single',function(){
        var name = $(this).attr('data-id');
        $(this).parents('.temp_save_new_bene_single').remove();
        $('.add_new_proc_bene_single[data-name="'+name+'"]').remove();
        // $('.gen_benefit_div[data-name="'+name+'"]').parent('.col-md-12').show();
    })

$(document).on('click','.btnsubmit_procedure_all',function(){
$('#Patient_Modal').modal('show')
$('#generate_consent_btn').removeAttr('data-sign-pat');
$('#generate_consent_btn').removeAttr('data-sign-doc');
});

$(document).on('click','.btn_close_modal_patient',function(){
$('#Patient_Modal').modal('hide')
});
// $(document).on('click','#generate_consent_btn',function(){
// var A4_procedure_fetch = '';
//     $('.singleproc').each(function(){
//     var resultString_pc = $(this).find('.data_unq_code').text().replace(/^P-/i, '');
//     A4_procedure_fetch += '<p>'+
//         '<span class="A4_procedure_code">'+resultString_pc+'</span> <span class="A4_procedure_star"><i class="fa-solid fa-arrow-right"></i></span> <span class="A4_procedure_side">'+$(this).find('.side').val()+'</span> <span class="A4_procedure_site">'+$(this).find('.site').val()+'</span> <span class="A4_procedure_site">'+$(this).find('.procedureseach').val()+'</span>'+
//     '</p>';
// });
//     $('.A4_procedure_fetch').html(A4_procedure_fetch)
//       printDiv();
//     })
    function printDiv() 
{

  var divToPrint=document.getElementById('DivIdToPrint');

  var newWin=window.open('','Print-Window');

  newWin.document.open();
  var htm = '<html><head><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">'+
    '<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">'+
    '<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/print.css')); ?>"></head>'+
    '<body onload="window.print()">'+divToPrint.innerHTML+'</body></html>';
  newWin.document.write(htm);

  newWin.document.close();

  // setTimeout(function(){newWin.close();},10);

}

// const copyListener = (event) => {
//   const selection = window.getSelection();

//   if (!selection.isCollapsed) {
//     const range = selection.getRangeAt(0);
//     const pageLink = `copyright: Surgery Consent Companion: ${document.location.href}`;
//     const selectedText = range.toString().trim();

//     // Split the selected text into lines
//     const lines = selectedText.split('\n');

//     // Add "Read more" content to each line
//     const formattedLines = lines.map(line => `${line} - ${pageLink}`);

//     // Join the lines back together with line breaks
//     const copiedContent = formattedLines.join('\n');

//     event.clipboardData.setData("text/plain", copiedContent);
//     event.clipboardData.setData("text/html", `<div>${formattedLines.join('<br>')}</div>`);

//     event.preventDefault();
//   }
// };

// document.addEventListener("copy", copyListener);




    $(document).on('click','.gen_benefit_div',function(){
        var name = $(this).attr('data-name');
        var code = $(this).attr('data-code');
        var statistics = $(this).attr('data-statistics');
        var detail = $(this).attr('data-detail');
        var status = $(this).attr('data-status');
        var userid = $(this).attr('data-userid');
        $(this).parent('.col-md-12').hide();

        var new_benefit_detail_input_limit = detail.slice(0, 50)+'...';
        var in_html_ben_new = '<div class="col-md-12 temp_save_new_bene_single mt-1">'+
              '<div class="temp_save_new_bene">'+
                  '<p class="parag"> '+name+' - '+detail+' <span class="btngen_plus"><i class="fa fa-minus close_temp_save_new_bene_single" data-id="'+name+'"></i></span></p>'+
              '</div>'+
          '</div>';
        $('.temp_save_new_bene_parent').append(in_html_ben_new);

        var in_html_proc_new = '<div class="row add_new_proc_bene_single" data-name="'+name+'" style="display:none">'+
                            '<div class="col-md-6">'+
                                '<label class="form-label">Benefit Name</label>'+
                                '<input name="new_benefit_code_input[]" type="hidden" class="new_benefit_code_input form-control input" value="'+code+'">'+
                                '<input name="new_benefit_status_input[]" type="hidden" class="new_benefit_status_input form-control input" value="'+status+'">'+
                                '<input name="new_benefit_userid_input[]" type="hidden" class="new_benefit_userid_input form-control input" value="'+userid+'">'+
                                '<input name="new_benefit_name_input[]" type="text" class="new_benefit_name_input form-control input" value="'+name+'">'+
                            '</div>'+
                            '<div class="col-md-6">'+
                                '<label class="form-label">Benefit Statistics</label>'+
                                '<input name="new_benefit_statistics_input[]" type="text" class="new_benefit_statistics_input form-control input" value="'+statistics+'">'+
                            '</div>'+
                            '<div class="col-md-11 mt-2">'+
                                '<label class="form-label">Benefit Detail</label>'+
                                '<input name="new_benefit_detail_input[]" type="text" class="new_benefit_detail_input form-control input" value="'+detail+'">'+
                            '</div>'+
                            '<div class="col-md-1 mb-3 p-0" style="position:relative;">'+
                                '<span class="btn_new_proc_ben_plus_click btn_new_proc_benrisk_plus"><i class="fa fa-plus"></i></span>'+
                            '</div>'+
                            '</div>';
        $('.add_new_proc_bene_parent').append(in_html_proc_new);
    })


    $(document).on('click','.gen_risk_div',function(){
        var name = $(this).attr('data-name');
        var code = $(this).attr('data-code');
        var statistics = $(this).attr('data-statistics');
        var detail = $(this).attr('data-detail');
        var status = $(this).attr('data-status');
        var userid = $(this).attr('data-userid');
        $(this).parent('.col-md-12').hide();

        var new_risk_detail_input_limit = detail.slice(0, 40)+'...';
        var in_html_risk_new = '<div class="col-md-12 temp_save_new_risk_single mt-1">'+
              '<div class="temp_save_new_risk">'+
                  '<p class="parag">'+name+' - '+detail+' <span class="btngen_plus"><i class="fa fa-minus close_temp_save_new_risk_single" data-id="'+name+'"></i></span> </p>'+
              '</div>'+
          '</div>';
        $('.temp_save_new_risk_parent').append(in_html_risk_new);

        var in_html_proc_new = '<div class="row add_new_proc_risk_single" data-name="'+name+'" style="display:none">'+
                            '<div class="col-md-6">'+
                                '<label class="form-label">Risk Name</label>'+
                                '<input name="new_risk_code_input[]" type="hidden" class="new_risk_code_input form-control input" value="'+code+'">'+
                                '<input name="new_risk_status_input[]" type="hidden" class="new_risk_status_input form-control input" value="'+status+'">'+
                                 '<input name="new_risk_userid_input[]" type="hidden" class="new_risk_userid_input form-control input" value="'+userid+'">'+
                                '<input name="new_risk_name_input[]" type="text" class="new_risk_name_input form-control input" value="'+name+'">'+
                            '</div>'+
                            '<div class="col-md-6">'+
                                '<label class="form-label">Risk Statistics</label>'+
                                '<input name="new_risk_statistics_input[]" type="text" class="new_risk_statistics_input form-control input" value="'+statistics+'">'+
                            '</div>'+
                            '<div class="col-md-11 mt-2">'+
                                '<label class="form-label">Risk Detail</label>'+
                                '<input name="new_risk_detail_input[]" type="text" class="new_risk_detail_input form-control input" value="'+detail+'">'+
                            '</div>'+
                            '<div class="col-md-1 mb-3 p-0" style="position:relative;">'+
                                '<span class="btn_new_proc_risk_plus_click btn_new_proc_benrisk_plus"><i class="fa fa-plus"></i></span>'+
                            '</div>'+
                            '</div>';
        $('.add_new_proc_risk_parent').append(in_html_proc_new);
    })

</script>
     
<script>
  document.addEventListener('DOMContentLoaded', function () {
    var currentDate = new Date();

    // Get local date string in "YYYY-MM-DD" format
    var formattedDate = currentDate.toLocaleDateString('en-CA'); // Adjust the locale as needed

    // Set the default value for the input field
    document.getElementById('pat_dob').value = formattedDate;

    var canvas = document.getElementById('canvas');
  var context = canvas.getContext('2d');
  var isDrawing = false;
  var isplaceholder = true;

  function startDrawing(e) {
    isDrawing = true;
    if (isplaceholder === true) {
    context.clearRect(0, 0, canvas.width, canvas.height); // Clear the canvas
    }
    draw(e);
    isplaceholder = false;
  }

  function stopDrawing() {
    isDrawing = false;
    context.beginPath();
  }

  function draw(e) {
    if (!isDrawing) return;

    context.lineWidth = 4;
    context.lineCap = 'round';
    context.strokeStyle = '#000';

    // Use e.touches for touch events
    var x = e.clientX || e.touches[0].clientX;
    var y = e.clientY || e.touches[0].clientY;

    context.lineTo(x - canvas.getBoundingClientRect().left, y - canvas.getBoundingClientRect().top);
    context.stroke();
    context.beginPath();
    context.moveTo(x - canvas.getBoundingClientRect().left, y - canvas.getBoundingClientRect().top);
  }

  canvas.addEventListener('mousedown', startDrawing);
  canvas.addEventListener('mouseup', stopDrawing);
  canvas.addEventListener('mousemove', draw);
  canvas.addEventListener('touchstart', startDrawing);
  canvas.addEventListener('touchmove', draw);
  canvas.addEventListener('touchend', stopDrawing);

  // Clear the canvas
  document.getElementById('clearBtn').addEventListener('click', function () {
    context.clearRect(0, 0, canvas.width, canvas.height);
    drawPlaceholder();
  });

    drawPlaceholder();

  function drawPlaceholder() {
    isplaceholder = true;
    context.font = '16px Arial';
    context.fillStyle = '#888';
    var text = 'Sign Here';
    var textWidth = context.measureText(text).width;
    var x = (canvas.width - textWidth) / 2;
    var y = canvas.height - 20; // Adjust the y-coordinate as needed

    context.fillText(text, x, y);
  }

    // Save the signature as an image
    document.getElementById('saveBtn').addEventListener('click', function () {
        var check_btn_type = $(this).attr('data-check')
        // alert(check_btn_type)
      var dataURL = canvas.toDataURL();
      console.log(dataURL); // You can send this dataURL to your server for saving or processing
      // Example: Send dataURL to server using AJAX
      var path_save_sign = "<?php echo e(url('save-signature')); ?>";
      var csrfToken = $('meta[name="csrf-token"]').attr('content');

      $.ajax({
        type: 'POST',
        url: path_save_sign,
        data: { signature: dataURL,  _token: csrfToken},
        success: function(response) {
          console.log(response.message);  // Message from the server
          if(check_btn_type == 'patient'){
            console.log(response.url); 
            $(".patient_sign_content").hide();
            $(".doctor_sign_content").show();
            $("#saveBtn").attr('data-check','doctor');
            $("#clearBtn").click();
            $('#generate_consent_btn').attr('data-sign-pat',response.url)
          }
          else{
            $('#generate_consent_btn').attr('data-sign-doc',response.url)
             $("#Patient_Modalsign").modal('hide');
            $('#Patient_Modal').modal('show')
            $('.patientsign_submit_btn').click();
          }
          // Optionally, you can handle the response from the server here
        },
        error: function(error) {
          console.error(error);
        }
      });
    });
  });
</script>

<script type="text/javascript">
    $(document).on('change','#digitalsignnow_checkbox',function(){
        if($(this).is(':checked')){
            $("#Patient_Modalsign").modal('show');
            $(".patient_sign_content").show();
            $(".doctor_sign_content").hide();
            $("#saveBtn").attr('data-check','patient');
            $("#clearBtn").click();
            $('#Patient_Modal').modal('hide')
        }
    });

    $(document).on('click','.btn_close_modal_patientsign',function(){
            $('#digitalsignnow_checkbox').prop('checked',false)
            $("#Patient_Modalsign").modal('hide');
    });

    $(document).on('click','.patientsign_submit_btn',function(){
            $("#Patient_Modalsign").modal('hide');
            $('#Patient_Modal').modal('show')
    });

    $(document).on('change keyup','#pat_email',function(){
        if($(this).val() != ''){
            $('#emailcopyropatient_checkbox').prop('checked',true)
        }
        else{
            $('#emailcopyropatient_checkbox').prop('checked',false)
        }
    });

    $(document).on('click','#generate_consent_btn',function(){
    var sign_pat = $(this).attr('data-sign-pat');
    var sign_doc = $(this).attr('data-sign-doc');
    var pat_fname = $('#pat_fname').val();
    var pat_lname = $('#pat_lname').val();
    var pat_dob = $('#pat_dob').val();
    var pat_email = $('#pat_email').val();
    var pat_phone = $('#pat_phone').val();
    var pat_gender = $('#pat_gender').val();
    var pat_address = $('#pat_address').val();
    var parsedDate = new Date(pat_dob);

      // Format the date as "D MMMM YYYY"
      var formattedDate = parsedDate.getDate() + ' ' + getMonthName(parsedDate.getMonth()) + ' ' + parsedDate.getFullYear();

      var currentDate_print = new Date();

    // Get local date string in "YYYY-MM-DD" format
    var formattedDate_print = currentDate_print.toLocaleDateString('en-CA'); // Adjust the locale as needed
    var parsedDate_print = new Date(formattedDate_print);
    var formattedDate_print_final = parsedDate_print.getDate() + ' / ' + getMonthName(parsedDate_print.getMonth()) + ' / ' + parsedDate_print.getFullYear();
    if(pat_fname == ''){
    $('#pat_fname').focus()
    return;
    }
    if(pat_lname == ''){
    $('#pat_lname').focus()
    return;
    }
    if(pat_dob == ''){
    $('#pat_dob').focus()
    return;
    }
    $('.print_pat_lname').text(pat_lname)
    $('.print_pat_fname').text(pat_fname)
    $('.print_pat_address').text(pat_address)
    $('.print_pat_dob').text(formattedDate)
    $('.print_pat_phone').text(pat_phone)
    $('.print_pat_fullname').text(pat_fname +' '+ pat_lname)
    $('.print_pat_fullname_updown').text(pat_fname +' '+ pat_lname)
    $('.print_pat_getdate').text(formattedDate_print_final)
    $('.print_pat_sign').html('')
    $('.print_pat_docsign').html('')
    if(sign_pat !== undefined){
        $('.print_pat_sign').html('<img src="'+sign_pat+'" style="width:100px;">')
    }
    if(sign_doc !== undefined){
        $('.print_pat_docsign').html('<img src="'+sign_doc+'" style="width:100px;">')
    }
    
    if(pat_address == ''){
    $('.print_pat_address').text('')
    }
    if(pat_dob == ''){
    $('.print_pat_dob').text('')
    }
    if(pat_phone == ''){
    $('.print_pat_phone').text('')
    }
    $('.print_pat_male').html('')
    $('.print_pat_female').html('')
    $('.print_pat_other').html('')
    if(pat_gender == 'male'){
        $('.print_pat_male').html('<i class="fa fa-check"></i>')
    }
    if(pat_gender == 'female'){
        $('.print_pat_female').html('<i class="fa fa-check"></i>')
    }
    if(pat_gender == 'other'){
        $('.print_pat_other').html('<i class="fa fa-check"></i>')
    }
    var A4_procedure_fetch = '';
        $('.singleproc').each(function(){
        var resultString_pc = $(this).find('.data_unq_code').text().replace(/^P-/i, '');
        A4_procedure_fetch += '<p>'+
            '<span class="A4_procedure_code">'+resultString_pc+'</span> <span class="A4_procedure_star"><i class="fa-solid fa-arrow-right"></i></span> <span class="A4_procedure_side">'+$(this).find('.side').val()+'</span> <span class="A4_procedure_site">'+$(this).find('.site').val()+'</span> <span style="color: green;font-size: 20px;">'+$(this).find('.p_plusmin_pre').text()+'</span> <span class="A4_procedure_site" style="margin:0">'+$(this).find('.procedureseach').val()+'</span>'+
        '</p>';
    });
        $('.A4_procedure_fetch').html(A4_procedure_fetch)
          printDiv();
        })

   // Helper function to get the month name
    function getMonthName(monthIndex) {
      var monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
      return monthNames[monthIndex];
    }

    $(document).on('click','.btnprocedure_edit',function(){
        window.pname_old = $(this).closest('.singleproc').find('.procedureseach').val()
        var pid = $(this).attr('data-id');
        $(this).closest('.singleproc').find('.procedureseach').removeAttr('readonly')
        $(this).closest('.singleproc').find('.procedureseach').focus()
        $(this).find('i').removeClass('fa fa-edit')
        $(this).find('i').addClass('fa fa-save')
        $(this).removeClass('btnprocedure_edit')
        $(this).addClass('btnprocedure_save')
    })

     $(document).on('click','.btnprocedure_save',function(){
        var pname = $(this).closest('.singleproc').find('.procedureseach').val();
        var pid = $(this).attr('data-id');
        $(this).closest('.singleproc').find('.procedureseach').attr('readonly','readonly')
        $(this).find('i').removeClass('fa fa-save')
        $(this).find('i').addClass('fa fa-edit')
        $(this).removeClass('btnprocedure_save')
        $(this).addClass('btnprocedure_edit')
        if(pname == pname_old){

        }
        else{
            var path_procedure_alternate = "<?php echo e(url('save_procedure_alternate')); ?>";
            $.ajaxSetup({
          headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
            });
            $.ajax({
            url: path_procedure_alternate,
            type: 'POST',
            dataType: "json",
            data: {
               pname: pname,
               pid: pid
            },
            success: function( data ) { 
            console.log(data)
        },
             error: function(err) {
                 alert('err')
            console.log(err)
        }
        })
        }
        });

     
     
$(document).on('click','.edit_temp_save_new_risk_single',function(){
var id = $(this).attr('data-id')
var type = 'risk';
$('#Edit_benrisk_new_proc').modal('show')
$('.Edit_benrisk_new_proc_title').text('Edit Risk (' + id + ')')
$('#Edit_benrisk_new_proc_done').attr('data-id',id)
$('#Edit_benrisk_new_proc_done').attr('data-type',type)
var get_risk_new_det = $('.add_new_proc_risk_single[data-name="'+id+'"]')
$('#Edit_benrisk_new_proc_name').val(get_risk_new_det.find('.new_risk_name_input').val())
$('#Edit_benrisk_new_proc_statistics').val(get_risk_new_det.find('.new_risk_statistics_input').val())
$('#Edit_benrisk_new_proc_detail').val(get_risk_new_det.find('.new_risk_detail_input').val())
});

$(document).on('click','.edit_temp_save_new_bene_single',function(){
var id = $(this).attr('data-id')
var type = 'ben';
$('#Edit_benrisk_new_proc').modal('show')
$('.Edit_benrisk_new_proc_title').text('Edit Benefit (' + id + ')')
$('#Edit_benrisk_new_proc_done').attr('data-id',id)
$('#Edit_benrisk_new_proc_done').attr('data-type',type)
var get_ben_new_det = $('.add_new_proc_bene_single[data-name="'+id+'"]')
$('#Edit_benrisk_new_proc_name').val(get_ben_new_det.find('.new_benefit_name_input').val())
$('#Edit_benrisk_new_proc_statistics').val(get_ben_new_det.find('.new_benefit_statistics_input').val())
$('#Edit_benrisk_new_proc_detail').val(get_ben_new_det.find('.new_benefit_detail_input').val())
});

$(document).on('click','#Edit_benrisk_new_proc_done',function(){
var id = $(this).attr('data-id')
var type = $(this).attr('data-type')
var name = $('#Edit_benrisk_new_proc_name').val();
var statistics = $('#Edit_benrisk_new_proc_statistics').val();
var detail = $('#Edit_benrisk_new_proc_detail').val();
if (type == 'ben') {
var get_ben_new_det = $('.add_new_proc_bene_single[data-name="'+id+'"]')
get_ben_new_det.find('.new_benefit_name_input').val(name)
get_ben_new_det.find('.new_benefit_statistics_input').val(statistics)
get_ben_new_det.find('.new_benefit_detail_input').val(detail)
$('.edit_temp_save_new_bene_single[data-id="'+id+'"]').closest('.temp_save_new_bene').find('.Edit_ben_new_proc_name_text').text(name)
$('.edit_temp_save_new_bene_single[data-id="'+id+'"]').closest('.temp_save_new_bene').find('.Edit_ben_new_proc_name_detail').text(detail)
get_ben_new_det.attr('data-name',name)
}
else{
var get_risk_new_det = $('.add_new_proc_risk_single[data-name="'+id+'"]')
get_risk_new_det.find('.new_risk_name_input').val(name)
get_risk_new_det.find('.new_risk_statistics_input').val(statistics)
get_risk_new_det.find('.new_risk_detail_input').val(detail)
$('.edit_temp_save_new_risk_single[data-id="'+id+'"]').closest('.temp_save_new_risk').find('.Edit_risk_new_proc_name_text').text(name)
$('.edit_temp_save_new_risk_single[data-id="'+id+'"]').closest('.temp_save_new_risk').find('.Edit_risk_new_proc_name_detail').text(detail)
get_risk_new_det.attr('data-name',name)
}
$('#Edit_benrisk_new_proc').modal('hide')
});

$(document).on('click','.btn_close_Edit_benrisk_new_proc',function(){
$('#Edit_benrisk_new_proc').modal('hide')
});

$(document).on('click','.btneditbenrisk_click',function(){
var cat = $(this).attr('data-cat');
var id = $(this).attr('data-id');
var procid = $(this).attr('data-procid');
var name = $(this).attr('data-name');
if (cat == 'benefit') {
var exist_name = $(this).closest('.parag').find('.existing_ben_name').text();
var exist_detail = $(this).closest('.parag').find('.existing_ben_detail').text();
}
else{
var exist_name = $(this).closest('.parag').find('.existing_risk_name').text();
var exist_detail = $(this).closest('.parag').find('.existing_risk_detail').text();
}
$('#Edit_benrisk_existing_proc_name').val(exist_name)
$('#Edit_benrisk_existing_proc_detail').val(exist_detail)
$('#Edit_benrisk_existing_proc').modal('show');
$('.Edit_benrisk_existing_proc_title').text('Edit '+ cat + ' '+ name)

$('#Edit_benrisk_existing_proc_done').attr('data-id',id)
$('#Edit_benrisk_existing_proc_done').attr('data-cat',cat)
})

$(document).on('click','.btn_close_Edit_benrisk_existing_proc',function(){
$('#Edit_benrisk_existing_proc').modal('hide');
});

$(document).on('click','#Edit_benrisk_existing_proc_done',function(){
$('#Edit_benrisk_existing_proc_done').hide();
$('.existing_benrisk_edit_submit_loader').show();
var cat = $(this).attr('data-cat');
var id = $(this).attr('data-id');
var Edit_benrisk_existing_proc_name = $('#Edit_benrisk_existing_proc_name').val();
var Edit_benrisk_existing_proc_detail = $('#Edit_benrisk_existing_proc_detail').val();
var path_benrisk_edit = "<?php echo e(url('edit_existing_benrisk')); ?>";
            $.ajaxSetup({
          headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
            });
            $.ajax({
            url: path_benrisk_edit,
            type: 'POST',
            dataType: "json",
            data: {
               cat: cat,
               id: id,
               Edit_benrisk_existing_proc_name: Edit_benrisk_existing_proc_name,
               Edit_benrisk_existing_proc_detail: Edit_benrisk_existing_proc_detail
            },
            success: function( data ) { 
            console.log(data)
            if (cat == 'benefit') {
            $('.parag[data-code="'+id+'"]').find('.existing_ben_name').text(Edit_benrisk_existing_proc_name);
            $('.parag[data-code="'+id+'"]').find('.existing_ben_detail').text(Edit_benrisk_existing_proc_detail);
            $('.parag_tr[data-code="'+id+'"]').find('.existing_ben_name_td').text(Edit_benrisk_existing_proc_name);
            $('.parag_tr[data-code="'+id+'"]').find('.existing_ben_detail_td').text(Edit_benrisk_existing_proc_detail);
            }
            else{
            $('.parag[data-code="'+id+'"]').find('.existing_risk_name').text(Edit_benrisk_existing_proc_name);
            $('.parag[data-code="'+id+'"]').find('.existing_risk_detail').text(Edit_benrisk_existing_proc_detail);
            $('.parag_tr[data-code="'+id+'"]').find('.existing_risk_name_td').text(Edit_benrisk_existing_proc_name);
            $('.parag_tr[data-code="'+id+'"]').find('.existing_risk_detail_td').text(Edit_benrisk_existing_proc_detail);
            }

            $('#Edit_benrisk_existing_proc_done').show();
            $('.existing_benrisk_edit_submit_loader').hide();
            $('#Edit_benrisk_existing_proc').modal('hide');
        },
             error: function(err) {
            console.log(err)
        }
        })
});

function checkproc(){
var proclen = $('.singleproc').length;
if(proclen == 1){
$('#side_pre').val($('.singleproc:last .side').val());
$('#site_pre').val($('.singleproc:last .site').val());
$('#side_pre').attr('readonly','readonly');
$('#site_pre').attr('readonly','readonly');
$('#plusmin_pre').show();
$('.p_plusmin_pre').text('');
$('.singleproc:first .btnprocedure_minus').show()
}
else if(proclen > 1){
$('.singleproc:first .btnprocedure_minus').hide()
$('#side_pre').val($('.singleproc:last .side').val());
$('#site_pre').val($('.singleproc:last .site').val());
$('#side_pre').attr('readonly','readonly');
$('#site_pre').attr('readonly','readonly');
$('#plusmin_pre').show();
}
else{
$('.singleproc:first .btnprocedure_minus').show()
$('#side_pre').val('');
$('#site_pre').val('');
$('#side_pre').removeAttr('readonly');
$('#site_pre').removeAttr('readonly');
$('#plusmin_pre').hide();
}
}
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\surgery\resources\views/home.blade.php ENDPATH**/ ?>