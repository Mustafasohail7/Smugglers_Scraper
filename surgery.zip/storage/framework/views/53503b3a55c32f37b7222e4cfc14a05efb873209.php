<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="icon" type="image/png" href="<?php echo e(asset('favicon.png')); ?>">
    <title>SURGERY CONSENT COMPANION</title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=Nunito" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>

    <!-- <script src="https://www.google.com/recaptcha/api.js" async defer></script> -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">


    <!-- Scripts -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
        
        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.1.3/js/bootstrap.bundle.min.js"></script>
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/print.css')); ?>">
   <style>
    body{
        background: #e8f0fe47;
    }
       #header {
/*    background-color: #074774;*/
/*    overflow: hidden;*/
/*background: #e8f0fe;*/
}
.navbar {
    padding: 0px 0;
}
.navbar-brand {
    
}
.navbar a {
    text-decoration: none;
}

#navbarSupportedContent {
    justify-content: center;
}
.leftnav{
        justify-content: left;
    display: flex;
    flex-wrap: wrap;
    width: 40%;
}
.rightnav{
        justify-content: right;
    display: flex;
    flex-wrap: wrap;
    width: 40%;
}
.fnamelname{
    font-weight: bold;
    font-size: 20px;
    color: black;
}
.settingopt{
font-weight: bold;
    font-size: 20px;
    color: black;
}
</style>
</head>
<body>
    <div id="app">
        <div id="header">
        <div class="container-fluid p-0">
            <nav class="navbar navbar-expand-lg navbar-light bg-white">
                <a class="navbar-brand d-block d-lg-none" href="<?php echo e(url('/')); ?>">
                    <img src="<?php echo e(url('/images/logo.jpeg')); ?>" alt="logo" style="width: 200px;">
                </a>
                <button class="navbar-toggler navbar_toggle" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav leftnav">
                    <?php if(auth()->guard()->guest()): ?>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link fnamelname" href="<?php echo e(url('/')); ?>"><?php echo e(Auth::user()->title); ?> <?php echo e(Auth::user()->fname); ?> <?php echo e(Auth::user()->lname); ?> <br><?php echo e(Auth::user()->practice_name); ?></span></a>
                        </li>
                    <?php endif; ?>
                    </ul>
                    <a class="navbar-brand d-none d-lg-block" href="<?php echo e(url('/')); ?>">
                    <img src="<?php echo e(url('/images/logo.jpeg')); ?>" alt="logo" style="width: 300px;">
                </a>
                    <ul class="navbar-nav rightnav">
                        <?php if(auth()->guard()->guest()): ?>
                    <?php else: ?>
                        <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle settingopt" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Settings
                                </a>

                                <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                     <a class="dropdown-item" href="<?php echo e(url('my_account')); ?>">
                                        <?php echo e(__('My Account')); ?>

                                    </a>
                                    <a class="dropdown-item" href="<?php echo e(url('change_password')); ?>">
                                        <?php echo e(__('Change Password')); ?>

                                    </a>
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>

                            </li>
                            <?php endif; ?>
                    </ul>
                </div>
            </nav>
        </div>
    </div>

        

        <main class="py-4">
            
            <?php if($flash = session('message')): ?>
        <div class="container" style="justify-content: center;display: flex;">
            <div class="col-md-4">
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e($flash); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
            </div>
        </div>
        <?php elseif($flash = session('error')): ?>
        <div class="container" style="justify-content: center;display: flex;">
            <div class="col-md-4">
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo e($flash); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            </div>
        </div>
        <?php endif; ?>
            <?php echo $__env->yieldContent('content'); ?>
        </main>

        
    </div>
</body>
</html>

<script src="<?php echo e(asset('build/js/intlTelInput.js')); ?>"></script>
<!-- <script src="<?php echo e(asset('js/html2canvas.js')); ?>"></script> -->
       <script src="https://unpkg.com/jspdf@latest/dist/jspdf.umd.min.js"></script>
       <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js" integrity="sha512-GsLlZN/3F2ErC5ifS5QtgpiJtWd43JWSuIgh7mbzZ8zBps+dvLusV+eNQATqgA/HdeKFVgA5v3S/cIrLF7QnIg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script> -->
       <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>



<?php /**PATH C:\xampp\htdocs\surgery\resources\views/layouts/app.blade.php ENDPATH**/ ?>