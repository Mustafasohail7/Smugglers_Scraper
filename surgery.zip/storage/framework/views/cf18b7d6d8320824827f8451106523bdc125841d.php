<nav class="navbar default-layout-navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
  <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center">
    <a class="navbar-brand brand-logo" href="<?php echo e(url('/admin')); ?>"><img src="<?php echo e(url('/images/logo.jpeg')); ?>" style="width: 230px;height: 70px;" alt="logo" /></a>
    <a class="navbar-brand brand-logo-mini" href="<?php echo e(url('/admin')); ?>"><img src="<?php echo e(url('/images/apple-icon-60x60.png')); ?>" style="height:20px" alt="logo" /></a>
  </div>
  <div class="navbar-menu-wrapper d-flex align-items-stretch">
    <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
      <span class="mdi mdi-menu"></span>
    </button>
    <ul class="navbar-nav navbar-nav-right">
      <li class="nav-item nav-profile dropdown">
        <a class="nav-link dropdown-toggle" id="profileDropdown" href="#" data-bs-toggle="dropdown" aria-expanded="false">
          <div class="nav-profile-img">
            <img src="<?php echo e(url('assets/images/faces/face1.jpg')); ?>" alt="image">
            <!-- <span class="availability-status online"></span> -->
          </div>
          <div class="nav-profile-text">
            <p class="mb-1 text-black"><?php echo e(Auth::user()->fname); ?> <?php echo e(Auth::user()->lname); ?></p>
          </div>
        </a>
        <div class="dropdown-menu navbar-dropdown" aria-labelledby="profileDropdown">
          <a class="dropdown-item" href="<?php echo e(url('admin_myaccount')); ?>">
            <i class="mdi mdi-account-box me-2 text-primary"></i> My Account </a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="<?php echo e(url('admin_websetting')); ?>">
            <i class="mdi mdi-settings me-2 text-primary"></i> Website Setting </a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="<?php echo e(url('admin_changepassword')); ?>">
            <i class="mdi mdi-account-key me-2 text-primary"></i> Change Password </a>
        </div>
      </li>
      <li class="nav-item d-none d-lg-block full-screen-link">
        <a class="nav-link">
          <i class="mdi mdi-fullscreen" id="fullscreen-button"></i>
        </a>
      </li>
      
      <li class="nav-item nav-logout d-none d-lg-block">
        <a class="nav-link" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
          <i class="mdi mdi-power"></i>
        </a>
        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
      </li>
    </ul>
    <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
      <span class="mdi mdi-menu"></span>
    </button>
  </div>
</nav>

<?php /**PATH C:\xampp\htdocs\surgery\resources\views/admin/inc/nav.blade.php ENDPATH**/ ?>