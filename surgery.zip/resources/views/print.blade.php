<page size="A4" id="DivIdToPrint" style="display: none;">
<div class="header">
    <p class="print_pat_fullname_updown"></p>
  </div>
<div class="row A4_parent_header">
	<div class="col-md-6 header_img">
		<img src="{{ url('/images/logo.jpeg') }}" alt="logo" style="width: 200px;margin-top: 15px;">
	</div>
	<div class="col-md-6 header_content">
		<!-- <h3>Dr. Important Surgeon</h3> -->
		<h3><a class="nav-link fnamelname" href="{{ url('/') }}">{{ Auth::user()->title }} {{ Auth::user()->fname }} {{ Auth::user()->lname }} <br>{{ Auth::user()->practice_name }}</span></a></h3>
		<p>“Professional letterhead goes here</p>
	</div>
	</div>

<div class="row A4_parent_nav">
	<ul>
		<li><b>Phone:</b> {{ Auth::user()->phone }}</li>
		<li><b>Gmail:</b> {{ Auth::user()->email }}</li>
		<li><b>Address:</b> Bic City, Australia</li>
	</ul>
</div>

<div class="row A4_parent_form">
	<h3>Consent for surgical procedure</h3>
	<div class="col-md-7 form_content" style="height: 177px;
    width: 400px;">
		<p>Hospital Number: <span class="print_pat_hospitalno"></span></p>
		<p>Surname: <span class="print_pat_lname"></span></p>
		<p>Given Name: <span class="print_pat_fname"></span></p>
		<p>Address: <span class="print_pat_address"></span></p>
		<p>Date Of Birth: <span class="print_pat_dob"></span></p>
		<p>Phone Number: <span class="print_pat_phone"></span></p>
		<p>Gender: <span class="form_check_gender print_pat_male"></span> Male <span class="form_check_gender print_pat_female"></span> Female <span class="form_check_gender print_pat_other"></span> Other</p>
	</div>
</div>

<div class="row A4_parent_procedure">
	<h3>Procedure:</h3>
	<div class="A4_procedure_fetch"></div>
</div>

<div class="row A4_parent_content">
	<p>{{ $pd_agree->mp_agree }}.</p>

<div class="col-md-7 form_content2" style="width: 400px;">
		<p>Name Of Patient : <span class="print_pat_fullname"></span></p>
		<p>Signature Of Patient :<span class="print_pat_sign"></span></p>
		<p>Date : <span class="print_pat_getdate"></span></p>
	</div>

<p>{{ $pd_agree->md_agree }}.</p>

<div class="col-md-7 form_content2" style="width: 400px;">
		<p>Name Of Doctor : <span class="print_doc_fullname">{{ Auth::user()->title }} {{ Auth::user()->fname }} {{ Auth::user()->lname }}</span> </p>
		<p>Signature Of Doctor :<span class="print_pat_docsign"></span></p>
		<p>Date : <span class="print_pat_getdate"></span></p>
	</div>

</div>

<div class="row A4_parent_benrisk">
	<h3>Benefits:</h3>
	<table class="table">
    <thead>
      <tr>
        <th style="    width: 25%;
    font-weight: 600;">Benefit</th>
        <th style="    width: 50%;
    font-weight: 600;">Explaination</th>
        <!-- <th>Statistics</th> -->
        <th style="    width: 25%;
    font-weight: 600;">Procedure</th>
      </tr>
    </thead>
    <tbody class="A4_benefit_fetch">
      
  </tbody>
</table>

	<h3>Risks:</h3>
	<table class="table">
    <thead>
      <tr>
        <th style="    width: 25%;
    font-weight: 600;">Risk</th>
        <th style="    width: 50%;
    font-weight: 600;">Explaination</th>
        <!-- <th>Statistics</th> -->
        <th style="    width: 25%;
    font-weight: 600;">Procedure</th>
      </tr>
    </thead>
    <tbody class="A4_risk_fetch">

  </tbody>
</table>
</div>

 <div class="footer">
    <p class="print_pat_fullname_updown"></p>
  </div>

<script>
	const copyListener = (event) => {
  const selection = window.getSelection();

  if (!selection.isCollapsed) {
    const range = selection.getRangeAt(0);
    // const pageLink = `copyright: Surgery Consent Companion: ${document.location.href}`;
    const pageLink = `copyright: Surgery Consent Companion: ${document.location.href}`;
    // const selectedText = range.toString().trim();
    const selectedText = range.commonAncestorContainer.innerText;

    console.log(range)
    console.log(range.commonAncestorContainer.innerText)
    console.log(range.cloneContents())

    // Split the selected text into lines
    const lines = selectedText.split('\n').filter(line => line.trim() !== '' && line.trim() !== '-');

    console.log(lines)
    // Add "Read more" content to each line
		const formattedLines = lines.map(line => `${line} <br> <span style="color:#23ace1;font-size:25px;">${pageLink}</span>`);

    // Join the lines back together with line breaks
    const copiedContent = formattedLines.join('\n');

    event.clipboardData.setData("text/plain", copiedContent);
    event.clipboardData.setData("text/html", `<div>${formattedLines.join('<br>')}</div>`);

    event.preventDefault();
  }
};

document.addEventListener("copy", copyListener);
</script>
</page>