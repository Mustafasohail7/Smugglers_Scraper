@extends('layouts.app')

@section('content')
<style type="text/css">
     .input-date {
  border: 0px solid #ccc;
  display: flex;
  widtH: 110px;
  position: relative;
  transition: 0.15s ease-in-out;
      padding: 0px 0px 0px 0px;
      border-top: 1px solid #ccc !important;
      border-bottom: 1px solid #ccc !important;
      height: 35px;

}
 
 .input-date:after {
  content: "/";
  position: absolute;
  color: #ccc;
  width: 3px;
  height: 22px;
  top: 50%;
  lefT: 35%;
  transform: translate(-50%, -50%);
}
 .input-date input {
  padding: 0px;
  width: 55px;
  text-transform: uppercase;
  display: block;
  border: none;
  outline: 0;
  background: none;
}
.input-date input:focus{
    background: none !important;
  outline: none !important;
  border: none !important;
  padding: 0px !important;
   box-shadow: none !important;
}
.input-date input:active{
    background: none !important;
  outline: none !important;
  border: none !important;
  padding: 0px !important;
   box-shadow: none !important;
}
.cvv input {
  width: 100%;
  padding: 5px;
  text-align: right;
  background: none;
  outline: 0;
  border: 0px solid #ccc;
/*  border:none;*/
border-radius: 0px 7px 7px 0px;
border-top: 1px solid #ccc !important;
      border-bottom: 1px solid #ccc !important;
      border-right: 1px solid #ccc !important;
}
.cvv input:focus{
    background: none !important;
  outline: none !important;
  border: 0px solid #ccc !important;
  padding: 5px !important;
   box-shadow: none !important;
   border-radius: 0px 7px 7px 0px;
border-top: 1px solid #ccc !important;
      border-bottom: 1px solid #ccc !important;
      border-right: 1px solid #ccc !important;
      border-left: px solid !important;
}
.cvv input:active{
    background: none !important;
  outline: none !important;
  border: 0px solid #ccc !important;
  padding: 5px !important;
   box-shadow: none !important;
   border-radius: 0px 7px 7px 0px;
border-top: 1px solid #ccc !important;
      border-bottom: 1px solid #ccc !important;
      border-right: 1px solid #ccc !important;
      border-left: px solid !important;
}
.cardnum input{
width: 100%;
  padding: 5px;
  background: none;
  outline: 0;
  border: 1px solid #ccc;
  border-radius: 7px 0px 0px 7px;
      border-right: 0px solid !important;
}
.cardnum input:focus{
    background: none !important;
  outline: none !important;
  border: 1px solid #ccc !important;
  padding: 5px !important;
   box-shadow: none !important;
   border-right: 0px solid !important;
}
.cardnum input:active{
    background: none !important;
  outline: none !important;
  border: 1px solid #ccc !important;
  padding: 5px !important;
   box-shadow: none !important;
   border-right: 0px solid !important;
}

.cardnum{
        padding: 0px 0px 0px 12px;
}
.cvv{
        padding: 0px 0px 0px 0px;
}
.input{
    background: none;
  outline: none;
  border: 1px solid #ccc !important;
  padding: 5px !important;
}
.input:focus{
    background: none !important;
  outline: none !important;
  border: 1px solid #ccc !important;
  padding: 5px !important;
   box-shadow: none !important;
}
.input:active{
    background: none !important;
  outline: none !important;
  border: 1px solid #ccc !important;
  padding: 5px !important;
   box-shadow: none !important;
}
.headingcard{
    text-align: center;
    margin: 0px 0px 0px 35px;
    font-size: 20px;
    font-weight: bold;
    font-family: inherit;
}
.cardwarning{
        margin: 0px 15px 0px 0px;
    font-size: 14px;
    text-align: right;
}
.invalid-feedback {
     display: block;
    }
 .terms_box{
    background: #e9e6e6;
    /* color: beige; */
    font-size: 16px;
    padding: 10px;
    border-radius: 10px;
    height: 150px;
    overflow-y: auto;
}
.terms_box:hover{
background: #f8fafe;
}
.btn-custom{
    background: grey !important;

}
</style>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header">{{ __('Register') }}</div>

                <div class="card-body">
                    <form id="payment-form" method="POST" action="{{ url('registerstore') }}">
                        @csrf

                        <div class="row mb-3">

                             <label for="title" class="col-md-2 col-form-label text-md-end">Title</label>

                            <div class="col-md-10">
                                 <select class="form-control" id="title" name="title">
                                    <option value="Dr">Dr</option>
                                    <option value="Mr">Mr</option>
                                    <option value="Mrs">Mrs</option>
                                </select>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="fname" class="col-md-2 col-form-label text-md-end">First Name</label>

                            <div class="col-md-10">
                                <input name="fname" type="text" required class="form-control @error('fname') is-invalid @enderror" id="fname" placeholder="First Name">
                                @error('fname')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="lname" class="col-md-2 col-form-label text-md-end">Last Name</label>

                            <div class="col-md-10">
                                 <input name="lname" type="text" required class="form-control @error('lname') is-invalid @enderror" id="lname" placeholder="Last Name">
                                @error('lname')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="email" class="col-md-2 col-form-label text-md-end">Email</label>

                            <div class="col-md-10">
                                <input name="email" type="email" required class="form-control @error('email') is-invalid @enderror" id="email" placeholder="Email">
                                @error('email')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        

                        <div class="row mb-3">
                            <label for="password" class="col-md-2 col-form-label text-md-end">{{ __('Password') }}</label>

                            <div class="col-md-10" style="position:relative;">
                                <p style="position: absolute;
    right: 20px;
    font-size: 14px;
    color: orange;
    font-weight: bold;bottom: -15px;">The password must be atleast 8 characters.</p>
                                <input id="password" type="password" class="input form-control @error('password') is-invalid @enderror" name="password" minlength="6" required autocomplete="new-password" placeholder="Password">

                                @error('password')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="password-confirm" class="col-md-2 col-form-label text-md-end">{{ __('Confirm Password') }}</label>

                            <div class="col-md-10">
                                <input id="password-confirm" type="password" class="input form-control" name="password_confirmation" required autocomplete="new-password" placeholder="Confrim Password">
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="phone" class="col-md-2 col-form-label text-md-end">Phone</label>

                            <div class="col-md-10">
                                <input id="phone" type="tel" class="form-control @error('phone') is-invalid @enderror" name="phone" placeholder="Phone" >
                                @error('phone')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="qualification" class="col-md-2 col-form-label text-md-end">Qualification</label>

                            <div class="col-md-10">
                                <input id="qualification" type="tel" class="form-control @error('qualification') is-invalid @enderror" name="qualification" placeholder="Qualification">
                                @error('qualification')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="practicename" class="col-md-2 col-form-label text-md-end">Practice Name</label>

                            <div class="col-md-10">
                                <input id="practicename" type="tel" class="form-control @error('practicename') is-invalid @enderror" name="practicename" placeholder="Practice Name">
                                @error('practicename')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                         <div class="row mb-3">
                            <label for="practicename" class="col-md-2 col-form-label text-md-end">EULA</label>

                            <div class="col-md-10">
                                <div class="terms_box">{!! $eula->text !!}</div>
                            </div>
                        </div>

                        

                        <div class="row">
                            <div class="col-md-10">
                                <input id="roles" type="hidden" class="form-control" name="roles" value="2">
                            </div>
                        </div>

<div class="row mb-3">
            <div class="col-md-10 offset-md-4">
    <div class="form-check">
  <input class="form-check-input" type="checkbox" id="privacy_policy" name="privacy_policy">
  <label class="form-check-label" for="privacy_policy">I have read and accept the terms above</label>
</div>

@error('privacy_policy')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>The terms must be accepted.</strong>
                                    </span>
                                @enderror
</div>
</div>

                        <div class="row mb-0">
                            <div class="col-md-10 offset-md-4">
                                <button type="submit" class="btn btn-primary btnsubmit btn-custom" disabled>
                                    {{ __('Register') }}
                                </button>
                                <a href="{{ route('login') }}">{{ __('Login Now') }}</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    $(document).on('change','#privacy_policy',function(){
        if($(this).is(':checked')){
            $('.btnsubmit').removeClass('btn-custom')
            $('.btnsubmit').removeAttr('disabled')
        }
        else{
            $('.btnsubmit').addClass('btn-custom')
            $('.btnsubmit').attr('disabled','disabled')
        }
    })
</script>
@endsection
