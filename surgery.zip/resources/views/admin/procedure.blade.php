@extends('layouts.app2')

@section('content')
<style type="text/css">
    .list-ticked li{
        background: #e5e3e3;
    border-radius: 5px;
    padding: 0px 0px 0px 5px;
    position: relative;
    }
  .mdi-subdirectory-arrow-left{
        position: absolute;
    top: 40px;
    left: -22px;
    font-size: 20px;
    color: blue;
    cursor: pointer;
  }
  .mdi-subdirectory-arrow-right{
        position: absolute;
    top: 10px;
    right: -22px;
    font-size: 20px;
    color: blue;
    cursor: pointer;
  }
  .searchitem{
    background: wheat;
    list-style: none;
    position: absolute;
    width: 94%;
    padding: 0;
    display: none;
  }
  .searchitem li{
    border-bottom: 1px solid grey dashed;
  }
  .searchitem li {
    border-bottom: 1px solid grey;
    padding: 5px;
    cursor: pointer;
    }
    .searchitem li:hover {
    background: white;
}
</style>
<!-- Scripts -->
    <!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css"> -->
        
        <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.1.3/js/bootstrap.bundle.min.js"></script> -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.css" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
<div class="content-wrapper">
            <div class="page-header">
              <h3 class="page-title">
                <span class="page-title-icon bg-gradient-primary text-white me-2">
                  <i class="mdi mdi-clipboard-text"></i>
                </span> {{ $single_proc->procedure_name }} ({{ $single_proc->procedure_code }})  created by ({{ $single_proc->fname }} {{ $single_proc->lname }}) @if($single_proc->status == 0)
                        <b style="color:red">Pending</b>
                        @else
                        <b style="color:green">Done</b>
                        @endif
                <span class="alternate_name" style="font-size: 12px;
    text-decoration: underline;
    cursor: pointer;
    color: #809580;">View Alternate Name</span>
    <span class="add_alternate_name" style="font-size: 12px;
    text-decoration: underline;
    cursor: pointer;
    color: #809580;">Add Alternate Name</span>      
              </h3>
            </div>

            <form method="POST" class="mb-3" action="{{ url('/admin_procedure_status/' .  $single_proc->id) }}">
                        @csrf
                    <input type="hidden" name="webpageid" value="{{ $single_proc->id }}">
                    <input type="text" name="proc_name" value="{{ $single_proc->procedure_name }}">
                    <select name="statusget" id="statusget">
                        <option @php if($single_proc->status == 1) { echo "selected"; } @endphp value="1">Done</option>
                        <option @php if($single_proc->status == 0) { echo "selected"; } @endphp value="0">Pending</option>
                    </select>
                    <button type="submit" class="btn btn-gradient-success btn-sm">Update</button>
                    </form>
            @include('admin.inc.notify')
            

            <div class="row">
              <div class="col-3 mb-2">
                      <button type="button" class="btn btn-gradient-secondary" id="addnewbenefit_modalopen" data-name="ben">Add Benefit</button>
                    </div>
              <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                   
                   <div class="row">
                    <div class="col-6">
                        <h5>Procedure Benefit</h5>
                        <ul class="list-ticked">
                        @foreach($single_proc_benfit as $single_proc_benfit_get )
                      <li><b>{{ $single_proc_benfit_get->code }}</b> - {{ $single_proc_benfit_get->benefit_name }} - {{ $single_proc_benfit_get->statistics }} <p>{{ $single_proc_benfit_get->detail }}</p>
                        @if($single_proc_benfit_get->status == 0)
                        <p>
                        <b style="color:red">Pending</b> -- Create & view by only <b>{{ $single_proc_benfit_get->fname }} {{ $single_proc_benfit_get->lname }}</b>
                        <form method="POST" class="mb-3" action="{{ url('/admin_benfit_status/' .  $single_proc_benfit_get->code) }}">
                        @csrf
                    <input type="hidden" name="benfitcode" value="{{ $single_proc_benfit_get->code }}">
                    <select name="statusget_ben" class="statusget_ben">
                        <option @php if($single_proc_benfit_get->status == 1) { echo "selected"; } @endphp value="1">Done</option>
                        <option @php if($single_proc_benfit_get->status == 0) { echo "selected"; } @endphp value="0">Pending</option>
                    </select>
                    </form>
                        </p>
                        @else
                        <p>
                        <b style="color:green">Done</b> -- Created by <b>{{ $single_proc_benfit_get->fname }} {{ $single_proc_benfit_get->lname }}</b>
                        </p>
                        @endif
                        @if($single_proc_benfit_get->status == 1)
                        <i class="mdi mdi-subdirectory-arrow-right moverightside" data-id="{{ $single_proc_benfit_get->id }}" data-name="ben" data-code="{{ $single_proc_benfit_get->code }}" data-procid="{{ $single_proc->id }}"></i>
                        @endif
                      </li>
                        @endforeach
                      </ul>
                    </div>

                    <div class="col-6">
                        <h5>All Benefit</h5>
                        <ul class="list-ticked">
                        @foreach($single_proc_all_benfit as $single_proc_all_benfit_get )
                      <li><b>{{ $single_proc_all_benfit_get->code }}</b> - {{ $single_proc_all_benfit_get->benefit_name }} - {{ $single_proc_all_benfit_get->statistics }} <p>{{ $single_proc_all_benfit_get->detail }}</p>
                        @if($single_proc_all_benfit_get->status == 0)
                        <p>
                        <b style="color:red">Pending</b> -- Create & view by only <b>{{ $single_proc_all_benfit_get->fname }} {{ $single_proc_all_benfit_get->lname }}</b>
                        </p>
                        @else
                        <p>
                        <b style="color:green">Done</b> -- Created by <b>{{ $single_proc_all_benfit_get->fname }} {{ $single_proc_all_benfit_get->lname }}</b>
                        </p>
                        @endif
                        <i class="mdi mdi-subdirectory-arrow-left moveleftside" data-name="ben" data-code="{{ $single_proc_all_benfit_get->code }}" data-procid="{{ $single_proc->id }}"></i>
                      </li>
                        @endforeach
                      </ul>
                    </div>
                   </div>

                  </div>
                </div>
              </div>
            </div>

            <div class="row">
              <div class="col-3 mb-2">
                      <button type="button" class="btn btn-gradient-secondary" id="addnewbenefit_modalopen" data-name="risk">Add Risk</button>
                    </div>
              <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                   
                   <div class="row">
                    <div class="col-6">
                      <h5>Procedure Risk</h5>
                      <ul class="list-ticked">
                      @foreach($single_proc_risk as $single_proc_risk_get )
                      <li><b>{{ $single_proc_risk_get->code }}</b> - {{ $single_proc_risk_get->risk_name }} - {{ $single_proc_risk_get->statistics }} <p>{{ $single_proc_risk_get->detail }}</p>
                        @if($single_proc_risk_get->status == 0)
                        <p>
                        <b style="color:red">Pending</b> -- Create & view by only <b>{{ $single_proc_risk_get->fname }} {{ $single_proc_risk_get->lname }}</b>
                        <form method="POST" class="mb-3" action="{{ url('/admin_risk_status/' .  $single_proc_risk_get->code) }}">
                        @csrf
                    <input type="hidden" name="riskcode" value="{{ $single_proc_risk_get->code }}">
                    <select name="statusget_risk" class="statusget_risk">
                        <option @php if($single_proc_risk_get->status == 1) { echo "selected"; } @endphp value="1">Done</option>
                        <option @php if($single_proc_risk_get->status == 0) { echo "selected"; } @endphp value="0">Pending</option>
                    </select>
                    </form>
                        </p>
                        @else
                        <p>
                        <b style="color:green">Done</b> -- Created by <b>{{ $single_proc_risk_get->fname }} {{ $single_proc_risk_get->lname }}</b>
                        </p>
                        @endif
                        @if($single_proc_risk_get->status == 1)
                        <i class="mdi mdi-subdirectory-arrow-right moverightside" data-id="{{ $single_proc_risk_get->id }}" data-name="risk" data-code="{{ $single_proc_risk_get->code }}" data-procid="{{ $single_proc->id }}"></i>
                        @endif
                      </li>
                      @endforeach
                      </ul>
                    </div>

                    <div class="col-6">
                      <h5>All Risk</h5>
                      <ul class="list-ticked">
                      @foreach($single_proc_all_risk as $single_proc_all_risk_get )
                      <li><b>{{ $single_proc_all_risk_get->code }}</b> - {{ $single_proc_all_risk_get->risk_name }} - {{ $single_proc_all_risk_get->statistics }} <p>{{ $single_proc_all_risk_get->detail }}</p>
                        @if($single_proc_all_risk_get->status == 0)
                        <p>
                        <b style="color:red">Pending</b> -- Create & view by only <b>{{ $single_proc_all_risk_get->fname }} {{ $single_proc_all_risk_get->lname }}</b>
                        </p>
                        @else
                        <p>
                        <b style="color:green">Done</b> -- Created by <b>{{ $single_proc_all_risk_get->fname }} {{ $single_proc_all_risk_get->lname }}</b>
                        </p>
                        @endif
                        <i class="mdi mdi-subdirectory-arrow-left moveleftside" data-name="risk" data-code="{{ $single_proc_all_risk_get->code }}" data-procid="{{ $single_proc->id }}"></i>
                      </li>
                      @endforeach

                      </ul>
                    </div>
                   </div>

                  </div>
                </div>
              </div>
            </div>
            
            
          </div>

<!-- new benefit modal -->
<div class="modal fade zoomIn" id="newBenefit_Modal" tabindex="-1" data-bs-keyboard="false" data-bs-backdrop="static" aria-hidden="true" role="dialog">
          <div class="modal-dialog modal-dialog-centered modal-md">
            <div class="modal-content">
                <div class="modal-header">
        <h4 class="modal-title">Add New Procedure</h4>
      </div>
      <form method="POST" action="{{ url('submit_new_benefitrisk_admin') }}" id="new_benefitrisk_form">
        @csrf
                <div class="modal-body" style="">
                <div class="row">
                            <div class="col-md-12">
                                <label class="form-label">Name</label>
                                <input name="new_benefit_status_input" type="hidden" class="new_benefit_status_input form-control input">
                                <input name="proc_id" type="hidden" class="proc_id form-control input" value="{{ $single_proc->id }}">
                                <input name="new_benefit_name_input" required type="text" class="new_benefit_name_input form-control input" id="new_benefit_name_input">
                                <ul class="searchitem">
                                    
                                </ul>
                            </div>
                            <div class="col-md-12 mt-2">
                                <label class="form-label">Statistics</label>
                                <input name="new_benefit_statistics_input" type="text" class="new_benefit_statistics_input form-control input">
                            </div>
                            <div class="col-md-12 mt-2">
                                <label class="form-label">Detail</label>
                                <input name="new_benefit_detail_input" required type="text" class="new_benefit_detail_input form-control input">
                            </div>
                            </div>

                </div>
                 <div class="modal-footer">
        <button type="button" class="btn btn-gradient-danger btn-fw btn_close_modal" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-gradient-success btn-fw add_newben_submit_btn">SUBMIT</button>
        <button type="button" class="btn btn-gradient-success btn-fw add_newben_submit_btn_loader" style="display:none;">Waiting...</button>
      </div>
  </form>
                </div>
            </div>
          </div>
<!-- new benefit modal -->

<!-- alternate name -->
<div class="modal fade zoomIn" id="alternate_name_Modal" tabindex="-1" data-bs-keyboard="false" data-bs-backdrop="static" aria-hidden="true" role="dialog">
          <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-header">
        <h4 class="modal-title">Alternate Procedure Name</h4>
      </div>
                <div class="modal-body" style="">
                <div class="row table-responsive">
                             <div class="col-12">
                      <table class="table table-striped">
                      <thead>
                        <tr>
                          <th> # </th>
                          <th> Procedure Code </th>
                          <th> Procedure Name </th>
                          <th> Procedure Alternate Name </th>
                          <th> User </th>
                          <th> Status </th>
                          <th> Created_at </th>
                        </tr>
                      </thead>
                      <tbody class="fetchprocedure">

                       
                        
                        
                      </tbody>
                    </table>
                    </div>
                            </div>

                </div>
                 <div class="modal-footer">
        <button type="button" class="btn btn-gradient-danger btn-fw btn_close_modal" data-dismiss="modal">Close</button>
      </div>
  </form>
                </div>
            </div>
          </div>
<!-- alternate name -->

<!-- alternate name -->
<div class="modal fade zoomIn" id="add_alternate_name_Modal" tabindex="-1" data-bs-keyboard="false" data-bs-backdrop="static" aria-hidden="true" role="dialog">
          <div class="modal-dialog modal-dialog-centered modal-md">
            <div class="modal-content">
                <div class="modal-header">
        <h4 class="modal-title">Add Alternate Procedure Name</h4>
      </div>
      <form method="POST" action="{{ url('submit_add_altername_admin') }}" id="submit_add_altername_admin">
        @csrf
                <div class="modal-body" style="">
                <input type="hidden" name="proc_id" id="proc_id" class="form-control" value="{{ $single_proc->id }}">
                <input type="text" name="proc_name" id="proc_name" class="form-control" placeholder="Procedure Name" required>
                </div>
                 <div class="modal-footer">
        <button type="submit" class="btn btn-gradient-primary btn-fw">Submit</button>
        <button type="button" class="btn btn-gradient-danger btn-fw btn_close_modal" data-dismiss="modal">Close</button>
      </div>
      </form>
                </div>
            </div>
          </div>
<!-- alternate name -->
<script type="text/javascript">
function fetchproc(searchval,statusval){
    // alert(searchval)
  var path_get_procedure = "{{ url('fetch_admin_procedure_alternate_single') }}";
    $.ajax({
            url: path_get_procedure,
            type: 'GET',
            dataType: "json",
            data: {
               searchval: searchval,
               statusval: statusval
            },
            success: function( data ) { 
              console.log(data)
              var fetchprocedure = '';
var a  = 0;
for (var i = 0; i < data.procedure.length; i++) {
a = i + 1;
fetchprocedure +='<tr>'+
                          '<td>'+a+'</td>'+
                          '<td><a href="{{ url("/procedure/") }}/'+data.procedure[i].procedure_code+'">'+data.procedure[i].procedure_code+'</a></td>'+
                          '<td>'+data.procedure[i].procedure_name_old+'</td>'+
                          '<td>'+data.procedure[i].procedure_name+'</td>'+
                          '<td>'+data.procedure[i].fname+' '+data.procedure[i].lname+'</td>';
                          if(data.procedure[i].status == 0){
                          fetchprocedure +='<td><label class="badge badge-gradient-danger">Pending</label></td>';
                          }
                          else{
                          fetchprocedure +='<td><label class="badge badge-gradient-success">Done</label> </td>';
                          }
                          fetchprocedure +='<td>'+data.procedure[i].created_at+'</td>'+
                          '<tr>';
            }
            $('.fetchprocedure').html(fetchprocedure)
            }
          });
  }
  fetchproc('{{ $single_proc->procedure_code }}','');
$(document).on('click','.alternate_name',function(event){
$('#alternate_name_Modal').modal('show')
})
$(document).on('click','.add_alternate_name',function(event){
$('#add_alternate_name_Modal').modal('show')
})
$(document).on('change','.statusget_ben',function(event){
this.form.submit();
})
$(document).on('change','.statusget_risk',function(event){
this.form.submit();
})
$(document).on('click','.moverightside',function(event){
var id = $(this).attr('data-id');
var name = $(this).attr('data-name');
var code = $(this).attr('data-code');
var procid = $(this).attr('data-procid');
 // Prompt the user for their password
    var adminPassword = prompt('Enter admin password:');

    if (adminPassword === null) {
        // User clicked Cancel
        return;
    }

// Continue with form submission if the admin password matches
    if (checkAdminPassword(adminPassword)) {
     
let formData = new FormData();
formData.append('id',id);
formData.append('name',name);
formData.append('code',code);
formData.append('procid',procid);
        $.ajaxSetup({
          headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
      });
         $.ajax({
        // headers: {
        //     'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')
        // },
        url: "{{ url('admin_benrisk_moverightside') }}",
        type: "POST",
        data: formData,
         processData: false,
    contentType: false,
    cache: false,
        dataType: "json",
         success: function(data) {
          console.log(data)
          location.reload();
          }
        });
         } else {
        // Show an alert if the passwords do not match
        alert('Incorrect admin password!');
    }
});



$(document).on('click','.moveleftside',function(event){
var name = $(this).attr('data-name');
var code = $(this).attr('data-code');
var procid = $(this).attr('data-procid');

// Prompt the user for their password
    var adminPassword = prompt('Enter admin password:');

    if (adminPassword === null) {
        // User clicked Cancel
        return;
    }

// Continue with form submission if the admin password matches
    if (checkAdminPassword(adminPassword)) {
let formData = new FormData();
formData.append('name',name);
formData.append('code',code);
formData.append('procid',procid);
        $.ajaxSetup({
          headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
      });
         $.ajax({
        // headers: {
        //     'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')
        // },
        url: "{{ url('admin_benrisk_moveleftside') }}",
        type: "POST",
        data: formData,
         processData: false,
    contentType: false,
    cache: false,
        dataType: "json",
         success: function(data) {
          console.log(data)
          location.reload();
          }
        });
         } else {
        // Show an alert if the passwords do not match
        alert('Incorrect admin password!');
    }
});
$(document).on('click','#addnewbenefit_modalopen',function(event){
  var name = $(this).attr('data-name');
  window.name = name;
  if(name == 'ben'){
  $('.modal-title').text('Add New Benefit')
  }
  else{
  $('.modal-title').text('Add New Risk')
  }
  $('.new_benefit_status_input').val(name)
  $('.new_benefit_name_input').attr('data-name',name)
  $('.new_benefit_name_input').val('')
  $('.searchitem').hide();
  $('#newBenefit_Modal').modal('show')
})

 $(document).on('click','.btn_close_modal',function(){
        $('#newBenefit_Modal').modal('hide');
        $('#alternate_name_Modal').modal('hide');
        $('#add_alternate_name_Modal').modal('hide');
    });

 $('#new_benefitrisk_form').submit(function(e) {
        e.preventDefault();
        // Prompt the user for their password
    var adminPassword = prompt('Enter admin password:');

    if (adminPassword === null) {
        // User clicked Cancel
        return;
    }

// Continue with form submission if the admin password matches
    if (checkAdminPassword(adminPassword)) {
        $('.add_newben_submit_btn').hide();
        $('.add_newben_submit_btn_loader').show();
        let formData = new FormData(this);
        $.ajaxSetup({
          headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
      });
         $.ajax({
        // headers: {
        //     'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')
        // },
        url: $(this).attr('action'),
        type: $(this).attr('method'),
        data: formData,
         processData: false,
    contentType: false,
    cache: false,
        dataType: "json",
         success: function(data) {
            console.log(data);
            
        $('.add_newben_submit_btn').show();
        $('.add_newben_submit_btn_loader').hide();
        $('#newBenefit_Modal').modal('hide')
        // fetchproc($('#search_proc').val(),$('#search_status').val());
        location.reload()
        },
        error: function(err) {
            console.log(err)
        }
    });
         } else {
        // Show an alert if the passwords do not match
        alert('Incorrect admin password!');
    }
    });


function checkAdminPassword(password) {
    return password === 'admin@123';
}

var path = "{{ url('benrisk_autocomplete') }}";
    // function autocomp(){
    // $( "#new_benefit_name_input" ).each(function(){
    $("#new_benefit_name_input").autocomplete({
         autoFocus: true,
        source: function( request, response ) {
          $.ajax({
            url: path,
            type: 'GET',
            dataType: "json",
            data: {
               search: request.term,
               attr: window.name
            },
            success: function( data ) {
                console.log(data)
                $('.searchitem').show();
                if (data.length === 0) {
 var result = [
            {
                label: 'Not Found', 
                value: response.term
            }
        ];
        response(result);
        var inhtml = '<li data-click="0">Not Found</li>';
        $('.searchitem').html(inhtml)
}
else{
    $('.searchitem').show();
    var inhtml = '';
    for (var i = 0; i < data.length; i++) {
        if(window.name == 'ben'){
    inhtml += '<li data-click="1" data-name="'+data[i].benefit_name+'" data-statistics="'+data[i].statistics+'" data-detail="'+data[i].detail+'">('+data[i].code+') '+data[i].benefit_name+'</li>';
        }
        else{
    inhtml += '<li data-click="1" data-name="'+data[i].risk_name+'" data-statistics="'+data[i].statistics+'" data-detail="'+data[i].detail+'">('+data[i].code+') '+data[i].risk_name+'</li>';
        }
    }
    $('.searchitem').html(inhtml)
               response( data );
}

            }
          });
        },
        select: function (event, ui) {
            // alert('ffffffff')
            if(ui.item.label == 'Not Found'){

            }
            else{
           $(this).val(ui.item.label);
           $(this).attr('data-id',ui.item.id);
       }
           console.log(ui.item); 
           return false;
        }
      });
  // });
// }
// autocomp();

    $(document).on('click','.searchitem li',function(){
        var name = $(this).attr('data-name')
        var click = $(this).attr('data-click')
        var statistics = $(this).attr('data-statistics')
        var detail = $(this).attr('data-detail')
        $('.searchitem').hide();
        if(statistics == 'null'){
            statistics = '';
        }
        if(click != 0){
        $('.new_benefit_statistics_input').val(statistics)
        $('.new_benefit_detail_input').val(detail)
        $('.new_benefit_name_input').val(name)
        }
    });
</script>
@endsection