@extends('layouts.app2')

@section('content')
<script src="https://cdn.ckeditor.com/ckeditor5/39.0.1/classic/ckeditor.js"></script>
<style>
.ck-editor__editable_inline {
    min-height: 300px;
}
</style>
<div class="content-wrapper">
            <div class="page-header">
              <h3 class="page-title">
                <span class="page-title-icon bg-gradient-primary text-white me-2">
                  <i class="mdi mdi-settings"></i>
                </span> Website Setting
              </h3>
            </div>
            @include('admin.inc.notify')
            <div class="row justify-content-center">
              
              <div class="col-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <form class="forms-sample" action="{{ url('update_pd_agree') }}" method="POST">
                    	@csrf
                      <div class="form-group">
                        <label for="title" class="form-label">Medicolegal Patient Agreement</label>
                        <input type="hidden" name="id" value="{{ $pd_agree->id }}">
                            <textarea class="form-control" name="mp_agree" style="height: 100px;">{{ $pd_agree->mp_agree }}</textarea>
                      </div>

                      <div class="form-group">
                        <label for="title" class="form-label">Medicolegal Doctor Agreement</label>
                            <textarea class="form-control" name="md_agree" style="height: 100px;">{{ $pd_agree->md_agree }}</textarea>
                      </div>


                      
                      <button type="submit" class="btn btn-gradient-primary me-2">Update</button>
                    </form>


                    <form class="forms-sample mt-5" action="{{ url('update_eula') }}" method="POST">
                        @csrf
                      <div class="form-group">
                        <label for="title" class="form-label">EULA</label>
                         <input type="hidden" name="id" value="{{ $eula->id }}">
                            <textarea id="content" name="content">{{ $eula->text }}</textarea>
                      </div>


                      
                      <button type="submit" class="btn btn-gradient-primary me-2">Update</button>
                    </form>
                  </div>
                </div>
              </div>

            </div>
            
            
          </div>
<script type="text/javascript">
          ClassicEditor
        // .create( document.querySelector( '#webpagecontent' ) )
     .create( document.querySelector( '#content' ),{
                ckfinder: {
                    uploadUrl: '{{url('image.upload').'?_token='.csrf_token()}}',
        }
            })
        .then( editor => {
        editor.ui.view.editable.element.style.height = '300px';
    } )
        .catch( error => {
            console.error( error );
        } );
</script>
@endsection