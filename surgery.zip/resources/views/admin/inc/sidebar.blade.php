<nav class="sidebar sidebar-offcanvas" id="sidebar">
  <ul class="nav">
    <li class="nav-item">
      <a class="nav-link" href="{{ url('/admin') }}">
        <span class="menu-title">Dashboard</span>
        <i class="mdi mdi-home menu-icon"></i>
      </a>
    </li>

    <li class="nav-item">
      <a class="nav-link" data-bs-toggle="collapse" href="#procedure" aria-expanded="false" aria-controls="ui-basic">
        <span class="menu-title">Procedures</span>
        <i class="menu-arrow"></i>
        <i class="mdi mdi-clipboard-text menu-icon"></i>
      </a>
      <div class="collapse" id="procedure">
        <ul class="nav flex-column sub-menu">
          <li class="nav-item"> <a class="nav-link" href="{{ url('/allprocedure') }}">All Procedures</a></li>
          <li class="nav-item"> <a class="nav-link" href="{{ url('/alternate_procedure') }}">Alternate Procedures</a></li>
          <li class="nav-item"> <a class="nav-link" href="{{ url('/allbenefits') }}">All Benefits</a></li>
          <li class="nav-item"> <a class="nav-link" href="{{ url('/allrisks') }}">All Risks</a></li>
          <li class="nav-item"> <a class="nav-link" href="{{ url('/edited_benrisk') }}">Edited Benefit & Risk</a></li>
          <li class="nav-item"> <a class="nav-link" href="{{ url('/procedure/P-001') }}">Generic Consent</a></li>
        </ul>
      </div>
    </li>



    <li class="nav-item">
      <a class="nav-link" data-bs-toggle="collapse" href="#user" aria-expanded="false" aria-controls="ui-basic">
        <span class="menu-title">Users</span>
        <i class="menu-arrow"></i>
        <i class="mdi mdi-account-search menu-icon"></i>
      </a>
      <div class="collapse" id="user">
        <ul class="nav flex-column sub-menu">
          <li class="nav-item"> <a class="nav-link" href="{{ url('/adduser') }}">Add User</a></li>
          <li class="nav-item"> <a class="nav-link" href="{{ url('/allusers') }}">All Users</a></li>
        </ul>
      </div>
    </li>

    

    
    
    
  </ul>
</nav>