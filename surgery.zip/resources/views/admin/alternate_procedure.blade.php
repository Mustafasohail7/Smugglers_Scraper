@extends('layouts.app2')

@section('content')
<div class="content-wrapper">
            <div class="page-header">
              <h3 class="page-title">
                <span class="page-title-icon bg-gradient-primary text-white me-2">
                  <i class="mdi mdi-clipboard-text"></i>
                </span> Alternate Procedures
              </h3>
            </div>
            @include('admin.inc.notify')
                          <div class="row">
                            <div class="col-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body row">
                      <div class="col-5 form-group">
                      <div class="input-group">
                        <div class="input-group-prepend">
                          <span class="input-group-text"><i class="mdi mdi-magnify"></i></span>
                        </div>
                        <input type="text" id="search_proc" name="search_proc" class="form-control" placeholder="Search Procedure">
                      </div>
                    </div>
                    <div class="col-4 form-group">
                      <select class="form-control form-control-sm" id="search_status" name="search_status">
                        <option value="" selected>All</option>
                        <option value="1">Done</option>
                        <option value="0">Pending</option>
                      </select>
                    </div>

                    <div class="col-2 p-0">
                      <a href="{{ url('allprocedure') }}"><button type="button" class="btn btn-gradient-secondary">Add Procedure</button></a>
                    </div>

                    <div class="col-12">
                      <table class="table table-striped">
                      <thead>
                        <tr>
                          <th> # </th>
                          <th> Procedure Code </th>
                          <th> Procedure Name </th>
                          <th> Procedure Alternate Name </th>
                          <th> User </th>
                          <th> Status </th>
                          <th> Created_at </th>
                          <th> Action </th>
                        </tr>
                      </thead>
                      <tbody class="fetchprocedure">

                       
                        
                        
                      </tbody>
                    </table>
                    </div>
                  </div>
                </div>
              </div>
                        </div>
            
          </div>

<!-- new procedure modal -->
<div class="modal fade zoomIn" id="newProc_Modal" tabindex="-1" data-bs-keyboard="false" data-bs-backdrop="static" aria-hidden="true" role="dialog">
          <div class="modal-dialog modal-dialog-centered modal-md">
            <div class="modal-content">
                <div class="modal-header">
        <h4 class="modal-title">Add New Procedure</h4>
      </div>
      <form method="POST" action="{{ url('submit_new_procedure_admin') }}" id="new_procedure_form">
        @csrf
                <div class="modal-body" style="">
                <div class="row">
                            <div class="col-md-12">
                                <label for="new_procedure_input" class="form-label">Type New Procedure</label>
                                <input name="new_procedure_input" id="new_procedure_input" type="text" required class="form-control input">
                            </div>
                            </div>

                </div>
                 <div class="modal-footer">
        <button type="button" class="btn btn-gradient-danger btn-fw btn_close_modal" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-gradient-success btn-fw add_newproc_submit_btn">SUBMIT</button>
        <button type="button" class="btn btn-gradient-success btn-fw add_newproc_submit_btn_loader" style="display:none;">Waiting...</button>
      </div>
  </form>
                </div>
            </div>
          </div>
<!-- new procedure modal -->
<script type="text/javascript">
  $(document).on('click','.btn_close_modal',function(){
        $('#newProc_Modal').modal('hide');
    });
  function fetchproc(searchval,statusval){
  var path_get_procedure = "{{ url('fetch_admin_procedure_alternate') }}";
    $.ajax({
            url: path_get_procedure,
            type: 'GET',
            dataType: "json",
            data: {
               searchval: searchval,
               statusval: statusval
            },
            success: function( data ) { 
              console.log(data)
              var fetchprocedure = '';
var a  = 0;
for (var i = 0; i < data.procedure.length; i++) {
a = i + 1;
fetchprocedure +='<tr>'+
                          '<td>'+a+'</td>'+
                          '<td><a href="{{ url("/procedure/") }}/'+data.procedure[i].procedure_code+'">'+data.procedure[i].procedure_code+'</a></td>'+
                          '<td>'+data.procedure[i].procedure_name_old+'</td>'+
                          '<td>'+data.procedure[i].procedure_name+'</td>'+
                          '<td>'+data.procedure[i].fname+' '+data.procedure[i].lname+'</td>';
                          if(data.procedure[i].status == 0){
                          fetchprocedure +='<td><label class="badge badge-gradient-danger">Pending</label></td>';
                          }
                          else{
                          fetchprocedure +='<td><label class="badge badge-gradient-success">Done</label> </td>';
                          }
                          fetchprocedure +='<td>'+data.procedure[i].created_at+'</td>'+
                                            '<td><a href="javascript:void(0);" class="delete_alternate_proc" data-code="'+data.procedure[i].alternate_id+'">delete</a> <a href="javascript:void(0);" class="changestatus_alternate_proc" data-status="'+data.procedure[i].status+'" data-code="'+data.procedure[i].alternate_id+'">change status</a></td>'+
                          '<tr>';
            }
            $('.fetchprocedure').html(fetchprocedure)
            }
          });
  }

$(document).on('click','#addnewproc_modalopen',function(event){
  $('#newProc_Modal').modal('show')
})
$(document).on('keyup','#search_proc',function(event){
        var search_proc = $( this ).val();
        if(event.keyCode == 13) {
            if(search_proc == ''){
    fetchproc('',$('#search_status').val());
            }
            else{  
    fetchproc(search_proc,$('#search_status').val());
            }
        }
    });

$(document).on('change','#search_status',function(){
  var search_status = $( this ).val();
  // alert(search_status)
  if(search_status == '') {
    fetchproc($('#search_proc').val(),'');
  }
  else{

    fetchproc($('#search_proc').val(),search_status);
  }
})
    fetchproc($('#search_proc').val(),$('#search_status').val());

    $('#new_procedure_form').submit(function(e) {
        e.preventDefault();
        $('.add_newproc_submit_btn').hide();
        $('.add_newproc_submit_btn_loader').show();
        let formData = new FormData(this);
        $.ajaxSetup({
          headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
      });
         $.ajax({
        // headers: {
        //     'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')
        // },
        url: $(this).attr('action'),
        type: $(this).attr('method'),
        data: formData,
         processData: false,
    contentType: false,
    cache: false,
        dataType: "json",
         success: function(data) {
            console.log(data);
            
        $('.add_newproc_submit_btn').show();
        $('.add_newproc_submit_btn_loader').hide();
        $('#newProc_Modal').modal('hide')
        fetchproc($('#search_proc').val(),$('#search_status').val());
        },
        error: function(err) {
            console.log(err)
        }
    });
    });

    $(document).on('click','.delete_alternate_proc',function(){
    var code = $(this).attr('data-code');
    // alert(code)
    // Prompt the user for their password
    var adminPassword = prompt('Enter admin password:');

    if (adminPassword === null) {
        // User clicked Cancel
        return;
    }

// Continue with form submission if the admin password matches
    if (checkAdminPassword(adminPassword)) {
    var path_get_procedure = "{{ url('delete_alternate_proc') }}";
    $.ajax({
            url: path_get_procedure,
            type: 'GET',
            dataType: "json",
            data: {
               code: code
            },
            success: function( data ) { 
              console.log(data)
              location.reload(true)
              
            }
          });
     } else {
        // Show an alert if the passwords do not match
        alert('Incorrect admin password!');
    }
  })


$(document).on('click','.changestatus_alternate_proc',function(){
    var code = $(this).attr('data-code');
    var status = $(this).attr('data-status');
    if(status == 1){
      status = 0;
    }
    else{
      status = 1;
    }
    var path_get_procedure = "{{ url('changestatus_alternate_proc') }}";
    $.ajax({
            url: path_get_procedure,
            type: 'GET',
            dataType: "json",
            data: {
               code: code,
               status: status
            },
            success: function( data ) { 
              console.log(data)
              fetchproc($('#search_proc').val(),$('#search_status').val());
              
            }
          });
  })

function checkAdminPassword(password) {
    return password === 'admin@123';
}
</script>
@endsection