<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use App\Models\User;
use Illuminate\Foundation\Auth\RegistersUsers;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Mail;

class RegisterStoreController extends Controller
{
    
    public function __construct()
    {
        $this->middleware('guest');
    }


//     public function check()
//     {
//         $stripe = new \Stripe\StripeClient(env('STRIPE_SECRET'));
//        $plan = Plan::find(1);
//    $subscription =  $stripe->subscriptions->create([
//   'customer' => 'cus_OXfsMPrDEWfZBk',
//   'items' => [
//     ['price' => 'price_1NjA68F5ufWtnIxqUvzyKaMH'],
//   ],
// ]);
//         dd($subscription->items->data[0]->id);
//     }
   public function registerstore(Request $request){
$this->validate(request(), [
            'fname' => ['required'],
            'lname' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
            'password' => ['required', 'min:8', 'confirmed'],
            'roles' => ['required'],
            'privacy_policy' => ['accepted'],
        ]);
        // user db
        $user = User::create([
            'fname' => $request['fname'],
            'lname' => $request['lname'],
            'email' => $request['email'],
            'password' => Hash::make($request['password']),
            'roles' => $request['roles'],
            'phone' => $request['phone'],
            'qualifications' => $request['qualification'],
            'practice_name' => $request['practicename'],
            'title' => $request['title'],
        ]);
        $user->roles()->attach($request['roles']);

        auth()->login($user);
        session()->flash('message', 'Registration Successfully!');
        return redirect('/home');


   }

   
}
