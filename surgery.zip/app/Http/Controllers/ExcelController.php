<?php
namespace App\Http\Controllers;
// use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\Excel;
use App\Exports\ProcedureExport;
use App\Exports\BenefitExport;
use App\Exports\RiskExport;

class ExcelController extends Controller
{
    public function exportExcel()
    {
        return Excel::create('export.xlsx', function ($excel) {
            $excel->sheet(new ProcedureExport);
            $excel->sheet(new BenefitExport);
            $excel->sheet(new RiskExport);
        })->download('xlsx');
    }
}
