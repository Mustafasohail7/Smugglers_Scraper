<?php

namespace App\Http\Controllers;

use Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Models\User;
use App\Models\ProcedureList;
use App\Models\BenefitList;
use App\Models\RiskList;
use App\Models\Pd_Agree;
use App\Models\Eula;
use Illuminate\Validation\Rule;
use Carbon\Carbon;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;

class AdminWebSettingController extends Controller
{
     public function __construct()
    {
        $this->middleware('auth');
    }

    public function admin_websetting(){
        $pd_agree = Pd_Agree::orderBy('id', 'DESC')
            ->first();
            $eula = Eula::orderBy('id', 'DESC')
            ->first();

        return view('admin.admin_websetting', compact('pd_agree','eula'));
    }

    public function update_pd_agree(Request $request){
        $upd = Pd_Agree::findOrFail($request->id);
        $upd['mp_agree'] = $request->mp_agree;
        $upd['md_agree'] = $request->md_agree;
        $upd->update();
        
        session()->flash('message', 'Successfully updated the Patient & Doctor Agreement!');
        return redirect()->back();

    }

    public function update_eula(Request $request){
        $upd = eula::findOrFail($request->id);
        $upd['text'] = $request->content;
        $upd->update();
        
        session()->flash('message', 'Successfully updated the EULA Agreement!');
        return redirect()->back();

    }

}
