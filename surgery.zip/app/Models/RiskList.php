<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RiskList extends Model
{
    use HasFactory;
    protected $table = 'risk_list';
    protected $fillable = ['risk_name','code','statistics','detail','procedure_id','status','userid'];
}
