<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Procedure_Alternate extends Model
{
    use HasFactory;
    protected $table = 'procedure_alternate';
    protected $fillable = ['procedure_id','procedure_name','status','userid'];
}
