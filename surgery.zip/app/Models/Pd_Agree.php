<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Pd_Agree extends Model
{
    use HasFactory;
    protected $table = 'pd_agree';
    protected $fillable = ['mp_agree','md_agree'];
}
