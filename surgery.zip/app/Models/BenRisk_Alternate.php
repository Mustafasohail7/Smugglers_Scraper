<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BenRisk_Alternate extends Model
{
    use HasFactory;
    protected $table = 'benrisk_alternate';
    protected $fillable = ['code','edit_name','edit_detail','status','userid','type'];
}
