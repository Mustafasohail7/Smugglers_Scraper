<?php

use Illuminate\Support\Facades\Route;

// use App\Http\Controllers\UserController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\AdminWebSettingController;
use App\Http\Controllers\ImageUploadController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\RegisterStoreController;
use App\Http\Controllers\ExcelController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::group(['middleware'=>['auth','roles:admin']],function(){ 
Route::get('/admin', [AdminController::class,'index']);
Route::post('/image.upload', [ImageUploadController::class, 'storeImage']);
Route::get('/admin_myaccount', [AdminController::class,'admin_myaccount']);
Route::get('/admin_websetting', [AdminWebSettingController::class,'admin_websetting']);
Route::post('/update_pd_agree', [AdminWebSettingController::class,'update_pd_agree']);
Route::post('/update_eula', [AdminWebSettingController::class,'update_eula']);
Route::get('/admin_changepassword', [AdminController::class,'admin_changepassword']);
Route::get('/allusers', [AdminController::class,'allusers']);
Route::get('/adduser', [AdminController::class,'adduser']);
Route::post('/add_user', [AdminController::class,'add_user']);
Route::post('/submit_add_altername_admin', [AdminController::class,'submit_add_altername_admin']);
Route::get('/allbenefits', [AdminController::class,'allbenefits']);
Route::get('/allrisks', [AdminController::class,'allrisks']);
Route::get('/allprocedure', [AdminController::class,'allprocedure']);
Route::get('/alternate_procedure', [AdminController::class,'alternate_procedure']);
Route::get('/fetch_admin_procedure', [AdminController::class,'fetch_admin_procedure']);
Route::get('/fetch_admin_procedure_alternate', [AdminController::class,'fetch_admin_procedure_alternate']);
Route::get('/fetch_admin_procedure_alternate_single', [AdminController::class,'fetch_admin_procedure_alternate_single']);
Route::get('/delete_alternate_proc', [AdminController::class,'delete_alternate_proc']);
Route::get('/changestatus_alternate_proc', [AdminController::class,'changestatus_alternate_proc']);
Route::post('/changestatus_edited_benrisk', [AdminController::class,'changestatus_edited_benrisk']);
Route::post('/submit_new_procedure_admin', [AdminController::class,'submit_new_procedure_admin']);
Route::get('/procedure/{id}', [AdminController::class,'procedure']);
Route::post('/admin_procedure_status/{id}', [AdminController::class, 'admin_procedure_status']);
Route::post('/admin_benfit_status/{id}', [AdminController::class, 'admin_benfit_status']);
Route::post('/admin_risk_status/{id}', [AdminController::class, 'admin_risk_status']);
Route::post('/submit_new_benefitrisk_admin', [AdminController::class, 'submit_new_benefitrisk_admin']);
Route::post('/admin_benrisk_moveleftside', [AdminController::class, 'admin_benrisk_moveleftside']);
Route::post('/admin_benrisk_moverightside', [AdminController::class, 'admin_benrisk_moverightside']);
Route::post('/submit_edit_benefitrisk_admin', [AdminController::class, 'submit_edit_benefitrisk_admin']);
Route::get('/fetch_admin_benrisk_edit', [AdminController::class, 'fetch_admin_benrisk_edit']);
Route::get('/fetch_admin_benrisk_delete', [AdminController::class, 'fetch_admin_benrisk_delete']);
Route::get('/edited_admin_benrisk_delete', [AdminController::class, 'edited_admin_benrisk_delete']);
Route::get('/edited_benrisk', [AdminController::class, 'edited_benrisk']);
Route::get('/export-excel', [ExcelController::class, 'exportExcel']);
Route::get('/benrisk_autocomplete', [AdminController::class,'benrisk_autocomplete']);

});
Route::get('/', function () {
    return redirect('/home');
});

Route::get('/home', [HomeController::class,'index']);
Route::get('/procedure_autocomplete', [HomeController::class,'procedure_autocomplete']);
Route::get('/fetch_procedure', [HomeController::class,'fetch_procedure']);
Route::get('/fetch_generic_rb', [HomeController::class,'fetch_generic_rb']);
Route::post('/submit_new_procedure', [HomeController::class,'submit_new_procedure']);
Route::post('/submit_new_benefit', [HomeController::class,'submit_new_benefit']);
Route::post('/submit_new_risk', [HomeController::class,'submit_new_risk']);
Route::get('/change_password', [HomeController::class, 'changepassword']);
Route::get('/my_account', [HomeController::class, 'myaccount']);
Route::post('/update-account', [HomeController::class, 'updateaccount']);
Route::post('/update-password', [HomeController::class, 'updatePassword']);
Route::post('/save-signature', [HomeController::class, 'savesignature']);
Route::post('/save_procedure_alternate', [HomeController::class, 'save_procedure_alternate']);
Route::post('/registerstore', [RegisterStoreController::class, 'registerstore']);
Route::post('/edit_existing_benrisk', [HomeController::class, 'edit_existing_benrisk']);
Auth::routes([]);

Route::group(['middleware'=>['auth','roles:user']],function(){ 
});


// Route::controller(SearchController::class)->group(function(){

//     Route::get('demo-search', 'index');

//     Route::get('autocomplete', 'autocomplete')->name('autocomplete');

// });
